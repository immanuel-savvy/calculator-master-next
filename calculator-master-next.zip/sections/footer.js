import { scroll_to_top } from "@/components/footer";

export { scroll_to_top };
