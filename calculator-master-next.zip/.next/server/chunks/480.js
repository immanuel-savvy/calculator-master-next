"use strict";
exports.id = 480;
exports.ids = [480];
exports.modules = {

/***/ 4624:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_preview_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(586);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_adminstrator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4480);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_adminstrator__WEBPACK_IMPORTED_MODULE_4__]);
_pages_adminstrator__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* __next_internal_client_entry_do_not_use__ default auto */ 





class Article extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.handle_article = ()=>{
            let { article } = this.props;
            window.sessionStorage.setItem("article", JSON.stringify(article));
            _pages_adminstrator__WEBPACK_IMPORTED_MODULE_4__.emitter && _pages_adminstrator__WEBPACK_IMPORTED_MODULE_4__.emitter.emit("push_article", article);
        };
        this.toggle_full_text = ()=>this.setState({
                full_text: !this.state.full_text
            });
        this.state = {};
    }
    render() {
        let { full_text } = this.state;
        let { article, edit, remove } = this.props;
        if (!article) return null;
        let { image, image_hash, title, sections, views, comments, created, categories, _id } = article;
        let text = sections.find((sec)=>sec.type === "paragraph")?.text;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "col-xl-4 col-lg-4 col-md-6 col-sm-12",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "blg_grid_box",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "blg_grid_thumb",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: `/article?_id=${_id}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_preview_image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    image: image,
                                    image_hash: image_hash,
                                    onclick: this.handle_article
                                })
                            }),
                            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "crs_video_ico",
                                onClick: edit,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: `fa fa-edit`
                                })
                            }) : null,
                            remove ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "crs_locked_ico",
                                onClick: ()=>window.confirm("Are you sure to remove article?") && remove(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: `fa fa-trash`
                                })
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "blg_grid_caption",
                        children: [
                            categories.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "blg_tag",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: categories[0].tags[0]
                                })
                            }) : null,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "blg_title",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: `/article?_id=${_id}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            onClick: this.handle_article,
                                            children: title
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "blg_desc",
                                onClick: this.toggle_full_text,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: full_text ? text : text && text.slice(0, 150)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "crs_grid_foot",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "crs_flex",
                            style: {
                                marginLeft: 0
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "crs_fl_last",
                                style: {
                                    marginLeft: 0
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "foot_list_info",
                                    style: {
                                        marginLeft: 0
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "article_footer_ul",
                                        style: {
                                            marginLeft: 0,
                                            marginBlockStart: 0
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "elsio_ic",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fa fa-eye text-success"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "elsio_tx",
                                                        children: [
                                                            views,
                                                            " Views"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "elsio_ic",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "ti-comment-alt text-success"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "elsio_tx",
                                                        children: [
                                                            comments,
                                                            " Comments"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "elsio_ic",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fa fa-clock text-warning"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "elsio_tx",
                                                        children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .date_string */ .Rd)(created)
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Article);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91);
/* harmony import */ var _text_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1294);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 





class Category extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.clip = 75;
        this.toggle_clip = ()=>this.setState({
                expanded: !this.state.expanded
            });
        this.state = {};
    }
    render() {
        let { expanded } = this.state;
        let { category, remove, edit } = this.props;
        let { title, description, calculators, _id } = category;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "col-xl-3 col-lg-4 col-md-4 col-sm-6",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "cates_crs_wrip",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "crs_trios",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "crs_cate_icon",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    class: "fa fa-heartbeat"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                class: "crs_cate_link",
                                children: [
                                    edit || remove ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                text: "Edit",
                                                action: edit
                                            }),
                                            "\xa0 \xa0 \xa0",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                action: remove,
                                                text: "Remove"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                        ]
                                    }) : null,
                                    calculators && calculators.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: `/calculators/${title.replace(/ /g, "_")}?_id=${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .trim_id */ .GB)(_id)}`,
                                        onClick: ()=>(0,_components_footer__WEBPACK_IMPORTED_MODULE_2__/* .save_to_session */ .qC)("category", category),
                                        children: [
                                            calculators.length,
                                            " Calculators"
                                        ]
                                    }) : null
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "crs_capt_cat",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/calculators/${title.replace(/ /g, "_")}?_id=${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .trim_id */ .GB)(_id)}`,
                                onClick: ()=>(0,_components_footer__WEBPACK_IMPORTED_MODULE_2__/* .save_to_session */ .qC)("category", category),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    children: title
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: description.slice(0, expanded ? undefined : this.clip)
                            }),
                            description.length > this.clip ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                onClick: this.toggle_clip,
                                href: "#",
                                children: expanded ? "Show less" : "Read more"
                            }) : null
                        ]
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);


/***/ }),

/***/ 442:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _alert_box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5589);
/* harmony import */ var _listempty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1030);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1875);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _text_btn__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1294);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7354);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 








class Add_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.set_category = ({ target })=>this.setState({
                category: target.value
            });
        this.add = async ()=>{
            let { toggle, on_add } = this.props;
            let { title, category, description, id, _id } = this.state;
            this.setState({
                loading: true
            });
            let calc = {
                title: title.trim(),
                id,
                category,
                _id,
                description
            };
            let result = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_7__/* .post_request */ .Yu)(_id ? "update_calculator" : "create_calculator", calc);
            if (result && result._id) {
                calc._id = result._id;
                calc.created = result.created;
                on_add && on_add(calc);
                toggle();
            } else {
                this.setState({
                    message: result && result.message || "Cannot create calculator at the moment.",
                    loading: false
                });
            }
        };
        let { calculator } = this.props;
        this.state = {
            title: "",
            description: "",
            ...calculator,
            show_id: !!!calculator
        };
    }
    render() {
        let { toggle, navs } = this.props;
        let { title, show_id, loading, category, description, id, _id, message } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "modal-content overli",
                id: "loginmodal",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "modal-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                class: "modal-title",
                                children: "Add Calculator"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                class: "close",
                                "data-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>toggle && toggle(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        class: "fas fa-times-circle"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "modal-body",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "login-form",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                children: [
                                    _id ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            textAlign: "right"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            text: "Toggle ID",
                                            style: {
                                                textAlign: "right"
                                            },
                                            action: ()=>this.setState({
                                                    show_id: !this.state.show_id
                                                })
                                        })
                                    }),
                                    show_id ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "ID"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                class: "input-with-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        class: "form-control",
                                                        value: id,
                                                        disabled: !!_id,
                                                        onChange: ({ target })=>this.setState({
                                                                id: target.value,
                                                                message: ""
                                                            }),
                                                        placeholder: "id"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        class: "ti-copy"
                                                    })
                                                ]
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Title"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                class: "input-with-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        class: "form-control",
                                                        value: title,
                                                        onChange: ({ target })=>this.setState({
                                                                title: target.value,
                                                                message: ""
                                                            }),
                                                        placeholder: "Title"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        class: "ti-text"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Category"
                                            }),
                                            navs ? navs.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "simple-input",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                    defaultValue: category,
                                                    id: "category",
                                                    onChange: this.set_category,
                                                    className: "form-control",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: "",
                                                            disabled: true,
                                                            selected: true,
                                                            children: "-- Select Category --"
                                                        }),
                                                        navs.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: category._id,
                                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_8__/* .to_title */ .bk)(category.title.replace(/_/g, " "))
                                                            }, category._id))
                                                    ]
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listempty__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                text: "Cannot get categories."
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                smalls: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Description"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                class: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                    type: "text",
                                                    class: "form-control",
                                                    placeholder: "Brief description here...",
                                                    value: description,
                                                    style: {
                                                        minHeight: 200
                                                    },
                                                    onChange: ({ target })=>this.setState({
                                                            description: target.value,
                                                            message: ""
                                                        })
                                                })
                                            })
                                        ]
                                    }),
                                    message ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_box__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        message: message
                                    }) : null,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "form-group",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            disabled: !title.trim() || !id && !_id || !description.trim(),
                                            loading: loading,
                                            title: _id ? "Update" : "Add",
                                            action: this.add
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Add_calculator);


/***/ }),

/***/ 6323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _alert_box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5589);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7354);





class Add_category extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.add = async ()=>{
            let { toggle, on_add } = this.props;
            let { title, tags, description, _id } = this.state;
            this.setState({
                loading: true
            });
            let cat = {
                title: title.trim(),
                _id,
                tags,
                description
            };
            let result = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_4__/* .post_request */ .Yu)(_id ? "update_category" : "create_category", cat);
            if (result && result._id) {
                cat._id = result._id;
                cat.created = result.created;
                on_add(cat);
                toggle();
            } else {
                this.setState({
                    message: result && result.message || "Cannot create category at the moment.",
                    loading: false
                });
            }
        };
        let { category } = this.props;
        this.state = {
            title: "",
            description: "",
            ...category
        };
    }
    render() {
        let { toggle } = this.props;
        let { title, tags, loading, description, _id, message } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "modal-content overli",
                id: "loginmodal",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "modal-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                class: "modal-title",
                                children: "Add Category"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                class: "close",
                                "data-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>toggle && toggle(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        class: "fas fa-times-circle"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "modal-body",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "login-form",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Title"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                class: "input-with-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        class: "form-control",
                                                        value: title,
                                                        onChange: ({ target })=>this.setState({
                                                                title: target.value,
                                                                message: ""
                                                            }),
                                                        placeholder: "Title"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        class: "ti-text"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Tags"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                class: "input-with-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        class: "form-control",
                                                        placeholder: "insurance,banking",
                                                        value: tags,
                                                        onChange: ({ target })=>this.setState({
                                                                tags: target.value,
                                                                message: ""
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        class: "ti-link"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Description"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                class: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                    type: "text",
                                                    class: "form-control",
                                                    placeholder: "Brief description here...",
                                                    value: description,
                                                    onChange: ({ target })=>this.setState({
                                                            description: target.value,
                                                            message: ""
                                                        })
                                                })
                                            })
                                        ]
                                    }),
                                    message ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_box__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        message: message
                                    }) : null,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "form-group",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            disabled: !title.trim() || !description.trim(),
                                            loading: loading,
                                            title: _id ? "Update" : "Add",
                                            action: this.add
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Add_category);


/***/ }),

/***/ 6114:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _handle_image_upload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7824);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__]);
_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






class Add_image extends _handle_image_upload__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z {
    constructor(props){
        super(props);
        this.add = async ()=>{
            let { on_add, toggle } = this.props;
            let { image, loading, image_hash, image_name, _id } = this.state;
            if (loading) return;
            this.setState({
                loading: true
            });
            image_name = image_name && image_name.replace(/[ \.]/g, "_");
            let img = {
                image,
                image_hash,
                image_name,
                _id
            };
            let res = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)(_id ? "update_image" : "add_image", img);
            if (res?._id) {
                img.image = res.image;
                img._id = res._id;
                img.created = res.created;
                on_add && on_add(img);
                toggle();
            } else this.setState({
                loading: false,
                message: "Cannot upload image at the moment"
            });
        };
        let { image } = this.props;
        this.state = {
            ...image
        };
    }
    render() {
        let { toggle } = this.props;
        let { image, image_loading, _id, loading, image_name } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "modal-content overli",
                id: "loginmodal",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "modal-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                class: "modal-title",
                                children: "Add Image"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                class: "close",
                                "data-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>toggle && toggle(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    "aria-hidden": "true",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        class: "fas fa-times-circle"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "modal-body",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "login-form",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "form-group smalls",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Image (1200 x 800)*"
                                            }),
                                            image_loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "custom-file",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "file",
                                                        className: "custom-file-input",
                                                        id: "customFile",
                                                        accept: "image/*",
                                                        onChange: this.handle_image
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        className: "custom-file-label",
                                                        for: "customFile",
                                                        children: "Choose file"
                                                    })
                                                ]
                                            }),
                                            image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    alignItems: "center"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        className: "py-3 rounded",
                                                        style: {
                                                            width: "100%"
                                                        },
                                                        src: image && image.startsWith("data") ? image : `${_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .domain */ .nw}/images/${image}`
                                                    })
                                                })
                                            }) : null
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Image Name (Optional)"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                class: "input-with-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        class: "form-control",
                                                        value: image_name,
                                                        onChange: ({ target })=>this.setState({
                                                                image_name: target.value,
                                                                message: ""
                                                            }),
                                                        placeholder: "Image Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        class: "ti-text"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        title: _id ? "Update" : "Add",
                                        action: this.add,
                                        disabled: !image,
                                        loading: loading
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Add_image);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7774:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6219);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7108);
/* harmony import */ var _assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(487);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_2__]);
_dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





class Admin_card extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { admin } = this.props;
        let { firstname, lastname, image: _image, _id } = admin || {};
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            class: "d-user-avater",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: `${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_4__/* .domain */ .nw}/Images/${_image || "logo_single.png"}`,
                    class: "img-fluid avater",
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .to_title */ .bk)(`${firstname} ${lastname}`.trim())
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: _id === _dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_2__/* .default_admin */ .O ? "Default Admin" : "Admin"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    class: "elso_syu89",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    class: "ti-pencil"
                                })
                            })
                        })
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Admin_card);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ admin_login)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/footer.js
var footer = __webpack_require__(91);
// EXTERNAL MODULE: ./components/nav.js
var nav = __webpack_require__(3909);
// EXTERNAL MODULE: ./components/stretch_btn.js
var stretch_btn = __webpack_require__(3782);
;// CONCATENATED MODULE: ./assets/img/loginbg4.jpg
/* harmony default export */ const loginbg4 = ({"src":"/_next/static/media/loginbg4.bafb1f76.jpg","height":4016,"width":6016,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAJuKR//EABsQAAEEAwAAAAAAAAAAAAAAAAEAAhEhAwQS/9oACAEBAAE/ANt85OrlzATa/8QAGBEAAgMAAAAAAAAAAAAAAAAAAQIAEnH/2gAIAQIBAT8AQmi5P//EABgRAAIDAAAAAAAAAAAAAAAAAAABAhJx/9oACAEDAQE/AJJWen//2Q==","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./assets/js/utils/functions.js
var functions = __webpack_require__(7108);
// EXTERNAL MODULE: ./assets/js/utils/services.js
var services = __webpack_require__(7354);
;// CONCATENATED MODULE: ./components/dashboard/admin_login.js
/* __next_internal_client_entry_do_not_use__ default auto */ 







class Admin_login extends (external_react_default()).Component {
    constructor(props){
        super(props);
        this.set_email = ({ target })=>this.setState({
                email: target.value,
                message: ""
            });
        this.set_password = ({ target })=>this.setState({
                password: target.value,
                message: ""
            });
        this.login = async ()=>{
            let { email, password } = this.state;
            this.setState({
                loading: true
            });
            let response = await (0,services/* post_request */.Yu)("admin_login", {
                email,
                password
            });
            response && response.admin ? this.props.login(response.admin) : this.setState({
                password: "",
                message: response.message,
                loading: false
            });
        };
        this.state = {};
    }
    render() {
        let { navs } = this.props;
        let { email, password, message, loading } = this.state;
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            id: "main-wrapper",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx(nav/* default */.Z, {
                    navs: navs,
                    page: "signup"
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "clearfix"
                }),
                /*#__PURE__*/ jsx_runtime.jsx("section", {
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "row justify-content-center",
                            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-xl-7 col-lg-8 col-md-12 col-sm-12",
                                children: /*#__PURE__*/ jsx_runtime.jsx("form", {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "crs_log_wrap",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "crs_log__thumb",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                    src: loginbg4.src,
                                                    className: "img-fluid",
                                                    alt: ""
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "crs_log__caption",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "rcs_log_123",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "rcs_ico",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fas fa-lock"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "rcs_log_124",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                className: "Lpo09",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                                                    children: "Login to Your Admin Account"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "form-group",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("label", {
                                                                        children: "Email Address"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                        type: "email",
                                                                        className: "form-control",
                                                                        value: email,
                                                                        onChange: this.set_email,
                                                                        placeholder: "you@mail.com"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "form-group",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("label", {
                                                                        children: "Password"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                                        type: "password",
                                                                        className: "form-control",
                                                                        value: password,
                                                                        onChange: this.set_password,
                                                                        placeholder: "*******"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                className: "form-group",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx(stretch_btn/* default */.Z, {
                                                                    action: this.login,
                                                                    loading: loading,
                                                                    title: "Login"
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    message ? /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                        className: "text-danger",
                                                        children: (0,functions/* to_title */.bk)(message)
                                                    }) : null
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx(footer/* default */.ZP, {
                    navs: navs
                })
            ]
        });
    }
}
/* harmony default export */ const admin_login = (Admin_login);


/***/ }),

/***/ 1995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_adminstrator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4480);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_adminstrator__WEBPACK_IMPORTED_MODULE_3__]);
_pages_adminstrator__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* __next_internal_client_entry_do_not_use__ default auto */ 




class Dashboard_breadcrumb extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.right_btn = (on_click, title, hide)=>{
            return hide ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    class: "elkios",
                    onClick: on_click,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: "#",
                        class: "add_new_btn",
                        "data-toggle": "modal",
                        "data-target": "#catModal",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                class: "fas fa-plus-circle mr-1"
                            }),
                            (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(title)
                        ]
                    })
                })
            });
        };
        this.state = {};
    }
    render() {
        let { crumb, on_click, hide, title, right_btn } = this.props;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "row",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                class: "col-lg-12 col-md-12 col-sm-12 pb-4",
                children: right_btn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    class: "dashboard_wrap d-flex align-items-center justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "arion",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                class: "transparent",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
                                    class: "breadcrumb",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            class: "breadcrumb-item",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "#",
                                                onClick: ()=>_pages_adminstrator__WEBPACK_IMPORTED_MODULE_3__.emitter.emit("dash_nav_click", "dashboard"),
                                                style: {
                                                    color: "#061f3e"
                                                },
                                                children: "Home"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            class: "breadcrumb-item active",
                                            "aria-current": "page",
                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(crumb)
                                        })
                                    ]
                                })
                            })
                        }),
                        right_btn
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                    "aria-label": "breadcrumb",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
                        class: "breadcrumb",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                class: "breadcrumb-item",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    style: {
                                        color: "#061f3e"
                                    },
                                    href: "/",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                class: "breadcrumb-item active",
                                "aria-current": "page",
                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(crumb)
                            })
                        ]
                    })
                })
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard_breadcrumb);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8292:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1995);
/* harmony import */ var _dashboard_stats__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2438);
/* harmony import */ var _manage_banner_stuffs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8732);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_2__, _manage_banner_stuffs__WEBPACK_IMPORTED_MODULE_4__]);
([_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_2__, _manage_banner_stuffs__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// import Notifications from "../notifications";



class Dashboard_landing extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            class: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    crumb: "dashboard"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_stats__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    class: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "col-lg-8 col-md-12 col-sm-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_manage_banner_stuffs__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard_landing);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6219:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ default_admin),
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4480);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__]);
_pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* __next_internal_client_entry_do_not_use__ default,default_admin auto */ 



const default_admin = "adminstrators~123calculator_master~1234567890123";
class Dashboard_nav_menu extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.nav_click = (title)=>this.setState({
                current_nav: title
            }, ()=>{
                _pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__.emitter.emit("dash_nav_click", title);
            });
        this.nav_sub_click = (subtitle)=>this.setState({
                current_nav: subtitle
            }, ()=>_pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__.emitter.emit("dash_nav_click", subtitle));
        this.render_nav = ({ title, icon, subnav }, index)=>{
            let { current_nav, current_slide_index } = this.state;
            return subnav ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: "headingOne",
                        class: "card-header bg-white shadow-sm border-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            class: "m-2 accordion_title",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "#",
                                "data-toggle": "collapse",
                                "data-target": `#collapse${index}`,
                                "aria-expanded": current_slide_index === index ? "true" : "false",
                                "aria-controls": `collapse${index}`,
                                class: "d-block position-relative text-dark collapsible-link py-2",
                                children: `${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .to_title */ .bk)(title.replace(/_/g, " "))}`
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: `collapse${index}`,
                        "aria-labelledby": "headingOne",
                        "data-parent": "#accordionExample",
                        class: `collapse ${current_slide_index === index ? "show" : ""}`,
                        style: {
                            margin: 0,
                            marginLeft: 0,
                            padding: 0,
                            paddingRight: 0
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: subnav.map(({ title }, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    style: {
                                        flexWrap: "wrap",
                                        padding: 10,
                                        cursor: "pointer"
                                    },
                                    class: "incomplete" || 0,
                                    onClick: ()=>this.nav_dash(title),
                                    children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .to_title */ .bk)(title.replace(/_/g, " "))
                                }, index))
                        })
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                class: "p-2",
                style: {
                    cursor: "pointer"
                },
                onClick: ()=>this.nav_dash(title),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    class: "d-block position-relative text-dark py-2",
                    children: `${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .to_title */ .bk)(title.replace(/_/g, " "))}`
                })
            });
        };
        this.nav_dash = (title)=>_pages_adminstrator__WEBPACK_IMPORTED_MODULE_2__.emitter.emit("dash_nav_click", title);
        this.render = ()=>{
            let { admin } = this.props;
            let { navs } = this.state;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "accordionExample",
                class: "accordion shadow circullum",
                children: navs.map((nav, i)=>admin && admin._id !== default_admin && nav.title === "admins" ? null : this.render_nav(nav, i))
            });
        };
        this.state = {
            current_nav: "dashboard",
            navs: new Array({
                title: "dashboard",
                icon: "fa-th"
            }, {
                title: "calculator_categories",
                icon: "fa-th"
            }, {
                title: "calculators",
                icon: "fa-th"
            }, {
                title: "images",
                icon: "fa-th"
            }, {
                title: "new_article",
                icon: "fa-th"
            }, {
                title: "manage_articles",
                icon: "fa-th"
            }, {
                title: "logout",
                icon: "fa-th"
            })
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard_nav_menu);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8913:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _admin_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7774);
/* harmony import */ var _dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6219);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_admin_card__WEBPACK_IMPORTED_MODULE_2__, _dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_3__]);
([_admin_card__WEBPACK_IMPORTED_MODULE_2__, _dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




class Dashboard_navbar extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { admin } = this.props;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "col-lg-3 col-md-3",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "dashboard-navbar",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        admin: admin
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_nav_menu__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        admin: admin
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard_navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7354);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 




class Dashboard_stats extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let stats = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_3__/* .get_request */ .AN)("stats");
            this.setState({
                stats
            });
        };
        this.stat_icon_et_name = {
            courses: "fa-book",
            students: "fa-users",
            enrollments: "fa-gem",
            instructors: "fa-users"
        };
        this.format_figure = (figure)=>figure;
        this.stat_card = ({ title, figure, name })=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                class: "col-xl-3 col-lg-6 col-md-6 col-sm-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    class: "dashboard_stats_wrap",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "rounded-circle p-4 p-sm-4 d-inline-flex align-items-center justify-content-center theme-bg mb-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "position-absolute text-white h5 mb-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    class: `fas ${this.stat_icon_et_name[name]}`
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            class: "dashboard_stats_wrap_content",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    children: this.format_figure(figure)
                                }),
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(title)
                                })
                            ]
                        })
                    ]
                })
            }, name);
        };
        this.state = {};
    }
    render() {
        let { stats } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "row",
            children: stats ? stats.map ? (stats?.map((stat)=>this.stat_card(stat))) : null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                contained: true
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard_stats);


/***/ }),

/***/ 193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _article__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4624);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1995);
/* harmony import */ var _pages_adminstrator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4480);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_article__WEBPACK_IMPORTED_MODULE_2__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__, _pages_adminstrator__WEBPACK_IMPORTED_MODULE_5__]);
([_article__WEBPACK_IMPORTED_MODULE_2__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__, _pages_adminstrator__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default auto */ 






class Manage_articles extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let articles = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_6__/* .post_request */ .Yu)("articles");
            this.setState({
                articles
            });
        };
        this.remove = async (article_id)=>{
            let { articles } = this.state;
            articles = articles.filter((article)=>article._id !== article_id);
            this.setState({
                articles
            });
            await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_6__/* .post_request */ .Yu)(`remove_article/${article_id}`);
        };
        this.edit = (article)=>{
            _pages_adminstrator__WEBPACK_IMPORTED_MODULE_5__.emitter.emit("edit_article", article);
        };
        this.state = {};
    }
    render() {
        let { articles } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    crumb: "manage articles"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    class: "row",
                    children: articles ? articles.length ? articles.map((article)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_article__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            article: article,
                            remove: ()=>this.remove(article._id),
                            edit: ()=>this.edit(article)
                        })) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-5 d-flex justify-content-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "h4",
                            children: "No articles yet."
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        contained: true
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Manage_articles);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8732:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _handle_image_upload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7824);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _preview_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(586);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__]);
_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// import Video from "../../Components/video";
class Banner_stuffs extends _handle_image_upload__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let banner_stuffs = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .get_request */ .AN)("banner_stuffs");
            this.setState({
                banner_stuffs,
                ...banner_stuffs
            });
        };
        this.submit = async ()=>{
            let { video, image, thumbnail, thumbnail_hash, thumbnail_image, thumbnail_image_hash } = this.state;
            this.setState({
                uploading: true
            });
            if (thumbnail_image) thumbnail = thumbnail_image;
            if (thumbnail_image_hash) thumbnail_hash = thumbnail_image_hash;
            let banner_stuffs = {
                video,
                image,
                thumbnail,
                thumbnail_hash
            };
            if (video && video.startsWith("data")) {
                let response = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)("update_banner_video", {
                    thumbnail,
                    thumbnail_hash,
                    video
                });
                banner_stuffs.video = response.video;
                banner_stuffs.thumbnail = response.thumbnail;
            }
            if (image && image.startsWith("data")) {
                let response = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)("update_banner_image", {
                    image
                });
                banner_stuffs.image = response.image;
            }
            this.setState({
                uploading: false,
                banner_stuffs
            });
        };
        this.state = {
            banner_stuffs: "fetching",
            show_vid: true
        };
    }
    render() {
        let { banner_stuffs, thumbnail, uploading, video, image, thumbnail_image, image_loading, show_vid, image_hash } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: banner_stuffs !== "fetching" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "justify-content-center",
                        children: [
                            image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_preview_image__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                style: {
                                    marginBottom: 20
                                },
                                image_hash: image_hash,
                                image: image
                            }) : null,
                            (video || thumbnail || thumbnail_image) && show_vid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : null
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            class: "row mt-3",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group smalls",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Banner Image (1920 x 1200)"
                                        }),
                                        image_loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "custom-file",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "file",
                                                    className: "custom-file-input",
                                                    id: "customFile",
                                                    accept: "image/*",
                                                    onChange: this.handle_image
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "custom-file-label",
                                                    for: "customFile",
                                                    children: "Choose file"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    class: "col-lg-12 col-md-12 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "form-group",
                                        children: uploading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "#",
                                            style: {
                                                color: "#000"
                                            },
                                            onClick: (video || image || thumbnail_image) && this.submit,
                                            class: "btn theme-bg btn-md",
                                            children: banner_stuffs ? "Update" : "Upload"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                contained: true
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner_stuffs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3708:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8824);
/* harmony import */ var _add_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(442);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1995);
/* harmony import */ var _right_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8230);
/* harmony import */ var _featured_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4670);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1875);
/* harmony import */ var _listempty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1030);
/* harmony import */ var _small_btn__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1653);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7354);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__]);
_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












class Manage_calculators extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let calculators = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_10__/* .post_request */ .Yu)("calculators");
            this._original_calculators = (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_11__/* .copy_object */ .ee)(calculators);
            this.setState({
                calculators
            });
        };
        this.on_add = (calculator)=>{
            let { calculators, calculator_in_edit } = this.state;
            if (calculator_in_edit) calculators = calculators.map((cal)=>{
                if (cal._id === calculator_in_edit._id) return calculator;
                return cal;
            });
            else calculators = new Array(calculator, ...calculators);
            this.setState({
                calculators,
                calculator_in_edit: null
            });
        };
        this.toggle_add_calculator = ()=>this.add_calculator?.toggle();
        this.edit = (calculator)=>this.setState({
                calculator_in_edit: calculator
            }, this.toggle_add_calculator);
        this.filter_calculators = ()=>{
            let { calculators, search_param } = this.state;
            if (search_param) calculators = this._original_calculators.filter((c)=>(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_11__/* .search_object */ .iu)(c, search_param));
            else calculators = this._original_calculators;
            this.setState({
                calculators
            });
        };
        this.remove = async (calculator)=>{
            if (!window.confirm("Are you sure to remove calculator?")) return;
            let { calculators } = this.state;
            calculators = calculators.filter((cal)=>cal._id !== calculator);
            this.setState({
                calculators
            });
            await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_10__/* .post_request */ .Yu)(`remove_calculator/${calculator}`);
        };
        this.state = {};
    }
    render() {
        let { navs } = this.props;
        let { calculators, calculator_in_edit, search_param, show } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            class: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    crumb: `manage calculators ${calculators && calculators.length ? `- ${calculators.length}` : ""}`,
                    right_btn: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_right_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "add calculator",
                        action: this.toggle_add_calculator
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row justify-content-center mb-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-group col-lg-6 col-md-6 col-xl-4 col-sm-12",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "input-with-icon mb-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "ti-search"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        value: search_param,
                                        style: {
                                            backgroundColor: "#eee"
                                        },
                                        placeholder: "Search Calculators",
                                        onChange: ({ target })=>this.setState({
                                                search_param: target.value
                                            }, this.filter_calculators)
                                    })
                                ]
                            }),
                            search_param ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    textAlign: "center"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_small_btn__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    title: "Show all",
                                    action: ()=>this.setState({
                                            search_param: "",
                                            calculators: this._original_calculators
                                        })
                                })
                            }) : null
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: calculators ? calculators.length ? calculators.map((calculator)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_featured_calculator__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            calculator: calculator,
                            edit: (e)=>{
                                e.preventDefault();
                                this.edit(calculator);
                            }
                        }, calculator._id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listempty__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    ref: (add_calculator)=>this.add_calculator = add_calculator,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_add_calculator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        navs: navs,
                        toggle: this.toggle_add_calculator,
                        on_add: this.on_add,
                        calculator: calculator_in_edit
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Manage_calculators);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6848:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _listempty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1030);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8824);
/* harmony import */ var _add_category__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6323);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1995);
/* harmony import */ var _right_btn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8230);
/* harmony import */ var _category__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5411);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_6__]);
_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* __next_internal_client_entry_do_not_use__ default auto */ 









class Manage_categories extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let categories = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_9__/* .get_request */ .AN)("categories");
            this.setState({
                categories
            });
        };
        this.on_add = (category)=>{
            let { categories, category_in_edit } = this.state;
            if (category_in_edit) {
                categories = categories.map((cat)=>{
                    if (cat._id === category_in_edit._id) return category;
                    return cat;
                });
            } else categories = new Array(category, ...categories);
            this.setState({
                categories,
                category_in_edit: null
            });
        };
        this.toggle_add_category = ()=>this.add_category?.toggle();
        this.edit_cat = (cat)=>{
            this.setState({
                category_in_edit: cat
            });
            this.toggle_add_category();
        };
        this.remove_cat = async (cat)=>{
            if (!window.confirm("Are you sure you to remove category?")) return;
            let { categories } = this.state;
            categories = categories.filter((c)=>c._id !== cat._id);
            this.setState({
                categories
            });
            await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_9__/* .post_request */ .Yu)(`remove_category/${cat._id}`);
        };
        this.state = {};
    }
    render() {
        let { categories, category_in_edit } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            class: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    crumb: "manage categories",
                    right_btn: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_right_btn__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        title: "add category",
                        action: this.toggle_add_category
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: categories ? categories.length ? categories.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            category: category,
                            edit: ()=>this.edit_cat(category),
                            remove: ()=>this.remove_cat(category)
                        }, category._id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listempty__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    ref: (add_category)=>this.add_category = add_category,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_add_category__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        category: category_in_edit,
                        toggle: this.toggle_add_category,
                        on_add: this.on_add
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Manage_categories);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2807);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _listempty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1030);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1875);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8824);
/* harmony import */ var _preview_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(586);
/* harmony import */ var _small_btn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1653);
/* harmony import */ var _text_btn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1294);
/* harmony import */ var _add_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6114);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1995);
/* harmony import */ var _right_btn__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8230);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7108);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_add_image__WEBPACK_IMPORTED_MODULE_9__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_10__]);
([_add_image__WEBPACK_IMPORTED_MODULE_9__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default auto */ 













class Manage_images extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let images = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__/* .get_request */ .AN)("images");
            this._images = (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_12__/* .copy_object */ .ee)(images);
            this.setState({
                images
            });
        };
        this.on_add = (image)=>{
            let { images, image_in_edit } = this.state;
            if (image_in_edit) {
                images = images.map((img)=>img._id === image._id ? image : img);
            } else images = new Array(image, ...images);
            this.setState({
                images,
                image_in_edit: null
            });
        };
        this.edit = (image)=>this.setState({
                image_in_edit: image
            }, this.toggle_add_image);
        this.remove = async (img)=>{
            if (!window.confirm("Are you sure to remove image?")) return;
            let { images } = this.state;
            images = images.filter((i)=>i._id !== img);
            this.setState({
                images
            });
            await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__/* .post_request */ .Yu)(`remove_image/${img}`);
        };
        this.toggle_add_image = ()=>this.add_image?.toggle();
        this.copy_alert = (image)=>{
            clearTimeout(this.clear_copy);
            this.setState({
                copied: image
            });
            this.clear_copy = setTimeout(()=>this.setState({
                    copied: false
                }), 3000);
        };
        this.state = {};
    }
    render() {
        let { search_param, images, copied, image_in_edit } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            class: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    crumb: `manage images ${images && images.length ? `- ${images.length}` : ""}`,
                    right_btn: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_right_btn__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        title: "add image",
                        action: this.toggle_add_image
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row justify-content-center mb-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group col-lg-6 col-md-6 col-xl-4 col-sm-12",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-with-icon mb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "ti-search"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: search_param,
                                            style: {
                                                backgroundColor: "#eee"
                                            },
                                            placeholder: "Search Images",
                                            onChange: ({ target })=>this.setState({
                                                    search_param: target.value
                                                }, this.filter_images)
                                        })
                                    ]
                                }),
                                search_param ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        textAlign: "center"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_small_btn__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        title: "Show all",
                                        action: ()=>this.setState({
                                                search_param: "",
                                                images: this._images
                                            })
                                    })
                                }) : null
                            ]
                        }),
                        images ? images.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row",
                            children: images.map((img)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_preview_image__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    image: img.image,
                                    class_name: "rounded img-fluid",
                                    parent_class: "col-md-3 col-lg-3 col-xl-3 col-sm-6",
                                    image_hash: img.image_hash,
                                    childs: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            style: {
                                                display: "flex",
                                                flexDirection: "row",
                                                justifyContent: "space-between"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                    text: "Edit",
                                                    icon: "fa-edit",
                                                    action: ()=>this.edit(img)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    text: `${_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__/* .domain */ .nw}/images/${img.image}`,
                                                    onCopy: ()=>this.copy_alert(img.image),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: copied === img.image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                            text: "Copied",
                                                            icon: "fa-copy"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                            text: "Copy URL",
                                                            icon: "fa-link"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                    text: "Remove",
                                                    icon: "fa-close",
                                                    action: ()=>this.remove(img._id)
                                                })
                                            ]
                                        })
                                    })
                                }, img.image))
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listempty__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    no_drop_on_backdrop: true,
                    ref: (add_image)=>this.add_image = add_image,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_add_image__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        toggle: this.toggle_add_image,
                        on_add: this.on_add,
                        image: image_in_edit
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Manage_images);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1069:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7824);
/* harmony import */ var _components_loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1995);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7354);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__]);
([_components_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__, _dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







class New_article extends _components_handle_image_upload__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let article_categories = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .get_request */ .AN)("article_categories");
            this.setState({
                article_categories
            });
        };
        this.set_title = ({ target })=>this.setState({
                title: target.value
            });
        this.type = new Array("paragraph", "blockquote");
        this.set_section = (text, index)=>{
            let { sections } = this.state;
            sections[index].text = text;
            this.setState({
                sections
            });
        };
        this.add_section = (type)=>{
            let { sections } = this.state;
            sections.push({
                type,
                text: ""
            });
            this.setState({
                sections
            });
        };
        this.remove_section = (index)=>{
            let { sections } = this.state;
            sections.splice(index, 1);
            this.setState({
                sections
            });
        };
        this.handle_check = (category)=>{
            let { categories } = this.state;
            if (categories.find((cat)=>cat._id === category._id)) categories = categories.filter((cat)=>cat._id !== category._id);
            else categories.push(category);
            this.setState({
                categories
            });
        };
        this.sumbit = async ()=>{
            let { title, image, image_hash, categories, views, comments, sections, _id, pages, loading } = this.state;
            if (loading) return;
            this.setState({
                loading: true
            });
            let article = {
                title,
                image,
                image_hash,
                pages,
                categories: categories.map((cat)=>cat._id),
                sections
            };
            let response;
            if (_id) {
                article._id = _id;
                article.views = views;
                article.comments = comments;
                response = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)("update_article", article);
            } else {
                response = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)("new_article", article);
                article._id = response._id;
                article.created = response.created;
                article.categories = response.categories;
            }
            this.setState({
                title: "",
                image: null,
                categories: new Array(),
                sections: new Array(),
                image_name: "",
                loading: false
            });
        };
        let { article } = this.props;
        this.state = {
            sections: new Array(),
            categories: new Array(),
            ...article
        };
    }
    render() {
        let { image, title, sections, image_name, loading, image_loading, _id, article_categories } = this.state;
        let is_set = title && image && sections.find((section)=>section.text);
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-lg-9 col-md-9 col-sm-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_breadcrumb__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    crumb: "new article"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    class: "row",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        className: "forms_block",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-group smalls",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Image (1200 x 800)*"
                                    }),
                                    image_loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "custom-file",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                className: "custom-file-input",
                                                id: "customFile",
                                                accept: "image/*",
                                                onChange: this.handle_image
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "custom-file-label",
                                                for: "customFile",
                                                children: image_name || "Choose image"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "d-flex align-items-center justify-content-center",
                                        children: image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: "py-3",
                                            style: {
                                                maxHeight: 200,
                                                maxWidth: 200,
                                                resize: "both"
                                            },
                                            src: image.startsWith("data") ? this.state.image : `${_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .domain */ .nw}/images/${image}`
                                        }) : null
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-group smalls",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Title*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        onChange: this.set_title,
                                        value: title
                                    })
                                ]
                            }),
                            article_categories && !article_categories.length ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-group smalls",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Categories"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            display: "flex",
                                            flexWrap: "wrap",
                                            flexDirection: "row"
                                        },
                                        children: article_categories ? article_categories.map(({ title, _id })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group smalls",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        id: _id,
                                                        className: "checkbox-custom",
                                                        name: "article_category",
                                                        type: "checkbox",
                                                        checked: this.state.categories.includes(_id),
                                                        onChange: ()=>this.handle_check(_id)
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        for: _id,
                                                        className: "checkbox-custom-label",
                                                        children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__/* .to_title */ .bk)(title)
                                                    })
                                                ]
                                            }, _id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                                    })
                                ]
                            }),
                            sections.map((section, index)=>section.type === this.type[0] ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: `Paragraph - (${index + 1})`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    onClick: ()=>this.remove_section(index),
                                                    className: "btn btn-action",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: `fas fa-window-close`
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            onChange: ({ target })=>this.set_section(target.value, index),
                                            value: section.text,
                                            className: "form-control"
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Block Quote* "
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    onClick: ()=>this.remove_section(index),
                                                    className: "btn btn-action",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: `fas fa-window-close`
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            onChange: ({ target })=>this.set_section(target.value, index),
                                            value: section.text,
                                            className: "form-control"
                                        })
                                    ]
                                })),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    sections.find((section)=>!section.text && section.type === this.type[0]) ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        href: "#",
                                        onClick: (e)=>{
                                            e.preventDefault();
                                            this.add_section(this.type[0]);
                                        },
                                        className: "btn theme-bg enroll-btn text-light mr-2",
                                        children: [
                                            "Add Paragraph",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: "ti-plus"
                                            })
                                        ]
                                    }),
                                    sections.find((section)=>!section.text && section.type === this.type[1]) ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        href: "#",
                                        onClick: ()=>this.add_section(this.type[1]),
                                        className: "btn theme-bg enroll-btn text-light ml-2",
                                        children: [
                                            "Add Blockquote",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: "ti-plus"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "form-group smalls mt-5",
                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: is_set && this.sumbit,
                                    type: "button",
                                    className: `btn full-width ${is_set ? "theme-bg" : "grey"} short_description-white`,
                                    children: _id ? "Update Article" : "Create Article"
                                })
                            })
                        ]
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (New_article);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7108);



class Right_btn extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { title, action } = this.props;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                class: "elkios",
                onClick: action,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    href: "#",
                    class: "add_new_btn",
                    "data-toggle": "modal",
                    "data-target": "#catModal",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            class: "fas fa-plus-circle mr-1"
                        }),
                        (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_2__/* .to_title */ .bk)(title)
                    ]
                })
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Right_btn);


/***/ }),

/***/ 7824:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var blurhash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8591);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([blurhash__WEBPACK_IMPORTED_MODULE_1__]);
blurhash__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* __next_internal_client_entry_do_not_use__ default auto */ 

class Handle_image_upload extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
    constructor(...args){
        super(...args);
        this.load_image = async (src)=>new Promise((resolve, reject)=>{
                const img = new Image();
                img.setAttribute("crossOrigin", "Anonymous");
                img.onload = ()=>resolve(img);
                img.onerror = (...args)=>reject(args);
                img.src = src;
            });
        this.get_image_data = (image)=>{
        // const canvas = document.createElement("canvas");
        // canvas.width = image.width;
        // canvas.height = image.height;
        // const context = canvas.getContext("2d");
        // context.drawImage(image, 0, 0);
        // return context.getImageData(0, 0, image.width, image.height);
        };
        this.encode_image_to_blurhash = async (image_url)=>{
            const image = await this.load_image(image_url);
            const image_data = this.get_image_data(image);
            return (0,blurhash__WEBPACK_IMPORTED_MODULE_1__.encode)(image_data.data, image_data.width, image_data.height, 4, 4);
        };
        this.handle_image = ({ target }, prefix)=>{
            let file = target.files[0];
            let reader = new FileReader();
            reader.readAsDataURL(file);
            let prop = "image", prop_hash = "image_hash", prop_loading = "image_loading";
            if (prefix) {
                prop_hash = `${prefix}_${prop_hash}`;
                prop_loading = `${prefix}_${prop_loading}`;
                prop = `${prefix}_${prop}`;
            }
            this.setState({
                [prop_loading]: true
            });
            reader.onloadend = async (e)=>{
                await this.encode_image_to_blurhash(reader.result).then((res)=>this.setState({
                        [prop_hash]: res
                    })).catch((err)=>console.log(err));
                this.setState({
                    file,
                    [prop]: reader.result,
                    image_name: file.name,
                    [prop_loading]: false
                });
            };
        };
        this.handle_video = ({ target })=>{
            let file = target.files[0];
            let reader = new FileReader();
            reader.readAsDataURL(file);
            this.setState({
                video_loading: true
            });
            reader.onloadend = async (e)=>this.setState({
                    video: reader.result,
                    video_name: file.name,
                    show_vid: false,
                    video_loading: false
                }, ()=>this.setState({
                        show_vid: true
                    }));
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Handle_image_upload);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8824:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2__);



class Modal extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.toggle = ()=>this.setState({
                show: !this.state.show
            });
        this.state = {
            show: false
        };
    }
    render() {
        let { children, on_hide, style, aria_labelled_by, backdrop, keyboard, size, no_drop_on_backdrop, title, centered } = this.props;
        let { show } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default()), {
            size: size,
            scrollable: true,
            static: no_drop_on_backdrop,
            show: show,
            centered: centered,
            backdrop: no_drop_on_backdrop ? "static" : backdrop,
            keyboard: keyboard !== null ? keyboard : null,
            "aria-labelledby": aria_labelled_by,
            onHide: ()=>{
                this.toggle();
                on_hide && on_hide();
            },
            children: [
                title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Header), {
                    style: {
                        ...style
                    },
                    closeButton: true,
                    children: title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Title), {
                        style: style ? {
                            color: "#fff"
                        } : null,
                        id: aria_labelled_by,
                        children: title
                    }) : null
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_2___default().Body), {
                    style: {
                        margin: 0,
                        padding: 0,
                        ...style
                    },
                    children: children
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Modal);


/***/ }),

/***/ 4480:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   emitter: () => (/* binding */ emitter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semitter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3196);
/* harmony import */ var semitter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semitter__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_contact_us_today__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2160);
/* harmony import */ var _components_dashboard_admin_login__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9078);
/* harmony import */ var _components_dashboard_dashboard_landing__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8292);
/* harmony import */ var _components_dashboard_dashboard_navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8913);
/* harmony import */ var _components_dashboard_manage_articles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(193);
/* harmony import */ var _components_dashboard_manage_calculators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3708);
/* harmony import */ var _components_dashboard_manage_categories__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6848);
/* harmony import */ var _components_dashboard_manage_images__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8995);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91);
/* harmony import */ var _components_loadindicator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1875);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7354);
/* harmony import */ var _components_nav__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3909);
/* harmony import */ var _components_dashboard_new_article__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1069);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_dashboard_dashboard_landing__WEBPACK_IMPORTED_MODULE_5__, _components_dashboard_dashboard_navbar__WEBPACK_IMPORTED_MODULE_6__, _components_dashboard_manage_articles__WEBPACK_IMPORTED_MODULE_7__, _components_dashboard_manage_calculators__WEBPACK_IMPORTED_MODULE_8__, _components_dashboard_manage_categories__WEBPACK_IMPORTED_MODULE_9__, _components_dashboard_manage_images__WEBPACK_IMPORTED_MODULE_10__, _components_dashboard_new_article__WEBPACK_IMPORTED_MODULE_15__]);
([_components_dashboard_dashboard_landing__WEBPACK_IMPORTED_MODULE_5__, _components_dashboard_dashboard_navbar__WEBPACK_IMPORTED_MODULE_6__, _components_dashboard_manage_articles__WEBPACK_IMPORTED_MODULE_7__, _components_dashboard_manage_calculators__WEBPACK_IMPORTED_MODULE_8__, _components_dashboard_manage_categories__WEBPACK_IMPORTED_MODULE_9__, _components_dashboard_manage_images__WEBPACK_IMPORTED_MODULE_10__, _components_dashboard_new_article__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default,emitter auto */ 















const emitter = new (semitter__WEBPACK_IMPORTED_MODULE_2___default())();
class Adminstrator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let admin = (0,_components_footer__WEBPACK_IMPORTED_MODULE_11__/* .get_session */ .Lx)("admin");
            this.setState({
                admin,
                check_logged_in: false
            });
            let navs = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_13__/* .get_request */ .AN)("categories");
            this.setState({
                navs
            });
            this.dash_nav_click = (nav_title)=>this.setState({
                    current_nav: nav_title,
                    article: null
                }, _components_footer__WEBPACK_IMPORTED_MODULE_11__/* .scroll_to_top */ .kH);
            this.edit_article = (article)=>this.setState({
                    current_nav: "new_article",
                    article
                }, _components_footer__WEBPACK_IMPORTED_MODULE_11__/* .scroll_to_top */ .kH);
            emitter.listen("dash_nav_click", this.dash_nav_click);
            emitter.listen("edit_article", this.edit_article);
        };
        this.componentWillUnmount = ()=>{
            emitter.remove_listener("dash_nav_click", this.dash_nav_click);
            emitter.remove_listener("edit_article", this.edit_article);
        };
        this.login = (admin)=>{
            this.setState({
                admin
            });
            (0,_components_footer__WEBPACK_IMPORTED_MODULE_11__/* .save_to_session */ .qC)("admin", admin);
        };
        this.nav_et_component = (navs)=>new Object({
                dashboard: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_dashboard_landing__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    navs: navs
                }),
                calculator_categories: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_manage_categories__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    navs: navs
                }),
                calculators: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_manage_calculators__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    navs: navs
                }),
                images: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_manage_images__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    navs: navs
                }),
                new_article: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_new_article__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    navs: navs,
                    article: this.state.article
                }),
                manage_articles: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_manage_articles__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    navs: navs
                })
            });
        this.state = {
            check_logged_in: true,
            current_nav: "dashboard"
        };
    }
    render() {
        let { navs, admin, check_logged_in, current_nav } = this.state;
        return check_logged_in ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loadindicator__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}) : admin ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            id: "main-wrapper",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_nav__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    page: "dashboard",
                    navs: navs
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "clearfix"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "gray pt-4",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container-fluid",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_dashboard_navbar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    admin: admin
                                }),
                                this.nav_et_component(navs)[current_nav]
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_contact_us_today__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                    navs: navs
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_admin_login__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            login: this.login,
            navs: navs
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Adminstrator);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;