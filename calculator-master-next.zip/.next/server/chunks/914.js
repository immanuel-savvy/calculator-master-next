"use strict";
exports.id = 914;
exports.ids = [914];
exports.modules = {

/***/ 5235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _calculators_age__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5026);
/* harmony import */ var _calculators_Annuity_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7080);
/* harmony import */ var _calculators_auto_loan__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4237);
/* harmony import */ var _calculators_body_fat_calculator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3080);
/* harmony import */ var _calculators_body_mass_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8799);
/* harmony import */ var _calculators_body_metabolic_rate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2575);
/* harmony import */ var _calculators_business_loan__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(546);
/* harmony import */ var _calculators_cake_pan_converter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8156);
/* harmony import */ var _calculators_compound_interest__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4212);
/* harmony import */ var _calculators_concrete__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4599);
/* harmony import */ var _calculators_daily_calorie_need__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3085);
/* harmony import */ var _calculators_date__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3547);
/* harmony import */ var _calculators_dividend_calculator__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9917);
/* harmony import */ var _calculators_fha_loan__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(689);
/* harmony import */ var _calculators_hours__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4588);
/* harmony import */ var _calculators_income_tax__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(426);
/* harmony import */ var _calculators_inflation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1584);
/* harmony import */ var _calculators_investment_calculator__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(144);
/* harmony import */ var _calculators_lean_body_mass__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4449);
/* harmony import */ var _calculators_loan_calculator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9831);
/* harmony import */ var _calculators_margin_calculator__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(2112);
/* harmony import */ var _calculators_mean_squared_error__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(654);
/* harmony import */ var _calculators_measurement_coverter__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(2094);
/* harmony import */ var _calculators_measurement_to_weight__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(7617);
/* harmony import */ var _calculators_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4374);
/* harmony import */ var _calculators_ovulation_calculator__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2357);
/* harmony import */ var _calculators_pace_calculator__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(3176);
/* harmony import */ var _calculators_password_generator__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(4711);
/* harmony import */ var _calculators_percentage__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(9667);
/* harmony import */ var _calculators_personal_loan__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(9472);
/* harmony import */ var _calculators_pregnancy_calculator__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(9071);
/* harmony import */ var _calculators_pregnancy_weight_gain__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(872);
/* harmony import */ var _calculators_random_number_generator__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(4648);
/* harmony import */ var _calculators_rectangle_cake_pan__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(1350);
/* harmony import */ var _calculators_retirement__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(159);
/* harmony import */ var _calculators_salary_calculator__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(5169);
/* harmony import */ var _calculators_sales_price__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(5850);
/* harmony import */ var _calculators_sales_tax__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(7166);
/* harmony import */ var _calculators_selling_price__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(5044);
/* harmony import */ var _calculators_standard_deviation__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(9722);
/* harmony import */ var _calculators_subnet_calculator__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(3705);
/* harmony import */ var _calculators_tip_calculator__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(8249);
/* harmony import */ var _calculators_triangle__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(4583);
/* harmony import */ var _calculators_Va_mortgage_loan__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(7882);
/* harmony import */ var _calculators_weight_loss_calculator__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(2977);
/* harmony import */ var _calculators_weight_to_volume__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(1072);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(1875);
/* harmony import */ var _simple_calculator__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(7836);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_calculators_auto_loan__WEBPACK_IMPORTED_MODULE_4__, _calculators_business_loan__WEBPACK_IMPORTED_MODULE_8__, _calculators_compound_interest__WEBPACK_IMPORTED_MODULE_10__, _calculators_fha_loan__WEBPACK_IMPORTED_MODULE_15__, _calculators_investment_calculator__WEBPACK_IMPORTED_MODULE_19__, _calculators_loan_calculator__WEBPACK_IMPORTED_MODULE_21__, _calculators_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_26__, _calculators_personal_loan__WEBPACK_IMPORTED_MODULE_31__, _calculators_Va_mortgage_loan__WEBPACK_IMPORTED_MODULE_45__]);
([_calculators_auto_loan__WEBPACK_IMPORTED_MODULE_4__, _calculators_business_loan__WEBPACK_IMPORTED_MODULE_8__, _calculators_compound_interest__WEBPACK_IMPORTED_MODULE_10__, _calculators_fha_loan__WEBPACK_IMPORTED_MODULE_15__, _calculators_investment_calculator__WEBPACK_IMPORTED_MODULE_19__, _calculators_loan_calculator__WEBPACK_IMPORTED_MODULE_21__, _calculators_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_26__, _calculators_personal_loan__WEBPACK_IMPORTED_MODULE_31__, _calculators_Va_mortgage_loan__WEBPACK_IMPORTED_MODULE_45__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















































const Calcs = new Object({
    JVU8u3zNbeGuFSP: {
        title: "morgage loan repayment",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS9: {
        title: "loan cqlculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_loan_calculator__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS1: {
        title: "salary calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_salary_calculator__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSz: {
        title: "Income Tax",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_income_tax__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSA: {
        title: "Investment Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_investment_calculator__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSZ: {
        title: "Retirement Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_retirement__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSQ: {
        title: "Inflation",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_inflation__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSK: {
        title: "Body Mass Index (BMI)",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_body_mass_index__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSf: {
        title: "Body Metabolic Rate",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_body_metabolic_rate__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS0: {
        title: "Daily Calorie Need",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_daily_calorie_need__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSq: {
        title: "Weight Loss Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_weight_loss_calculator__WEBPACK_IMPORTED_MODULE_46__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS2: {
        title: "Body Fat Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_body_fat_calculator__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS3: {
        title: "Pregnancy Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_pregnancy_calculator__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS4: {
        title: "Pregnancy Weight Gain",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_pregnancy_weight_gain__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS5: {
        title: "Pace Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_pace_calculator__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS6: {
        title: "Percentage",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_percentage__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS7: {
        title: "Random number generate",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_random_number_generator__WEBPACK_IMPORTED_MODULE_34__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFS8: {
        title: "Triangle",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_triangle__WEBPACK_IMPORTED_MODULE_44__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSa: {
        title: "Standard Deviation",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_standard_deviation__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSb: {
        title: "Mean Squared Error",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_mean_squared_error__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSc: {
        title: "Age Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_age__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSd: {
        title: "Date",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_date__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSe: {
        title: "Hours",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_hours__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSg: {
        title: "Password Generator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_password_generator__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSh: {
        title: "Concrete",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_concrete__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSi: {
        title: "Auto Loan",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_auto_loan__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSj: {
        title: "Compound Interest",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_compound_interest__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSk: {
        title: "FHA Loan Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_fha_loan__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSl: {
        title: "VA Mortgage Loan",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_Va_mortgage_loan__WEBPACK_IMPORTED_MODULE_45__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSm: {
        title: "Personal Loan Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_personal_loan__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSn: {
        title: "Business Loan Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_business_loan__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSo: {
        title: "Annuity Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_Annuity_calculator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSp: {
        title: "Subnet Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_subnet_calculator__WEBPACK_IMPORTED_MODULE_42__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSr: {
        title: "Tip Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_tip_calculator__WEBPACK_IMPORTED_MODULE_43__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSs: {
        title: "Margin Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_margin_calculator__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSt: {
        title: "Dividend Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_dividend_calculator__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSu: {
        title: "Sales Tax",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_sales_tax__WEBPACK_IMPORTED_MODULE_39__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSv: {
        title: "Sales Price",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_sales_price__WEBPACK_IMPORTED_MODULE_38__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSw: {
        title: "Lean Body Mass",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_lean_body_mass__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSx: {
        title: "Measurement Converter",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_measurement_coverter__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSy: {
        title: "Cake Pan Converter",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_cake_pan_converter__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSF: {
        title: "Weight to Volume",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_weight_to_volume__WEBPACK_IMPORTED_MODULE_47__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSB: {
        title: "Measurement to Weight",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_measurement_to_weight__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSC: {
        title: "Selling Price",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_selling_price__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSD: {
        title: "Rectangle Cake Pan Converter",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_rectangle_cake_pan__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .Z, {})
    },
    JVU8u3zNbeGuFSE: {
        title: "Ovulation Calculator",
        component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculators_ovulation_calculator__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {})
    }
});
class Calculator_component extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { calculator } = this.props;
        if (!calculator) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_48__/* ["default"] */ .Z, {});
        let { id } = calculator;
        let comp = Calcs[id];
        return comp ? comp.component : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_simple_calculator__WEBPACK_IMPORTED_MODULE_49__/* ["default"] */ .Z, {});
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Calculator_component);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5914:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   u: () => (/* binding */ Img_tag)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _calculator_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5235);
/* harmony import */ var _reviews__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5521);
/* harmony import */ var react_markdown_lib_react_markdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7433);
/* harmony import */ var _calculator_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(550);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_calculator_component__WEBPACK_IMPORTED_MODULE_2__, react_markdown_lib_react_markdown__WEBPACK_IMPORTED_MODULE_5__]);
([_calculator_component__WEBPACK_IMPORTED_MODULE_2__, react_markdown_lib_react_markdown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default,Img_tag auto */ 





const Img_tag = ({ src })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
        src: src,
        className: "img-fluid rounded",
        style: {
            width: "100%"
        }
    });
};
class Calculator_details extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { calculator, categories } = this.props;
        let { description } = calculator;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-md-8 col-lg-8 col-sm-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculator_component__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            calculator: calculator
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            class: "col-lg-8 col-md-12 order-lg-first",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    class: "edu_wraper",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            class: "edu_title",
                                            children: "Description"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown_lib_react_markdown__WEBPACK_IMPORTED_MODULE_5__/* .ReactMarkdown */ .D, {
                                            // remarkPlugins={[remarkGfm]}
                                            children: description,
                                            components: {
                                                img: Img_tag
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_reviews__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    calculator: calculator
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_calculator_sidebar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            navs: categories,
                            calculator: calculator
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Calculator_details);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _listempty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1030);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1875);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7354);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 






class Calculator_sidebar extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.load_calc = async (nav)=>{
            let { calculator } = this.props;
            if (!nav) return;
            let calculators = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .post_request */ .Yu)("get_calculators", {
                calculators: nav?.calculators.filter((c)=>c !== calculator?._id)
            });
            this.setState({
                calculators
            });
        };
        this.componentDidMount = async ()=>{
            if (!this.cat) return;
            this.load_calc(this.cat);
        };
        this.toggle_short_description = ()=>this.setState({
                show_full: !this.state.show_full
            });
        this.state = {};
    }
    render() {
        let { show_full, calculators } = this.state;
        let { calculator, navs } = this.props;
        if (!calculator) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {});
        let nav = navs.find((n)=>n._id === calculator?.category);
        if (!nav) return;
        this.cat = nav;
        nav && !calculators && this.load_calc(nav);
        let { title, description } = nav || new Object();
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "col-lg-4 col-md-12 order-lg-last",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ed_view_box style_2 border min pt-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ml-3",
                        children: "Calculator Category"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        style: {
                            cursor: "pointer"
                        },
                        className: "theme-cl ml-3",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: this.toggle_short_description,
                        className: "ed_view_short px-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            style: {
                                cursor: "pointer"
                            },
                            children: show_full ? description : `${description.slice(0, 150)}...`
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "edu_wraper",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                class: "edu_title",
                                children: "More calculators"
                            }),
                            calculators ? calculators.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                class: "simple-list p-0",
                                children: calculators.map((calc, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: `/calculator/${calc.title}?_id=${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__/* .trim_id */ .GB)(calc._id)}`,
                                            children: calc.title
                                        })
                                    }, index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listempty__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Calculator_sidebar);


/***/ }),

/***/ 7080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Annuity_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { interest, years, principal } = this.state;
            return interest && years && principal;
        };
        this.calculate = ()=>{
            let { interest, years, principal } = this.state;
            interest = Number(interest);
            years = Number(years);
            principal = Number(principal);
            // Convert interest rate from percentage to decimal
            let decimal_rate = interest / 100;
            // Calculate the periodic interest rate
            let periodic_rate = decimal_rate / 12;
            // Calculate the total number of payments
            let num_payments = years * 12;
            // Calculate the annuity payment
            let annuity_payment = principal * periodic_rate / (1 - Math.pow(1 + periodic_rate, -num_payments));
            // Round the result to two decimal places
            let annuity_payment_round = Math.round(annuity_payment * 100) / 100;
            // Calculate the total cost of the annuity
            let total_cost = annuity_payment_round * num_payments;
            // Generate an object with the results
            this.setState({
                annuity_payment: annuity_payment_round,
                total_cost,
                done: true
            });
        };
        this.state = {
            principal: 200000,
            interest: 3.5,
            years: 30
        };
    }
    render() {
        let { annuity_payment, total_cost, interest, years, done, principal } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Annuity Payment"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(annuity_payment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Cost"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(total_cost.toFixed(2))
                            ]
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Principal"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Years"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "0",
                                                                placeholder: "Years",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Annuity_calculator);


/***/ }),

/***/ 7882:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








class VA_mortgage_loan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, years, interest } = this.state;
            return principal && years && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal, years, interest, va_funding_fee } = this.state;
            principal = Number(principal);
            years = Number(years);
            interest = Number(interest);
            va_funding_fee = Number(va_funding_fee);
            // Convert interest rate from percentage to decimal
            let decimal_rate = interest / 100;
            // Calculate the monthly interest rate
            let monthly_rate = decimal_rate / 12;
            // Calculate the number of monthly payments
            let months = years * 12;
            // Calculate the VA funding fee
            let funding_fee = va_funding_fee / 100;
            // Calculate the loan amount with funding fee included
            let loanAmount = principal * (1 + funding_fee);
            // Calculate the monthly payment
            let monthly_payment = loanAmount * monthly_rate / (1 - 1 / (1 + monthly_rate) ** months);
            // Calculate the total cost of the loan
            let total_cost = monthly_payment * months;
            // Generate the amortization schedule
            let amortisation_schedule = [];
            let balance = loanAmount;
            for(let i = 1; i <= months; i++){
                let interest = balance * monthly_rate;
                let principal = monthly_payment - interest;
                balance -= principal;
                let payment = interest + principal;
                let row = {
                    "S/N": i,
                    payment: payment.toFixed(2),
                    principal: principal.toFixed(2),
                    interest: interest.toFixed(2),
                    balance: balance.toFixed(2)
                };
                amortisation_schedule.push(row);
            }
            // Round the results to two decimal places
            let monthly_payment_rounded = Math.round(monthly_payment * 100) / 100;
            let total_cost_rounded = Math.round(total_cost * 100) / 100;
            // Generate an object with the results and the amortization schedule
            this.setState({
                monthly_payment: monthly_payment_rounded,
                total_cost: total_cost_rounded,
                amortisation_schedule,
                done: true
            });
        };
        this.state = {
            principal: 200000,
            interest: 4,
            years: 30,
            va_funding_fee: 2.3,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, years, interest, monthly_payment, amortisation_schedule, amortization_table_index, va_funding_fee, total_cost } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Monthly Payment"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(monthly_payment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Cost"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_cost.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Total Payments",
                                            data: {
                                                labels: [
                                                    "Principal",
                                                    "Interest"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            principal,
                                                            total_cost - principal
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortisation_schedule.map((res)=>res["S/N"]),
                                                datasets: [
                                                    {
                                                        label: "Balance",
                                                        data: amortisation_schedule.map((res)=>res.balance),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Interest",
                                                        data: amortisation_schedule.map((res)=>res.interest),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal",
                                                        data: amortisation_schedule.map((res)=>res.principal),
                                                        borderColor: "rgb(154, 0, 132)",
                                                        backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortisation_schedule && amortisation_schedule.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortisation_schedule[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortisation_schedule.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry["S/N"]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.principal)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.interest)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                })
                                            ]
                                        }, entry["S/N"]);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortisation_schedule.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Principal"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Years"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Years",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "VA Funding Fee"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "VA Funding Fee",
                                                                value: va_funding_fee,
                                                                onChange: ({ target })=>this.setState({
                                                                        va_funding_fee: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VA_mortgage_loan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);



class Age extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate = ()=>{
            let { dob, current_date } = this.state;
            dob = new Date(dob);
            current_date = new Date(current_date);
            let birth_year = dob.getFullYear();
            let birth_month = dob.getMonth();
            let birth_day = dob.getDate();
            let current_year = current_date.getFullYear();
            let current_month = current_date.getMonth();
            let current_day = current_date.getDate();
            let age = current_year - birth_year;
            if (current_month < birth_month || current_month === birth_month && current_day < birth_day) age--;
            this.setState({
                age,
                done: true
            });
        };
        let date = new Date();
        this.state = {
            dob: "2001-08-04",
            current_date: `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`
        };
    }
    render() {
        let { current_date, dob, age, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Age Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Date of Birth"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "date",
                                                                min: "1",
                                                                placeholder: "Date of Birth",
                                                                value: dob,
                                                                onChange: ({ target })=>this.setState({
                                                                        dob: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Age at the Date of"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "date",
                                                                min: "1",
                                                                placeholder: "To present",
                                                                value: current_date,
                                                                onChange: ({ target })=>this.setState({
                                                                        current_date: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Age"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                age,
                                " Years"
                            ]
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Age);


/***/ }),

/***/ 4237:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








class Auto_loan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, duration, interest } = this.state;
            return principal && duration && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal, duration, interest, down_payment } = this.state;
            principal = Number(principal);
            duration = Number(duration);
            interest = Number(interest);
            down_payment = Number(down_payment);
            // Calculate the loan amount minus the down payment
            principal = principal - down_payment;
            // Calculate the monthly interest rate and number of payments
            let monthly_interest_rate = interest / 12 / 100;
            let number_of_payments = duration * 12;
            // Calculate the monthly payment amount
            let monthly_payment = principal * monthly_interest_rate / (1 - (1 + monthly_interest_rate) ** -number_of_payments);
            // Calculate the total amount paid over the life of the loan
            let total_amount_paid = monthly_payment * number_of_payments;
            // Calculate the total interest paid over the life of the loan
            let total_interest_paid = total_amount_paid - principal;
            // Calculate the amortization table
            let balance = principal;
            let amortization_table = [];
            for(let i = 1; i <= number_of_payments; i++){
                let interest = balance * monthly_interest_rate;
                let principal_payment = monthly_payment - interest;
                balance = balance - principal_payment;
                amortization_table.push({
                    payment_number: i,
                    payment_amount: monthly_payment.toFixed(2),
                    principal_payment: principal_payment.toFixed(2),
                    interest_payment: interest.toFixed(2),
                    balance: balance.toFixed(2)
                });
            }
            // Return the results
            this.setState({
                done: true,
                monthly_payment,
                total_amount_paid,
                total_interest_paid,
                amortization_table
            });
        };
        this.state = {
            principal: 10000,
            interest: 5,
            duration: 3,
            down_payment: 0,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, duration, interest, down_payment, monthly_payment, total_amount_paid, total_interest_paid, amortization_table, amortization_table_index } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Monthly Payment"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(monthly_payment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-8 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon my-auto",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        "Total of ",
                                                        parseInt(amortization_table.length),
                                                        " Payments"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_amount_paid.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Total Interest"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_interest_paid.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Total Payments",
                                            data: {
                                                labels: [
                                                    "Principal",
                                                    "Interest"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            principal,
                                                            total_interest_paid
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortization_table.map((res)=>res.payment_number),
                                                datasets: [
                                                    {
                                                        label: "Balance",
                                                        data: amortization_table.map((res)=>res.balance),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal Payment",
                                                        data: amortization_table.map((res)=>res.principal_payment),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    },
                                                    {
                                                        label: "Interest Payment",
                                                        data: amortization_table.map((res)=>res.interest_payment),
                                                        borderColor: "rgb(154, 0, 132)",
                                                        backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortization_table && amortization_table.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortization_table[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortization_table.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.payment_number
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.payment_amount)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.principal_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.interest_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                })
                                            ]
                                        }, entry.payment_number);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortization_table.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Term (Years)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: duration,
                                                                onChange: ({ target })=>this.setState({
                                                                        duration: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Down Payment"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Down Payment",
                                                                value: down_payment,
                                                                onChange: ({ target })=>this.setState({
                                                                        down_payment: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Auto_loan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8158);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);





class Body_fat_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.sexes = new Array("male", "female");
        this.calculate = ()=>{
            let { sex, waist, neck, hip, height, weight } = this.state;
            waist = Number(waist);
            neck = Number(neck);
            hip = Number(hip);
            weight = Number(weight);
            height = Number(height);
            let body_fat_percentage;
            if (sex === "male") {
                let factor1 = 0.082;
                let factor2 = 0.034;
                let factor3 = 2.4;
                let lean_body_mass = weight * (1.0 - factor1);
                let body_fat_mass = weight - lean_body_mass;
                let waist_neck_ratio = waist - neck;
                body_fat_percentage = factor2 * waist - factor3 * waist_neck_ratio + factor1 * 100.0;
            } else {
                let factor1 = 0.29288;
                let factor2 = 0.1575;
                let factor3 = 5.41;
                let factor4 = 0.06934;
                let lean_body_mass = weight * (1.0 - factor1);
                let body_fat_mass = weight - lean_body_mass;
                let hipRatio = waist + hip - neck;
                body_fat_percentage = factor2 * hipRatio - factor3 * height - factor4 * 100.0;
                if (body_fat_percentage < 0 || body_fat_percentage > 100) body_fat_percentage = Math.abs(body_fat_percentage) / 100;
            }
            this.setState({
                body_fat_percentage,
                done: true
            });
        };
        this.state = {
            sex: this.sexes[0],
            age: 30,
            waist: 32,
            neck: 35,
            hip: 38,
            height: 170,
            weight: 80
        };
    }
    render() {
        let { sex, age, waist, neck, hip, height, weight, done, body_fat_percentage } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "modal-title text-dark",
                            children: "Body Fat Calculator"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "login-form",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (kg)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Weight",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height (centimeters)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Height",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Age",
                                                                value: age,
                                                                onChange: ({ target })=>this.setState({
                                                                        age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Sex"
                                                            }),
                                                            this.sexes.map((sex_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    type: "radio",
                                                                    title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(sex_.replace(/_/g, " ")),
                                                                    _id: sex_,
                                                                    checked: sex_ === sex,
                                                                    action: (sex)=>this.setState({
                                                                            sex
                                                                        }),
                                                                    name: "sex"
                                                                }, sex_))
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Waist (cm)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Waist",
                                                                value: waist,
                                                                onChange: ({ target })=>this.setState({
                                                                        waist: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Hip (cm)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Hip",
                                                                value: hip,
                                                                onChange: ({ target })=>this.setState({
                                                                        hip: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Neck (cm)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Neck",
                                                                value: neck,
                                                                onChange: ({ target })=>this.setState({
                                                                        neck: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                }),
                                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "crs_grid p-2 py-5 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "text-center text-dark",
                                            children: "Body Fat Percentage"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                            className: "text-center mb-2",
                                            children: [
                                                parseInt(body_fat_percentage),
                                                " %"
                                            ]
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body_fat_calculator);


/***/ }),

/***/ 8799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Body_mass_index extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate = ()=>{
            let { weight, height } = this.state;
            weight = Number(weight);
            height = Number(height);
            const bmi = weight / Math.pow(height, 2);
            this.setState({
                bmi,
                done: true
            });
        };
        this.state = {
            weight: 70,
            height: 1.75
        };
    }
    render() {
        let { weight, height, bmi, done } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "modal-title text-dark",
                            children: "Body Mass Index"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "login-form",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (kg)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Weight",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height (meters)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Height",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !weight || !height
                                        })
                                    ]
                                }),
                                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "crs_grid p-2 py-5 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "text-center text-dark",
                                            children: "BMI"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                            className: "text-center mb-2",
                                            children: [
                                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(bmi.toFixed(1)),
                                                " kg/m",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("sup", {
                                                    children: "2"
                                                })
                                            ]
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body_mass_index);


/***/ }),

/***/ 2575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8158);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);






class Body_metabolic_rate extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.sexes = new Array("male", "female");
        this.calculate = (prop)=>{
            let { weight, height, age, sex } = prop || this.state;
            weight = Number(weight);
            height = Number(height);
            age = Number(age);
            let bmr_constant = sex === this.sexes[0] ? 5 : -161;
            let weight_in_kg = weight * 0.453592; // convert pounds to kilograms
            let height_in_cm = height * 2.54; // convert inches to centimeters
            let bmr = 10 * weight_in_kg + 6.25 * height_in_cm - 5 * age + bmr_constant;
            this.setState({
                bmr,
                done: true
            });
            return bmr;
        };
        this.state = {
            weight: 70,
            height: 170,
            age: 30,
            sex: this.sexes[0]
        };
    }
    render() {
        let { weight, height, age, bmr, is_male, sex, done } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "modal-title text-dark",
                            children: "Body Metabolic Rate"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "login-form",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (Pounds)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Weight",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height (centimeters)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Height",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Age",
                                                                value: age,
                                                                onChange: ({ target })=>this.setState({
                                                                        age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Sex"
                                                            }),
                                                            this.sexes.map((sex_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    type: "radio",
                                                                    title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(sex_.replace(/_/g, " ")),
                                                                    _id: sex_,
                                                                    checked: sex_ === sex,
                                                                    action: (sex)=>this.setState({
                                                                            sex
                                                                        }),
                                                                    name: "sex"
                                                                }, sex_))
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !weight || !height || !age || !sex
                                        })
                                    ]
                                }),
                                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "crs_grid p-2 py-5 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "text-center text-dark",
                                            children: "BMR"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                            className: "text-center mb-2",
                                            children: [
                                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(bmr.toFixed(1)),
                                                " calories"
                                            ]
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body_metabolic_rate);


/***/ }),

/***/ 546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7108);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__]);
_line_charts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








class Business_loan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, years, interest } = this.state;
            return principal && years && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal, years, interest } = this.state;
            principal = Number(principal);
            years = Number(years);
            interest = Number(interest);
            // Convert interest rate from percentage to decimal
            let decimal_rate = interest / 100;
            // Calculate the monthly interest rate
            let monthly_rate = decimal_rate / 12;
            // Calculate the number of monthly payments
            let months = years * 12;
            // Calculate the monthly payment
            let payment = principal * monthly_rate / (1 - (1 + monthly_rate) ** -months);
            // Round the result to two decimal places
            let payment_rounded = Math.round(payment * 100) / 100;
            // Generate an array to store the amortization table
            let amortization_table = [];
            // Calculate the starting balance
            let balance = principal;
            let total_amount_paid = 0, total_interest_paid = 0;
            // Loop through each month and calculate the interest and principal payments
            for(let i = 1; i <= months; i++){
                // Calculate the interest for the current month
                let interest = balance * monthly_rate;
                total_interest_paid += interest;
                // Calculate the principal for the current month
                let principal = payment - interest;
                // Round the principal to two decimal places
                let principal_rounded = Math.round(principal * 100) / 100;
                total_amount_paid += payment_rounded;
                // Calculate the remaining balance after the current month's payment
                balance = balance - principal;
                // Round the balance to two decimal places
                let balance_rounded = Math.round(balance * 100) / 100;
                // Add the current month's data to the amortization table
                amortization_table.push({
                    month: i,
                    balance: balance_rounded,
                    principal: principal_rounded,
                    interest: Math.round(interest * 100) / 100,
                    payment: payment_rounded
                });
            }
            // Generate an object with the results and the amortization table
            this.setState({
                loan_amount: principal,
                loan_interest: interest,
                total_amount_paid,
                total_interest_paid,
                duration: years,
                monthly_payment: payment_rounded,
                amortization_table,
                done: true
            }, _footer__WEBPACK_IMPORTED_MODULE_7__/* .scroll_to_top */ .kH);
        };
        this.state = {
            principal: 10000,
            interest: 5,
            years: 3,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, years, interest, total_amount_paid, total_interest_paid, amortization_table, amortization_table_index, monthly_payment } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Monthly Payment"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(monthly_payment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-8 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon my-auto",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        "Total of ",
                                                        parseInt(amortization_table.length),
                                                        " Payments"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(total_amount_paid.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Total Interest"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(total_interest_paid.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                    md: 8,
                                    sm: 12,
                                    lg: 6,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        title: "Figures Trend",
                                        data: {
                                            labels: amortization_table.map((res)=>res.month),
                                            datasets: [
                                                {
                                                    label: "Balance",
                                                    data: amortization_table.map((res)=>res.balance),
                                                    borderColor: "rgb(53, 162, 235)",
                                                    backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                },
                                                {
                                                    label: "Principal",
                                                    data: amortization_table.map((res)=>res.principal),
                                                    borderColor: "rgb(255, 99, 132)",
                                                    backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                },
                                                {
                                                    label: "Interest",
                                                    data: amortization_table.map((res)=>res.interest),
                                                    borderColor: "rgb(154, 0, 132)",
                                                    backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                }
                                            ]
                                        }
                                    })
                                })
                            })
                        })
                    ]
                }) : null,
                amortization_table && amortization_table.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortization_table[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortization_table.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.month
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.principal)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.interest)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.payment)
                                                    ]
                                                })
                                            ]
                                        }, entry.month);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortization_table.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Term (Years)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Business_loan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);






class Cake_pan_converter extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.units = new Array("inches", "centimeters", "millimeters", "feet", "meters");
        this.is_set = ()=>{
            let { from_unit, to_unit, height, diameter } = this.state;
            return from_unit && to_unit && height && diameter;
        };
        this.calculate = ()=>{
            let { from_unit, to_unit, height, diameter } = this.state;
            diameter = Number(diameter);
            height = Number(height);
            // Convert dimensions to a base from_unit (inches)
            let base_diameter, base_height;
            switch(from_unit.toLowerCase()){
                case "inches":
                    base_diameter = diameter;
                    base_height = height;
                    break;
                case "centimeters":
                    base_diameter = diameter / 2.54;
                    base_height = height / 2.54;
                    break;
                case "millimeters":
                    base_diameter = diameter / 25.4;
                    base_height = height / 25.4;
                    break;
                case "feet":
                    base_diameter = diameter * 12;
                    base_height = height * 12;
                    break;
                case "meters":
                    base_diameter = diameter * 39.37;
                    base_height = height * 39.37;
                    break;
                default:
                    throw new Error("Invalid 'from_unit' value. Supported units are: inches, centimeters, millimeters, feet, meters.");
            }
            // Calculate the radius of the pan
            let radius = base_diameter / 2;
            // Convert dimensions to the target from_unit
            let converted_diameter, converted_height;
            switch(to_unit.toLowerCase()){
                case "inches":
                    converted_diameter = base_diameter;
                    converted_height = base_height;
                    break;
                case "centimeters":
                    converted_diameter = base_diameter * 2.54;
                    converted_height = base_height * 2.54;
                    break;
                case "millimeters":
                    converted_diameter = base_diameter * 25.4;
                    converted_height = base_height * 25.4;
                    break;
                case "feet":
                    converted_diameter = base_diameter / 12;
                    converted_height = base_height / 12;
                    break;
                case "meters":
                    converted_diameter = base_diameter / 39.37;
                    converted_height = base_height / 39.37;
                    break;
                default:
                    throw new Error("Invalid 'to_unit' value. Supported units are: inches, centimeters, millimeters, feet, meters.");
            }
            // Calculate the height of the pan
            converted_height = parseFloat(converted_height.toFixed(2));
            // Calculate the diameter of the pan
            converted_diameter = parseFloat(converted_diameter.toFixed(2));
            // Calculate the area of the pan in square inches
            let area = Math.PI * Math.pow(radius, 2);
            // Calculate the volume of the pan in cubic inches
            let volume = area * converted_height;
            // Round the volume to two decimal places
            let rounded_volume = parseFloat(volume.toFixed(2));
            // Return an object with the converted dimensions and volume
            this.setState({
                done: true,
                diameter_r: converted_diameter,
                height_r: converted_height,
                volume: rounded_volume
            });
        };
        this.state = {
            from_unit: this.units[0],
            to_unit: this.units[1],
            diameter: 9,
            height: 2
        };
    }
    render() {
        let { volume, diameter_r, height_r, done, from_unit, to_unit, diameter, height } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: "text-center text-dark",
                                children: [
                                    "Converting from ",
                                    from_unit,
                                    " to ",
                                    to_unit
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Volume"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        " ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(volume)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Diameter"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(diameter_r)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Height"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(height_r)
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Diameter"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: diameter,
                                                                onChange: ({ target })=>this.setState({
                                                                        diameter: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Diameter"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Height"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "From Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "bank",
                                                                    defaultValue: from_unit,
                                                                    onChange: ({ target })=>this.setState({
                                                                            from_unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((from_unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: from_unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(from_unit)
                                                                        }, from_unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "To Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "bank",
                                                                    defaultValue: to_unit,
                                                                    onChange: ({ target })=>this.setState({
                                                                            to_unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((to_unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: to_unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(to_unit)
                                                                        }, to_unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cake_pan_converter);


/***/ }),

/***/ 4212:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5169);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__]);
_line_charts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








class Compound_interest extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, years, interest } = this.state;
            return principal && years && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal, years, interest, compound_per_year } = this.state;
            principal = Number(principal) || 0;
            years = Number(years) || 0;
            interest = Number(interest) || 0;
            compound_per_year = Number(compound_per_year) || 0;
            // Convert interest rate from percentage to decimal
            let decimal_rate = interest / 100;
            // Calculate the compound interest
            let total = principal * (1 + decimal_rate / compound_per_year) ** (compound_per_year * years);
            // Round the result to two decimal places
            let total_rounded = Math.round(total * 100) / 100;
            // Calculate the interest earned
            let interest_earned = total_rounded - principal;
            // Round the interest earned to two decimal places
            let interest_earned_rounded = Math.round(interest_earned * 100) / 100;
            // Calculate the payment schedule
            let payment_schedule = new Array();
            let balance = principal;
            let interest_paid = 0;
            let principal_paid = 0;
            for(let i = 0; i < years * compound_per_year; i++){
                // Calculate the interest and principal paid for this period
                let period_interest = balance * decimal_rate / compound_per_year;
                let period_interval = (total - balance) / (years * compound_per_year - i);
                // Update the balance and totals
                balance -= period_interval;
                interest_paid += period_interest;
                principal_paid += period_interval;
                // Add the payment details to the schedule
                payment_schedule.push({
                    period: i + 1,
                    balance: Math.round(balance * 100) / 100,
                    interest_paid: Math.round(period_interest * 100) / 100,
                    principal_paid: Math.round(period_interval * 100) / 100
                });
            }
            // Generate an object with the results
            this.setState({
                total: total_rounded,
                interest_earned: interest_earned_rounded,
                payment_schedule,
                done: true
            }, _footer__WEBPACK_IMPORTED_MODULE_6__/* .scroll_to_top */ .kH);
        };
        this.state = {
            principal: 1000,
            interest: 5,
            years: 10,
            compound_per_year: 12,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, years, interest, payment_schedule, amortization_table_index, compound_per_year, interest_earned, total } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(total.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Interest Earned"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(interest_earned.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                    md: 8,
                                    sm: 12,
                                    lg: 6,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        title: "Figures Trend",
                                        data: {
                                            labels: payment_schedule.map((res)=>res.period),
                                            datasets: [
                                                {
                                                    label: "Balance",
                                                    data: payment_schedule.map((res)=>res.balance),
                                                    borderColor: "rgb(53, 162, 235)",
                                                    backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                },
                                                {
                                                    label: "Principal",
                                                    data: payment_schedule.map((res)=>res.interest_paid),
                                                    borderColor: "rgb(255, 99, 132)",
                                                    backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                },
                                                {
                                                    label: "Interest",
                                                    data: payment_schedule.map((res)=>res.principal_paid),
                                                    borderColor: "rgb(154, 0, 132)",
                                                    backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                }
                                            ]
                                        }
                                    })
                                })
                            })
                        })
                    ]
                }) : null,
                payment_schedule && payment_schedule.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(payment_schedule[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: payment_schedule.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.period
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.interest_paid)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(entry.principal_paid)
                                                    ]
                                                })
                                            ]
                                        }, entry.period);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < payment_schedule.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Principal"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Years"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Years",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Compound per Year"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Compound per Year",
                                                                value: compound_per_year,
                                                                onChange: ({ target })=>this.setState({
                                                                        compound_per_year: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Compound_interest);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);



class Concrete extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate_1 = ()=>{
            let { width, length, depth } = this.state;
            width = Number(width);
            depth = Number(depth);
            length = Number(length);
            let width_feet = width / 12;
            let length_feet = length / 12;
            let depth_feet = depth / 12;
            // Calculate volume in cubic feet
            let volume_cubic_feet = width_feet * length_feet * depth_feet;
            // Calculate volume in cubic yards
            let volume_cubic_yard = volume_cubic_feet / 27;
            // Round to two decimal places
            let result = Math.round(volume_cubic_yard * 100) / 100;
            // Return result
            this.setState({
                square_concrete: result,
                done1: true
            });
        };
        this.calculate_2 = ()=>{
            let { num_steps, width_s, depth_s, height_s } = this.state;
            num_steps = Number(num_steps);
            width_s = Number(width_s);
            depth_s = Number(depth_s);
            height_s = Number(height_s);
            // Convert dimensions to feet
            let width_feet = width_s / 12;
            let height_feet = height_s / 12;
            let depth_feed = depth_s / 12;
            // Calculate volume in cubic feet
            let volume_cubic_feet = width_feet * height_feet * depth_feed * num_steps;
            // Calculate volume in cubic yards
            let volume_cubic_yard = volume_cubic_feet / 27;
            // Round to two decimal places
            let result = Math.round(volume_cubic_yard * 100) / 100;
            // Return result
            this.setState({
                stairs_concrete: result,
                done2: true
            });
        };
        this.calculate_3 = ()=>{
            let { radius, height_c } = this.state;
            radius = Number(radius);
            height_c = Number(height_c);
            let radius_feet = radius / 12;
            let height_feet = height_c / 12;
            // Calculate volume in cubic feet
            let volume_cubic_feet = Math.PI * radius_feet ** 2 * height_feet;
            // Calculate volume in cubic yards
            let volume_cubic_yard = volume_cubic_feet / 27;
            // Round to two decimal places
            let c_result = Math.round(volume_cubic_yard * 100) / 100;
            // Return result
            this.setState({
                c_result,
                done3: true
            });
        };
        this.state = {
            width: 12,
            length: 12,
            depth: 4,
            width_s: 10,
            height_s: 8,
            radius: 3,
            height_c: 6,
            depth_s: 2,
            num_steps: 5
        };
    }
    render() {
        let { width, length, depth, done1, square_concrete, done2, width_s, depth_s, height_s, stairs_concrete, num_steps, radius, height_c, done3, c_result } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Slabs, Square Footings, or Walls"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Width"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: width,
                                                                placeholder: "Width",
                                                                onChange: ({ target })=>this.setState({
                                                                        width: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Length"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: length,
                                                                placeholder: "Length",
                                                                onChange: ({ target })=>this.setState({
                                                                        length: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Depth"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: depth,
                                                                placeholder: "Depth",
                                                                onChange: ({ target })=>this.setState({
                                                                        depth: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate_1
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: square_concrete
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Stairs Concrete Volume"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Number of Steps"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: num_steps,
                                                                placeholder: "Number of Steps",
                                                                onChange: ({ target })=>this.setState({
                                                                        num_steps: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Width"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: width_s,
                                                                placeholder: "Width",
                                                                onChange: ({ target })=>this.setState({
                                                                        width_s: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Length"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: height_s,
                                                                placeholder: "Length",
                                                                onChange: ({ target })=>this.setState({
                                                                        height_s: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Depth"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: depth_s,
                                                                placeholder: "Depth",
                                                                onChange: ({ target })=>this.setState({
                                                                        depth_s: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate_2
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done2 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: stairs_concrete
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Circular Slab Volume"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Radius"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: radius,
                                                                placeholder: "Radius",
                                                                onChange: ({ target })=>this.setState({
                                                                        radius: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "1",
                                                                value: height_c,
                                                                placeholder: "Height",
                                                                onChange: ({ target })=>this.setState({
                                                                        height_c: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate_3
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done3 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: c_result
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Concrete);


/***/ }),

/***/ 3085:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8158);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);





class Daily_calorie_need extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.activities = new Array("sedentary", "lightly_active", "moderately_active", "very_active", "extra_active");
        this.sexes = new Array("male", "female");
        this.calculate = (prop)=>{
            let { weight, height, age, sex, activity } = prop || this.state;
            let bmr;
            // Calculate BMR based on sex
            if (sex === "male") {
                bmr = 10 * weight + 6.25 * height - 5 * age + 5;
            } else {
                bmr = 10 * weight + 6.25 * height - 5 * age - 161;
            }
            // Calculate daily calorie needs based on BMR and activity level
            let daily_calorie_need;
            switch(activity){
                case "lightly_active":
                    daily_calorie_need = bmr * 1.375;
                    break;
                case "moderately_active":
                    daily_calorie_need = bmr * 1.55;
                    break;
                case "very_active":
                    daily_calorie_need = bmr * 1.725;
                    break;
                case "extra_active":
                    daily_calorie_need = bmr * 1.9;
                    break;
                default:
                    daily_calorie_need = bmr * 1.2;
                    break;
            }
            this.setState({
                daily_calorie_need,
                done: true
            });
            return daily_calorie_need;
        };
        this.state = {
            weight: 75,
            height: 180,
            age: 30,
            sex: this.sexes[0],
            activity: this.activities[0]
        };
    }
    render() {
        let { weight, height, daily_calorie_need, age, bmr, sex, done } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "modal-title text-dark",
                            children: "Body Mass Index"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "login-form",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (kg)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Weight",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height (centimeters)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Height",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Age",
                                                                value: age,
                                                                onChange: ({ target })=>this.setState({
                                                                        age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Sex"
                                                            }),
                                                            this.sexes.map((sex_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    type: "radio",
                                                                    title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(sex_.replace(/_/g, " ")),
                                                                    _id: sex_,
                                                                    checked: sex_ === sex,
                                                                    action: (sex)=>this.setState({
                                                                            sex
                                                                        }),
                                                                    name: "sex"
                                                                }, sex_))
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Activity Level"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "activity",
                                                                    onChange: ({ target })=>this.setState({
                                                                            activity: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.activities.map((activity)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: activity,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(activity.replace(/_/g, " "))
                                                                        }, activity))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !weight || !height || !age || !sex
                                        })
                                    ]
                                }),
                                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "crs_grid p-2 py-5 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "text-center text-dark",
                                            children: "Daily Calorie Need"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                            className: "text-center mb-2",
                                            children: [
                                                (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .Ew)(parseInt(daily_calorie_need)),
                                                " calories"
                                            ]
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Daily_calorie_need);


/***/ }),

/***/ 3547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);



class Date_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.operations = new Array("addition", "subtraction");
        this.calculate = ()=>{
            let { day1, day2 } = this.state;
            day1 = new Date(day1);
            day2 = new Date(day2);
            let date1_time = day1.getTime();
            let date2_time = day2.getTime();
            let time_diff = Math.abs(date2_time - date1_time);
            let day_diff = Math.ceil(time_diff / (1000 * 3600 * 24));
            this.setState({
                diff: day_diff,
                done1: true
            });
        };
        this.calculate_2 = ()=>{
            let { months, years, days, operation, date } = this.state;
            date = new Date(date);
            months = Number(months);
            years = Number(years);
            days = Number(days);
            // Convert the date to a JavaScript date object
            let original_date = new Date(date);
            // Perform the requested operation (addition or subtraction)
            let new_date = operation === this.operations[0] ? new Date(original_date.getFullYear() + years, original_date.getMonth() + months, original_date.getDate() + days) : new Date(original_date.getFullYear() - years, original_date.getMonth() - months, original_date.getDate() - days);
            // Return the new date in YYYY-MM-DD format
            let year = new_date.getFullYear();
            let month = (new_date.getMonth() + 1).toString().padStart(2, "0");
            let day = new_date.getDate().toString().padStart(2, "0");
            this.setState({
                result: `${year}-${month}-${day}`,
                done2: true
            });
        };
        let d = new Date();
        let td = `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, "0")}-${d.getDate().toString().padStart(2, "0")}`;
        this.state = {
            day1: `${d.getFullYear()}-${d.getMonth().toString().padStart(2, "0")}-${(d.getDate() + 0).toString().padStart(2, "0")}`,
            day2: td,
            operation: this.operations[0],
            date: td,
            years: 1,
            months: 2,
            days: 3
        };
    }
    render() {
        let { day1, day2, done1, diff, done2, result, date, operation, years, months, days } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Date Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Day1"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "date",
                                                                placeholder: "Day1",
                                                                value: day1,
                                                                onChange: ({ target })=>this.setState({
                                                                        day1: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Day2"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "date",
                                                                placeholder: "Day 2",
                                                                value: day2,
                                                                onChange: ({ target })=>this.setState({
                                                                        day2: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Number of Days"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                diff,
                                " Days"
                            ]
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Date +/-"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Date"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "date",
                                                                placeholder: "Date",
                                                                value: date,
                                                                onChange: ({ target })=>this.setState({
                                                                        date: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Years"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Years",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Months"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Months",
                                                                value: months,
                                                                onChange: ({ target })=>this.setState({
                                                                        months: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Days"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Days",
                                                                value: days,
                                                                onChange: ({ target })=>this.setState({
                                                                        days: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Operation"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "length",
                                                                    defaultValue: operation,
                                                                    onChange: ({ target })=>this.setState({
                                                                            operation: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.operations.map((l)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: l,
                                                                            children: l
                                                                        }, l))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate_2
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done2 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Date"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: result
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Date_calculator);


/***/ }),

/***/ 9917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Dividend_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { share_price, dividend_yield, shares } = this.state;
            return share_price && dividend_yield && shares;
        };
        this.calculate = ()=>{
            let { share_price, dividend_yield, shares } = this.state;
            share_price = Number(share_price);
            dividend_yield = Number(dividend_yield);
            shares = Number(shares);
            // Convert dividend yield from percentage to decimal
            const decimal_yield = dividend_yield / 100;
            // Calculate the annual dividend per share
            const annual_dividend_per_share = share_price * decimal_yield;
            // Calculate the total annual dividend
            const total_annual_dividend = annual_dividend_per_share * shares;
            // Generate an object with the results
            this.setState({
                done: true,
                annual_dividend_per_share: annual_dividend_per_share.toFixed(2),
                total_annual_dividend: total_annual_dividend.toFixed(2)
            });
        };
        this.state = {
            share_price: 50,
            dividend_yield: 2.5,
            shares: 1000
        };
    }
    render() {
        let { annual_dividend_per_share, total_annual_dividend, share_price, dividend_yield, shares, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Annual Dividend Per Share"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(annual_dividend_per_share)
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Annual Dividend"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(total_annual_dividend)
                            ]
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Share Price"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: share_price,
                                                                onChange: ({ target })=>this.setState({
                                                                        share_price: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Share Price"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Dividend Yield"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Dividend Yield",
                                                                value: dividend_yield,
                                                                onChange: ({ target })=>this.setState({
                                                                        dividend_yield: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Shares"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: shares,
                                                                onChange: ({ target })=>this.setState({
                                                                        shares: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dividend_calculator);


/***/ }),

/***/ 689:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








class FHA_loan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, years, interest } = this.state;
            return principal && years && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal: total_loan_amount, interest, years, upfront_mip_percent, annual_mip_percent } = this.state;
            // Calculate the upfront MIP
            let upfront_mip = total_loan_amount * (upfront_mip_percent / 100);
            // Calculate the monthly interest rate
            let monthly_rate = interest / 1200;
            // Calculate the number of monthly payments
            let num_payments = years * 12;
            // Calculate the base monthly payment
            let base_payment = total_loan_amount * monthly_rate / (1 - 1 / (1 + monthly_rate) ** num_payments);
            // Calculate the annual MIP amount
            let annual_mip = (total_loan_amount + upfront_mip) * (annual_mip_percent / 100);
            // Calculate the total monthly payment
            let total_payment = base_payment + annual_mip / 12;
            // Calculate the total cost of the loan
            let total_cost = total_payment * num_payments;
            // Calculate the amortization schedule
            let amortization_schedule = [];
            let remaining_balance = total_loan_amount;
            for(let i = 1; i <= num_payments; i++){
                let interest_payment = remaining_balance * monthly_rate;
                let principal_payment = base_payment - interest_payment;
                let total_payment = base_payment + annual_mip / 12;
                amortization_schedule.push({
                    payment_number: i,
                    balance: remaining_balance,
                    principal_payment,
                    interest_payment,
                    total_payment
                });
                remaining_balance -= principal_payment;
            }
            // Return an object with the results and the amortization schedule
            this.setState({
                upfront_mip,
                base_payment,
                annual_mip,
                total_payment,
                total_cost,
                amortization_schedule,
                done: true
            });
        };
        this.state = {
            principal: 200000,
            interest: 3.5,
            years: 30,
            upfront_mip_percent: 1.75,
            annual_mip_percent: 0.85,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, years, interest, amortization_schedule, upfront_mip_percent, annual_mip_percent, amortization_table_index, total_cost, base_payment, upfront_mip, annual_mip, total_payment } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Cost"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_cost.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Total Payment"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_payment.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-8 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon my-auto",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Base Payment"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(base_payment.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Upfront MIP"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(upfront_mip.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Annual MIP"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(annual_mip.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Payments",
                                            data: {
                                                labels: [
                                                    "Payments",
                                                    "Base"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            total_payment,
                                                            base_payment
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortization_schedule.map((res)=>res.payment_number),
                                                datasets: [
                                                    {
                                                        label: "Balance",
                                                        data: amortization_schedule.map((res)=>res.balance),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal Payment",
                                                        data: amortization_schedule.map((res)=>res.principal_payment),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    },
                                                    {
                                                        label: "Interest Payment",
                                                        data: amortization_schedule.map((res)=>res.interest_payment),
                                                        borderColor: "rgb(154, 0, 132)",
                                                        backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortization_schedule && amortization_schedule.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortization_schedule[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortization_schedule.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.payment_number
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.principal_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.interest_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.total_payment)
                                                    ]
                                                })
                                            ]
                                        }, entry.payment_number);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortization_schedule.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Term (Years)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Upfront MIP (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Upfront MIP",
                                                                value: upfront_mip_percent,
                                                                onChange: ({ target })=>this.setState({
                                                                        upfront_mip_percent: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Annual MIP (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Annual MIP",
                                                                value: annual_mip_percent,
                                                                onChange: ({ target })=>this.setState({
                                                                        annual_mip_percent: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FHA_loan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


class Hours_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hours_calculator);


/***/ }),

/***/ 426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _text_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1294);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7108);







class Income_tax extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.toggle_advance = ()=>this.setState({
                advanced: !this.state.advanced
            });
        this.is_set = ()=>{
            let { income } = this.state;
            return Number(income) > 0;
        };
        this.taxBrackets = {
            single: [
                {
                    maxIncome: 9875,
                    rate: 0.1
                },
                {
                    maxIncome: 40125,
                    rate: 0.12
                },
                {
                    maxIncome: 85525,
                    rate: 0.22
                },
                {
                    maxIncome: 163300,
                    rate: 0.24
                },
                {
                    maxIncome: 207350,
                    rate: 0.32
                },
                {
                    maxIncome: 518400,
                    rate: 0.35
                },
                {
                    maxIncome: Infinity,
                    rate: 0.37
                }
            ],
            married: [
                {
                    maxIncome: 19750,
                    rate: 0.1
                },
                {
                    maxIncome: 80250,
                    rate: 0.12
                },
                {
                    maxIncome: 171050,
                    rate: 0.22
                },
                {
                    maxIncome: 326600,
                    rate: 0.24
                },
                {
                    maxIncome: 414700,
                    rate: 0.32
                },
                {
                    maxIncome: 622050,
                    rate: 0.35
                },
                {
                    maxIncome: Infinity,
                    rate: 0.37
                }
            ],
            head_of_household: [
                {
                    maxIncome: 14100,
                    rate: 0.1
                },
                {
                    maxIncome: 53700,
                    rate: 0.12
                },
                {
                    maxIncome: 85500,
                    rate: 0.22
                },
                {
                    maxIncome: 163300,
                    rate: 0.24
                },
                {
                    maxIncome: 207350,
                    rate: 0.32
                },
                {
                    maxIncome: 518400,
                    rate: 0.35
                },
                {
                    maxIncome: Infinity,
                    rate: 0.37
                }
            ],
            widow: [
                {
                    maxIncome: 19750,
                    rate: 0.1
                },
                {
                    maxIncome: 80250,
                    rate: 0.12
                },
                {
                    maxIncome: 171050,
                    rate: 0.22
                },
                {
                    maxIncome: 326600,
                    rate: 0.24
                },
                {
                    maxIncome: 414700,
                    rate: 0.32
                },
                {
                    maxIncome: 622050,
                    rate: 0.35
                },
                {
                    maxIncome: Infinity,
                    rate: 0.37
                }
            ],
            married_filing_separately: [
                {
                    maxIncome: 9875,
                    rate: 0.1
                },
                {
                    maxIncome: 40125,
                    rate: 0.12
                },
                {
                    maxIncome: 85525,
                    rate: 0.22
                },
                {
                    maxIncome: 163300,
                    rate: 0.24
                },
                {
                    maxIncome: 207350,
                    rate: 0.32
                },
                {
                    maxIncome: 311025,
                    rate: 0.35
                },
                {
                    maxIncome: Infinity,
                    rate: 0.37
                }
            ]
        };
        this.calculate = ()=>{
            let { income, filing_status, number_of_dependents, deductions, standard_deduction, itemized_deductions, tax_credits, other_taxable_income, state_tax_paid, pre_tax_deductions, pre_tax_contributions, post_tax_deductions } = this.state;
            income = Number(income) || 0;
            filing_status = filing_status || "single";
            deductions = Number(deductions) || 0;
            standard_deduction = Number(standard_deduction) || 0;
            itemized_deductions = Number(itemized_deductions) || 0;
            tax_credits = Number(tax_credits) || 0;
            number_of_dependents = Number(number_of_dependents) || 0;
            post_tax_deductions = Number(post_tax_deductions) || 0;
            pre_tax_contributions = Number(pre_tax_contributions) || 0;
            pre_tax_deductions = Number(pre_tax_deductions) || 0;
            state_tax_paid = Number(state_tax_paid) || 0;
            other_taxable_income = Number(other_taxable_income) || 0;
            // Define tax brackets based on filing status
            let taxBrackets = this.taxBrackets;
            // Determine tax bracket based on income and filing status
            let taxBracket;
            for(let i = 0; i < taxBrackets[filing_status].length; i++){
                if (income > taxBrackets[filing_status][i].maxIncome) {
                    taxBracket = taxBrackets[filing_status][i];
                } else {
                    break;
                }
            }
            if (!taxBracket) taxBracket = taxBrackets[filing_status][0];
            // Calculate tax liability based on income and tax bracket rate
            let tax_liability = (income - taxBracket.maxIncome) * taxBracket.rate;
            for(let i = taxBrackets[filing_status].indexOf(taxBracket) - 1; i >= 0; i--){
                tax_liability += (taxBrackets[filing_status][i + 1].maxIncome - taxBrackets[filing_status][i].maxIncome) * taxBrackets[filing_status][i].rate;
            }
            // Calculate adjusted gross income
            const adjusted_gross_icome = income - (deductions || number_of_dependents * 500 || standard_deduction || itemized_deductions || 0);
            // Calculate taxable income
            const taxable_income = adjusted_gross_icome + other_taxable_income - tax_credits - state_tax_paid;
            // Calculate final tax liability
            const final_tax_liability = Math.max(tax_liability - taxable_income, 0);
            // Calculate total deductions
            const total_deductions = pre_tax_deductions + post_tax_deductions;
            // Calculate total exemptions
            const total_exemptions = number_of_dependents * 500;
            // Calculate marginal tax rate
            const marginal_tax_rate = taxBracket.rate;
            // Calculate tax pre-payments
            const tax_pre_payments = pre_tax_contributions + state_tax_paid;
            this.setState({
                tax_liability,
                adjusted_gross_icome,
                taxable_income,
                final_tax_liability,
                total_deductions,
                total_exemptions,
                marginal_tax_rate,
                tax_pre_payments,
                done: true
            });
        };
        this.state = {};
    }
    render() {
        let { done, income, number_of_dependents, deductions, total_exemptions, tax_liability, taxable_income, final_tax_liability, tax_credits, adjusted_gross_icome, marginal_tax_rate, advanced, total_deductions, other_taxable_income, pre_tax_contributions, post_tax_deductions, pre_tax_deductions, state_tax_paid } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            className: "modal-title text-dark",
                            children: "Calculator"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "login-form",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Income"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "number",
                                                    value: income,
                                                    onChange: ({ target })=>this.setState({
                                                            income: target.value
                                                        }),
                                                    className: "form-control",
                                                    style: {
                                                        fontSize: 16,
                                                        color: "#000"
                                                    },
                                                    placeholder: "Income"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "form-group",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: "Filing Status"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "simple-input",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                    id: "status",
                                                    onChange: ({ target })=>this.setState({
                                                            filing_status: target.value
                                                        }),
                                                    className: "form-control",
                                                    children: Object.keys(this.taxBrackets).map((filing_status)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: filing_status,
                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_6__/* .to_title */ .bk)(filing_status.replace(/_/g, " "))
                                                        }, filing_status))
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-lg-6 col-md-6 col-sm-12",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            children: "Number Of Dependents"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "form-control",
                                                            type: "number",
                                                            placeholder: "Number of Dependents",
                                                            value: number_of_dependents,
                                                            onChange: ({ target })=>this.setState({
                                                                    number_of_dependents: target.value
                                                                })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-lg-6 col-md-6 col-sm-12",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            children: "Deductions"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "form-control",
                                                            type: "number",
                                                            placeholder: "Deductions",
                                                            value: deductions,
                                                            onChange: ({ target })=>this.setState({
                                                                    deductions: target.value
                                                                })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            display: "flex",
                                            alignItems: "center",
                                            marginBottom: 20,
                                            justifyContent: "center"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            action: this.toggle_advance,
                                            style: {
                                                textAlign: "center",
                                                fontWeight: "bold"
                                            },
                                            text: "Advance Options"
                                        })
                                    }),
                                    advanced ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Pre Tax Deductions"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Pre Tax Deductions",
                                                                    value: pre_tax_deductions,
                                                                    onChange: ({ target })=>this.setState({
                                                                            pre_tax_deductions: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Post Tax Deductions"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Post Tax Deductions",
                                                                    value: post_tax_deductions,
                                                                    onChange: ({ target })=>this.setState({
                                                                            post_tax_deductions: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "State Tax Paid"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "State Tax Paid",
                                                                    value: state_tax_paid,
                                                                    onChange: ({ target })=>this.setState({
                                                                            state_tax_paid: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Tax Credits"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Tax Credits",
                                                                    value: tax_credits,
                                                                    onChange: ({ target })=>this.setState({
                                                                            tax_credits: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Pre Tax Contributions"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Pre Tax Contributions",
                                                                    value: pre_tax_contributions,
                                                                    onChange: ({ target })=>this.setState({
                                                                            pre_tax_contributions: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Other Taxable Income"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Other Taxable Income",
                                                                    value: other_taxable_income,
                                                                    onChange: ({ target })=>this.setState({
                                                                            other_taxable_income: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        title: "Calculate",
                                        style: {
                                            backgroundColor: "yellow"
                                        },
                                        action: this.calculate,
                                        disabled: !this.is_set()
                                    }),
                                    done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "crs_grid p-2 py-5 text-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                            style: {
                                                width: "100%",
                                                textAlign: "center"
                                            },
                                            className: "result_table",
                                            bordered: true,
                                            hover: true,
                                            responsive: true,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Tax Liability"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "€ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(tax_liability)
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Taxable Income"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "€ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(taxable_income)
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Adjusted Gross Income"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "€ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(adjusted_gross_icome)
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Final Tax Liability"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "€ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(final_tax_liability)
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Total Deductions"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: total_deductions
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Total Exemptions"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "€ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .E)(total_exemptions)
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                children: "Marginal Tax Rate"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    marginal_tax_rate * 100,
                                                                    " %"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    }) : null
                                ]
                            })
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Income_tax);


/***/ }),

/***/ 1584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Inflation extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate_inflation_rate = ()=>{
            let { initial_value, final_value, num_years } = this.state;
            initial_value = Number(initial_value);
            final_value = Number(final_value);
            num_years = Number(num_years);
            let inflation_rate = (Math.pow(final_value / initial_value, 1 / num_years) - 1) * 100;
            this.setState({
                inflation_rate
            });
        };
        this.adjust_for_inflation = ()=>{
            let { value, num_years_ad, inflation_rate_ad } = this.state;
            value = Number(value);
            num_years_ad = Number(num_years_ad);
            inflation_rate_ad = Number(inflation_rate_ad);
            let adjusted_value = value * Math.pow(1 + inflation_rate_ad / 100, num_years_ad);
            this.setState({
                adjusted_value
            });
        };
        this.state = {
            value: 100,
            initial_value: 100,
            final_value: 150,
            num_years: 5,
            num_years_ad: 5,
            inflation_rate_ad: 8.3
        };
    }
    render() {
        let { inflation_rate, adjusted_value, num_years_ad, inflation_rate_ad, value, initial_value, final_value, num_years } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Calculate Inflation Rate"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "login-form",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Initial Value"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Initial Value",
                                                                    value: initial_value,
                                                                    onChange: ({ target })=>this.setState({
                                                                            initial_value: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Final Value"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Final Value",
                                                                    value: final_value,
                                                                    onChange: ({ target })=>this.setState({
                                                                            final_value: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Number of Years"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Number of Years",
                                                                    value: num_years,
                                                                    onChange: ({ target })=>this.setState({
                                                                            num_years: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Inflation Rate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate_inflation_rate,
                                                disabled: !initial_value || !final_value || !num_years
                                            })
                                        ]
                                    }),
                                    inflation_rate ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "crs_grid p-2 py-5 text-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-center text-dark",
                                                children: "Inflation Rate"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                className: "text-center mb-2",
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(inflation_rate.toFixed(2))
                                                ]
                                            })
                                        ]
                                    }) : null
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Adjust for Inflation"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "login-form",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Value"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Value",
                                                                    value: value,
                                                                    onChange: ({ target })=>this.setState({
                                                                            value: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Number of years"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Number of years",
                                                                    value: num_years_ad,
                                                                    onChange: ({ target })=>this.setState({
                                                                            num_years_ad: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Inflation Rate"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Inflation Rate",
                                                                    value: inflation_rate_ad,
                                                                    onChange: ({ target })=>this.setState({
                                                                            inflation_rate_ad: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.adjust_for_inflation,
                                                disabled: !value || !inflation_rate_ad || !num_years_ad
                                            })
                                        ]
                                    }),
                                    adjusted_value ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "crs_grid p-2 py-5 text-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-center text-dark",
                                                children: "Adjusted Value for Inflation"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                className: "text-center mb-2",
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(adjusted_value.toFixed(2))
                                                ]
                                            })
                                        ]
                                    }) : null
                                ]
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Inflation);


/***/ }),

/***/ 144:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








class Investment_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.index_size = 12;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.is_set = ()=>{
            let { principal, interest_rate, monthly_contribution, num_years } = this.state;
            return principal && interest_rate && monthly_contribution && num_years;
        };
        this.calculate = ()=>{
            let { principal, interest_rate, monthly_contribution, num_years } = this.state;
            principal = Number(principal) || 0;
            interest_rate = Number(interest_rate) || 0;
            monthly_contribution = Number(monthly_contribution) || 0;
            num_years = Number(num_years) || 0;
            let monthly_interest_rate = interest_rate / 1200;
            let num_months = num_years * 12;
            // Calculate total contributions
            let total_contributions = monthly_contribution * num_months + principal;
            // Calculate total interest
            let total_interest = 0;
            let balance = principal;
            for(let i = 0; i < num_months; i++){
                let interest = balance * monthly_interest_rate;
                total_interest += interest;
                balance += monthly_contribution + interest;
            }
            // Calculate monthly payment
            let monthly_payment = principal * monthly_interest_rate * Math.pow(1 + monthly_interest_rate, num_months) / (Math.pow(1 + monthly_interest_rate, num_months) - 1);
            // Generate amortization table
            let amortization_table = [];
            let remaining_balance = principal;
            for(let i = 0; i < num_months; i++){
                let interest = remaining_balance * monthly_interest_rate;
                let principal_payment = monthly_payment - interest;
                remaining_balance -= principal_payment;
                amortization_table.push({
                    month: i + 1,
                    balance: remaining_balance,
                    principal_payment,
                    interest_payment: interest,
                    total_payment: monthly_payment
                });
            }
            this.setState({
                total_contributions,
                total_interest,
                amortization_table,
                ending_balance: amortization_table.slice(-1)[0].balance,
                done: true
            });
        };
        this.state = {
            principal: 20000,
            monthly_contribution: 1000,
            num_years: 10,
            interest_rate: 6,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, interest_rate, total_interest, total_contributions, monthly_contribution, num_years, amortization_table, amortization_table_index, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Contributions"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_contributions.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Total Interest"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_interest.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Total Payments",
                                            data: {
                                                labels: [
                                                    "Principal",
                                                    "Interest"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            total_contributions,
                                                            total_interest
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortization_table.map((res)=>res.month),
                                                datasets: [
                                                    {
                                                        label: "Interest Payment",
                                                        data: amortization_table.map((res)=>res.interest_payment),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal Payment",
                                                        data: amortization_table.map((res)=>res.principal_payment),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortization_table && amortization_table.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortization_table[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("th", {
                                                colSpan: 5,
                                                style: {
                                                    textAlign: "center"
                                                },
                                                children: [
                                                    "Year ",
                                                    1
                                                ]
                                            })
                                        }),
                                        amortization_table.slice(0, amortization_table_index).map((entry)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: entry.month
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "$ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.balance)
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "$ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.principal_payment)
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "$ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.interest_payment)
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                children: [
                                                                    "$ ",
                                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.total_payment)
                                                                ]
                                                            })
                                                        ]
                                                    }, entry.month),
                                                    entry.month % 12 === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("th", {
                                                            style: {
                                                                textAlign: "center"
                                                            },
                                                            colSpan: 5,
                                                            children: [
                                                                "Year ",
                                                                entry.month / 12 + 1
                                                            ]
                                                        })
                                                    }) : null
                                                ]
                                            });
                                        })
                                    ]
                                })
                            ]
                        }),
                        amortization_table_index < amortization_table.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Principal"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        value: principal,
                                                        onChange: ({ target })=>this.setState({
                                                                principal: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Principal"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Monthly Contributions"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        value: monthly_contribution,
                                                        onChange: ({ target })=>this.setState({
                                                                monthly_contribution: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Monthly Contribution"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest Rate"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest Rate",
                                                                value: interest_rate,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest_rate: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Number Of Years"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Number Of Years",
                                                                value: num_years,
                                                                onChange: ({ target })=>this.setState({
                                                                        num_years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Investment_calculator);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4449:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Lean_body_mass extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { weight, body_fat_percentage } = this.state;
            return weight && body_fat_percentage;
        };
        this.calculate = ()=>{
            let { weight, body_fat_percentage } = this.state;
            weight = Number(weight);
            body_fat_percentage = Number(body_fat_percentage);
            // Calculate lean body mass
            let lean_body_mass = weight * (1 - body_fat_percentage / 100);
            // Round to two decimal places
            lean_body_mass = Math.round(lean_body_mass * 100) / 100;
            this.setState({
                lean_body_mass,
                done: true
            });
        };
        this.state = {
            weight: 70,
            body_fat_percentage: 1.75
        };
    }
    render() {
        let { weight, body_fat_percentage, lean_body_mass, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Lean Body Mass"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-center mb-2",
                                children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(lean_body_mass.toFixed(2))
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Weight"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Body Fat Percentage (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: body_fat_percentage,
                                                                onChange: ({ target })=>this.setState({
                                                                        body_fat_percentage: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Body Fat Percentage"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Lean_body_mass);


/***/ }),

/***/ 9831:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4374);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_2__]);
_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



class Loan_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_morgage_loan_repayment__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {});
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loan_calculator);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Margin_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { revenue, cost } = this.state;
            return revenue && cost;
        };
        this.calculate = ()=>{
            let { revenue, cost } = this.state;
            revenue = Number(revenue);
            cost = Number(cost);
            let profit = revenue - cost;
            let margin = profit / revenue * 100;
            this.setState({
                margin,
                done: true
            });
        };
        this.state = {
            revenue: 1500,
            cost: 1000
        };
    }
    render() {
        let { revenue, cost, margin, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Profit Margin"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "text-center mb-2",
                                children: [
                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(margin.toFixed(2)),
                                    "%"
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Revenue"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: revenue,
                                                                onChange: ({ target })=>this.setState({
                                                                        revenue: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Revenue"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Cost"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: cost,
                                                                onChange: ({ target })=>this.setState({
                                                                        cost: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Cost"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Margin_calculator);


/***/ }),

/***/ 654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _alert_box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5589);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);




class Mean_squared_error extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.handle_numbers = ({ target }, type)=>{
            let numbers = target.value;
            numbers = numbers.replace(/ /g, ",").split(",");
            numbers = numbers.filter((n, i)=>{
                if (!n && i + 1 !== numbers.length) return;
                n = Number(n);
                if (!n && n !== 0) return false;
                return true;
            });
            this.setState({
                [type]: numbers.join(","),
                message: ""
            });
        };
        this.calculate = ()=>{
            let { actual_data, predicted_data } = this.state;
            actual_data = actual_data.split(",").map((n)=>Number(n));
            predicted_data = predicted_data.split(",").map((n)=>Number(n));
            if (actual_data.length !== predicted_data.length) return this.setState({
                message: "Data must have the same length"
            });
            let squared_errors = actual_data.map((val, i)=>(val - predicted_data[i]) ** 2);
            let mse = squared_errors.reduce((acc, val)=>acc + val, 0) / actual_data.length;
            this.setState({
                mse,
                done: true,
                message: ""
            });
        };
        this.state = {
            predicted_data: "5,10,15,20,25",
            actual_data: "6,11,14,18,27"
        };
    }
    render() {
        let { actual_data, predicted_data, done, mse, message } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Basic Statistics"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "login-form",
                                children: [
                                    message ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_box__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        message: message,
                                        type: "info"
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Actual Data"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Actual Data",
                                                                value: actual_data,
                                                                onChange: (e)=>this.handle_numbers(e, "actual_data")
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Predicted Data"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Predicted Data",
                                                                value: predicted_data,
                                                                onChange: (e)=>this.handle_numbers(e, "predicted_data")
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                disabled: !actual_data || !predicted_data,
                                                title: "Calculate",
                                                action: this.calculate
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Mean Squared Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: mse
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Mean_squared_error);


/***/ }),

/***/ 2094:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);





class Measurement_converter extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.units = new Array("cup", "tablespoon", "teaspoon");
        this.is_set = ()=>{
            let { value, from } = this.state;
            return value && from;
        };
        this.calculate = ()=>{
            let { value, from, to } = this.state;
            value = Number(value);
            let teaspoon_per_tablespoon = 3;
            let tablespoon_per_cup = 16;
            // Convert everything to teaspoons
            let teaspoons;
            switch(from){
                case "teaspoon":
                    teaspoons = value;
                    break;
                case "tablespoon":
                    teaspoons = value * teaspoon_per_tablespoon;
                    break;
                case "cup":
                    teaspoons = value * tablespoon_per_cup * teaspoon_per_tablespoon;
                    break;
                default:
                    throw new Error('Invalid "from" from');
            }
            // Convert teaspoons to the desired from
            let result;
            switch(to){
                case "teaspoon":
                    result = teaspoons;
                    break;
                case "tablespoon":
                    result = teaspoons / teaspoon_per_tablespoon;
                    break;
                case "cup":
                    result = teaspoons / (teaspoon_per_tablespoon * tablespoon_per_cup);
                    break;
                default:
                    throw new Error('Invalid "to" from');
            }
            this.setState({
                result,
                done: true
            });
        };
        this.state = {
            value: 15,
            from: this.units[0],
            to: this.units[2]
        };
    }
    render() {
        let { value, result, from, to, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "text-center mb-2",
                                children: [
                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(result.toFixed(2)),
                                    " ",
                                    from
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                children: [
                                                                    "Value in (",
                                                                    from,
                                                                    ")"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: value,
                                                                onChange: ({ target })=>this.setState({
                                                                        value: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Value"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "From"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "from",
                                                                    defaultValue: from,
                                                                    onChange: ({ target })=>this.setState({
                                                                            from: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((from)=>from === to ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: from,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(from)
                                                                        }, from))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "To"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "to",
                                                                    defaultValue: to,
                                                                    onChange: ({ target })=>this.setState({
                                                                            to: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((to)=>to === from ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: to,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(to)
                                                                        }, to))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Measurement_converter);


/***/ }),

/***/ 7617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);





class Measurement_to_weight extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.units = new Array("cup", "tablespoon", "teaspoon");
        this.is_set = ()=>{
            let { amount, unit } = this.state;
            return amount && unit;
        };
        this.calculate = ()=>{
            let { amount, unit } = this.state;
            amount = Number(amount);
            let grams;
            switch(unit){
                case "cup":
                    grams = amount * 236.59;
                    break;
                case "tablespoon":
                    grams = amount * 14.79;
                    break;
                case "teaspoon":
                    grams = amount * 4.93;
                    break;
                default:
                    grams = 0;
            }
            this.setState({
                grams,
                done: true
            });
        };
        this.state = {
            amount: 150,
            unit: this.units[0]
        };
    }
    render() {
        let { amount, unit, grams, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Weight in Grams"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "text-center mb-2",
                                children: [
                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(grams.toFixed(2)),
                                    " grams"
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                children: [
                                                                    "Amount in (",
                                                                    unit,
                                                                    ")"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: amount,
                                                                onChange: ({ target })=>this.setState({
                                                                        amount: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Amount"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "bank",
                                                                    defaultValue: unit,
                                                                    onChange: ({ target })=>this.setState({
                                                                            unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(unit)
                                                                        }, unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Measurement_to_weight);


/***/ }),

/***/ 4374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








class Morgage_loan_repayment extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.is_set = ()=>{
            let { principal, duration, interest } = this.state;
            return principal && duration && interest;
        };
        this.payment_intervals = new Array("monthly", "quarterly", "yearly");
        this.intervals_et_number_of_annual_payments = new Object({
            [this.payment_intervals[0]]: 12,
            [this.payment_intervals[1]]: 4,
            [this.payment_intervals[2]]: 1
        });
        this.month = 60 * 60 * 24 * 30 * 1000;
        this.commalise_figures = (value)=>{
            let integer = Math.floor(value);
            let decimal = (value - integer).toFixed(2).toString();
            let commalised = (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .commalise_figures */ .Ew)(integer);
            return `${commalised}${decimal.slice(decimal.indexOf("."))}`;
        };
        this.calculate = ()=>{
            let { principal: loan_amount, duration: loan_term, interest: interest_rate, interval } = this.state;
            let payments_per_year = this.intervals_et_number_of_annual_payments[interval];
            loan_amount = Number(loan_amount);
            loan_term = Number(loan_term);
            interest_rate = Number(interest_rate);
            let total_payments = loan_term * payments_per_year;
            let monthly_interest_rate = interest_rate / 100 / payments_per_year;
            let discount_factor = ((1 + monthly_interest_rate) ** total_payments - 1) / (monthly_interest_rate * (1 + monthly_interest_rate) ** total_payments);
            let monthly_payment = loan_amount / discount_factor;
            let balance = loan_amount, total_interest = 0;
            let amortization_table = [];
            for(let i = 0; i < total_payments; i++){
                let interest_payment = balance * monthly_interest_rate;
                let principal_payment = monthly_payment - interest_payment;
                balance -= principal_payment;
                total_interest += interest_payment;
                amortization_table.push({
                    payment_number: i + 1,
                    balance: balance.toFixed(2),
                    principal_payment: principal_payment.toFixed(2),
                    interest_payment: interest_payment.toFixed(2),
                    total_payment: monthly_payment.toFixed(2)
                });
            }
            let total_morgage_repayment = amortization_table.length * monthly_payment;
            let end_date = Date.now();
            let n = total_morgage_repayment / monthly_payment;
            end_date += n * (12 / payments_per_year) * this.month;
            this.setState({
                repayment: monthly_payment,
                amortization_table,
                total_morgage_repayment,
                total_interest,
                end_date
            }, _footer__WEBPACK_IMPORTED_MODULE_6__/* .scroll_to_top */ .kH);
        };
        this.state = {
            principal: 400000,
            interest: 5,
            duration: 30,
            interval: this.payment_intervals[0],
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, duration, interval, interest, end_date, total_morgage_repayment, total_interest, repayment, amortization_table, amortization_table_index } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                total_morgage_repayment ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                            className: "text-center text-dark",
                            children: [
                                interval,
                                " payment"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                this.commalise_figures(repayment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-8 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon my-auto",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        "Total of ",
                                                        parseInt(amortization_table.length),
                                                        " Payments"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: this.commalise_figures(total_morgage_repayment.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Total Interest"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: this.commalise_figures(total_interest.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "End Date"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        value: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .date_string */ .Rd)(end_date).slice(3),
                                        className: "form-control",
                                        style: {
                                            fontSize: 16,
                                            color: "#000",
                                            textAlign: "center"
                                        },
                                        disabled: true
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Total Payments",
                                            data: {
                                                labels: [
                                                    "Principal",
                                                    "Interest"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            principal,
                                                            total_interest
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortization_table.map((res)=>res.payment_number),
                                                datasets: [
                                                    {
                                                        label: "Balance",
                                                        data: amortization_table.map((res)=>res.balance),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal Payment",
                                                        data: amortization_table.map((res)=>res.principal_payment),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    },
                                                    {
                                                        label: "Interest Payment",
                                                        data: amortization_table.map((res)=>res.interest_payment),
                                                        borderColor: "rgb(154, 0, 132)",
                                                        backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortization_table && amortization_table.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortization_table[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortization_table.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.payment_number
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        this.commalise_figures(entry.balance)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$",
                                                        " ",
                                                        this.commalise_figures(entry.principal_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$",
                                                        " ",
                                                        this.commalise_figures(entry.interest_payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        this.commalise_figures(entry.total_payment)
                                                    ]
                                                })
                                            ]
                                        }, entry.payment_number);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortization_table.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Loan Amount"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        value: principal,
                                                        onChange: ({ target })=>this.setState({
                                                                principal: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Principal"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Term (Years)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: duration,
                                                                onChange: ({ target })=>this.setState({
                                                                        duration: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Payment Intervals"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "simple-input",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                        id: "bank",
                                                        onChange: ({ target })=>this.setState({
                                                                interval: target.value
                                                            }),
                                                        className: "form-control",
                                                        children: this.payment_intervals.map((interval)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: interval,
                                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(interval.replace(/_/g, " "))
                                                            }, interval))
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Morgage_loan_repayment);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2357:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);



class Ovulation_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate = ()=>{
            let { cycle_length, last_period_date } = this.state;
            cycle_length = Number(cycle_length);
            last_period_date = new Date(last_period_date);
            // Calculate the ovulation date
            let ovulation_date = new Date(last_period_date.getTime() + (cycle_length - 14) * 24 * 60 * 60 * 1000);
            this.setState({
                ovulation_date,
                done: true
            });
        };
        let d = new Date();
        this.state = {
            last_period_date: `${d.getDate()}-${d.getMonth() + 1}-${d.getFullYear()}`,
            cycle_length: 28
        };
    }
    render() {
        let { cycle_length, done, ovulation_date, last_period_date } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center mt-2 text-dark",
                            children: "Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Your next ovulation date is "
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: `${ovulation_date.toDateString()}`
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Pregnancy Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Last Period Date"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "date",
                                                        value: last_period_date,
                                                        onChange: ({ target })=>this.setState({
                                                                last_period_date: target.value,
                                                                done: false
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Last period date"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Cycle Length"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        value: cycle_length,
                                                        onChange: ({ target })=>this.setState({
                                                                cycle_length: target.value,
                                                                done: false
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Cycle Length"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Ovulation_calculator);


/***/ }),

/***/ 3176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7108);




class Pace_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.kilo = 1.609;
        this.calculate = ()=>{
            let { distance, hours, minutes, seconds, distance_unit } = this.state;
            distance = Number(distance);
            hours = Number(hours);
            minutes = Number(minutes);
            seconds = Number(seconds);
            if (distance_unit === this.distances[0]) distance /= this.kilo;
            let total_minutes = hours * 60 + minutes + seconds / 60;
            let pace = total_minutes / distance;
            let pace_minutes = Math.floor(pace);
            let pace_seconds = Math.round((pace - pace_minutes) * 60);
            this.setState({
                result: {
                    minute: pace_minutes,
                    second: pace_seconds
                },
                done: true
            });
        };
        this.distances = new Array("kilometer", "miles");
        this.state = {
            distance: 3.1,
            distance_unit: this.distances[0],
            hours: 0,
            minutes: 23,
            seconds: 10
        };
    }
    render() {
        let { distance, hours, minutes, distance_unit, seconds, done, result } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Pace Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                children: [
                                                                    "Distance (",
                                                                    distance_unit,
                                                                    ")"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Distance",
                                                                value: distance,
                                                                onChange: ({ target })=>this.setState({
                                                                        distance: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "activity",
                                                                    onChange: ({ target })=>this.setState({
                                                                            distance_unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.distances.map((distance_unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: distance_unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .to_title */ .bk)(distance_unit.replace(/_/g, " "))
                                                                        }, distance_unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-4 col-md-4 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Hours"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "0",
                                                                placeholder: "Hours",
                                                                value: hours,
                                                                onChange: ({ target })=>this.setState({
                                                                        hours: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-4 col-md-4 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Minutes"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Minutes",
                                                                min: "0",
                                                                max: "59",
                                                                value: minutes,
                                                                onChange: ({ target })=>this.setState({
                                                                        minutes: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-4 col-md-4 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Seconds"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "0",
                                                                max: "59",
                                                                placeholder: "Seconds",
                                                                value: seconds,
                                                                onChange: ({ target })=>this.setState({
                                                                        seconds: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Summary"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: `${result.minute}:${result.second < 10 ? "0" : ""}${result.second} per ${distance_unit}`
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Which means you are running each ",
                                distance_unit,
                                " in",
                                " ",
                                result.minute,
                                " minutes and ",
                                result.second,
                                " seconds."
                            ]
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pace_calculator);


/***/ }),

/***/ 4711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7108);




let _lalpha = "abcdefghijklmnopqrstuvwxyz", _ualpha = _lalpha.toUpperCase(), _digits = "0123456789", _symbols = "'~!@#$%^&*()_+{}|\":?><`[];'/.,";
class Password_generator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.lengths = ".".repeat(32).split("").map((x, i)=>i + 1);
        this.generate = (e)=>{
            let { lower_case, upper_case, digits, symbols, pass_length } = this.state;
            if (!upper_case && !lower_case && !digits && !symbols) {
                digits = true;
                lower_case = true;
            }
            let wholeset = "";
            if (lower_case) wholeset += _lalpha;
            if (upper_case) wholeset += _ualpha;
            if (digits) wholeset += _digits;
            if (symbols) wholeset += _symbols;
            let random_value = "";
            for(let i = 0; i < (pass_length || 8); i++){
                let index = (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .gen_random_int */ .Yl)(wholeset.length);
                if (index === wholeset.length) index--;
                random_value += wholeset[index];
            }
            this.setState({
                password: random_value
            });
        };
        this.state = {
            pass_length: 8,
            lower_case: true
        };
    }
    render() {
        let { pass_length, lower_case, upper_case, digits, symbols, password } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Password Generator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Password Length"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "length",
                                                                    defaultValue: pass_length,
                                                                    onChange: ({ target })=>this.setState({
                                                                            pass_length: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.lengths.map((l)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: l,
                                                                            children: l
                                                                        }, l))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "form-group",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            onClick: ()=>this.setState({
                                                                    lower_case: !lower_case
                                                                }),
                                                            className: "form-group smalls",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "lowercase",
                                                                    className: "checkbox-custom",
                                                                    name: "lowercase",
                                                                    disabled: true,
                                                                    type: "checkbox",
                                                                    checked: lower_case
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    for: "lowercase",
                                                                    className: "checkbox-custom-label",
                                                                    children: "Lowercase letters [abcdefghijkmnpqrstuvwxyz]"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "form-group",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            onClick: ()=>this.setState({
                                                                    upper_case: !upper_case
                                                                }),
                                                            className: "form-group smalls",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "uppercase",
                                                                    className: "checkbox-custom",
                                                                    name: "uppercase",
                                                                    disabled: true,
                                                                    type: "checkbox",
                                                                    checked: upper_case
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    for: "uppercase",
                                                                    className: "checkbox-custom-label",
                                                                    children: "Uppercase letters [ABCDEFGHJKLMNPQRSTUVWXYZ]"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "form-group",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            onClick: ()=>this.setState({
                                                                    digits: !digits
                                                                }),
                                                            className: "form-group smalls",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "digits",
                                                                    className: "checkbox-custom",
                                                                    name: "digits",
                                                                    disabled: true,
                                                                    type: "checkbox",
                                                                    checked: digits
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    for: "digits",
                                                                    className: "checkbox-custom-label",
                                                                    children: "Digits [23456789]"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "form-group",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            onClick: ()=>this.setState({
                                                                    symbols: !symbols
                                                                }),
                                                            className: "form-group smalls",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "symbols",
                                                                    className: "checkbox-custom",
                                                                    name: "symbols",
                                                                    disabled: true,
                                                                    type: "checkbox",
                                                                    checked: symbols
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    for: "symbols",
                                                                    className: "checkbox-custom-label",
                                                                    children: "Symbols [!#$%&()*+-=?[]|~@^_]"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.generate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                password ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Password"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            style: {
                                textTransform: "none"
                            },
                            children: password
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Password_generator);


/***/ }),

/***/ 9667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);



class Percentage extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate_percentage = ()=>{
            let { amount, total } = this.state;
            amount = Number(amount);
            total = Number(total);
            if (typeof amount !== "number" || typeof total !== "number") {
                throw new Error("Both arguments must be numbers.");
            }
            if (total === 0) return 0;
            this.setState({
                percentage: (amount / total * 100).toFixed(2),
                done1: true
            });
        };
        this.calculate_percentage_of = ()=>{
            let { percent, total_of } = this.state;
            percent = Number(percent);
            total_of = Number(total_of);
            if (typeof percent !== "number" || typeof total_of !== "number") {
                throw new Error("Both arguments must be numbers.");
            }
            this.setState({
                percentage_of: (percent / 100).toFixed(2) * total_of,
                done3: true
            });
        };
        this.calculate_difference = ()=>{
            let { num1, num2 } = this.state;
            num1 = Number(num1);
            num2 = Number(num2);
            let difference = Math.abs(num1 - num2);
            let average = (num1 + num2) / 2;
            let percentage_diff = difference / average * 100;
            this.setState({
                difference: percentage_diff.toFixed(2),
                done2: true
            });
        };
        this.render = ()=>{
            let { amount, num1, num2, total, difference, percentage, done1, done3, percent, percentage_of, total_of, done2 } = this.state;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "modal-title text-dark",
                                    children: "Percentage"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "login-form",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Amount"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Amount",
                                                                    value: amount,
                                                                    onChange: ({ target })=>this.setState({
                                                                            amount: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Total"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Total",
                                                                    value: total,
                                                                    onChange: ({ target })=>this.setState({
                                                                            total: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate_percentage
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    done1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid p-2 py-5 text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-center mb-2",
                                children: `${percentage}%`
                            })
                        ]
                    }) : null,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "modal-title text-dark",
                                    children: "Percentage of"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "login-form",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Percentage (%)"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Percentage",
                                                                    value: percent,
                                                                    onChange: ({ target })=>this.setState({
                                                                            percent: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Total"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Total",
                                                                    value: total_of,
                                                                    onChange: ({ target })=>this.setState({
                                                                            total_of: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate_percentage_of
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    done3 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid p-2 py-5 text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-center mb-2",
                                children: `${percentage_of}`
                            })
                        ]
                    }) : null,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "modal-title text-dark",
                                    children: "Percentage Difference"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "login-form",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Value 1"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Value 1",
                                                                    value: num1,
                                                                    onChange: ({ target })=>this.setState({
                                                                            num1: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Value 2"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Value 2",
                                                                    value: num2,
                                                                    onChange: ({ target })=>this.setState({
                                                                            num2: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate_difference
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    done2 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid p-2 py-5 text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-center mb-2",
                                children: `${difference}%`
                            })
                        ]
                    }) : null
                ]
            });
        };
        this.state = {
            amount: 75,
            total: 100,
            num1: 240,
            num2: 160,
            percent: 40,
            total_of: 400
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Percentage);


/***/ }),

/***/ 9472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _line_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6558);
/* harmony import */ var _pie_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5799);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7108);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__]);
([_line_charts__WEBPACK_IMPORTED_MODULE_3__, _pie_chart__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









class Personal_loan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { principal, years, interest } = this.state;
            return principal && years && interest;
        };
        this.index_size = 25;
        this.load_more = ()=>{
            let { amortization_table_index } = this.state;
            amortization_table_index += this.index_size;
            this.setState({
                amortization_table_index
            });
        };
        this.calculate = ()=>{
            let { principal, years, interest } = this.state;
            principal = Number(principal);
            years = Number(years);
            interest = Number(interest);
            // Convert interest rate from percentage to decimal
            let decimal_rate = interest / 100;
            // Calculate the number of months in the loan term
            let months = years * 12;
            // Calculate the monthly interest rate
            let monthly_rate = decimal_rate / 12;
            // Calculate the monthly payment
            let monthly_payment = principal * monthly_rate / (1 - (1 + monthly_rate) ** -months);
            // Round the monthly payment to two decimal places
            let monthly_payment_rounded = Math.round(monthly_payment * 100) / 100;
            // Calculate the total amount paid
            let total_paid = monthly_payment_rounded * months;
            // Calculate the total interest paid
            let total_interest = total_paid - principal;
            // Create an empty array to hold the amortization schedule
            let amortisation_schedule = new Array();
            // Initialize the balance to the principal
            let balance = principal;
            // Loop through each month and calculate the payment, interest, and new balance
            for(let i = 1; i <= months; i++){
                let interest = balance * monthly_rate;
                let payment = monthly_payment_rounded;
                let principal_paid = payment - interest;
                balance -= principal_paid;
                balance = Math.round(balance * 100) / 100;
                // Add the current month's data to the amortization schedule array
                amortisation_schedule.push({
                    month: i,
                    payment,
                    principal_paid,
                    interest_paid: interest,
                    balance
                });
            }
            // Generate an object with the results
            this.setState({
                monthly_payment: monthly_payment_rounded,
                total_paid,
                total_interest,
                amortisation_schedule,
                done: true
            }, _footer__WEBPACK_IMPORTED_MODULE_8__/* .scroll_to_top */ .kH);
        };
        this.state = {
            principal: 10000,
            interest: 5,
            years: 3,
            amortization_table_index: this.index_size
        };
    }
    render() {
        let { principal, done, years, interest, monthly_payment, amortisation_schedule, amortization_table_index, total_paid, total_interest } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Monthly Payment"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(monthly_payment.toFixed(2))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-8 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon my-auto",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    children: [
                                                        "Total of ",
                                                        parseInt(amortisation_schedule.length),
                                                        " Payments"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_paid.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "form-group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "input-with-icon",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Total Interest"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "form-control",
                                                    value: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(total_interest.toFixed(2)),
                                                    disabled: true,
                                                    style: {
                                                        backgroundColor: "#fff",
                                                        color: "#000"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    class: "fa fa",
                                                    style: {
                                                        marginTop: 15
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000"
                                                        },
                                                        children: "$"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                            style: {
                                marginTop: 40,
                                marginBottom: 40
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
                                style: {
                                    textAlign: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pie_chart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: "Total Payments",
                                            data: {
                                                labels: [
                                                    "Principal",
                                                    "Interest"
                                                ],
                                                datasets: [
                                                    {
                                                        label: "Amount",
                                                        data: [
                                                            principal,
                                                            total_interest
                                                        ],
                                                        backgroundColor: [
                                                            "rgba(54, 162, 235, 0.2)",
                                                            "rgba(255, 99, 132, 0.2)"
                                                        ],
                                                        borderColor: [
                                                            "rgba(54, 162, 235, 1)",
                                                            "rgba(255, 99, 132, 1)"
                                                        ],
                                                        borderWidth: 1
                                                    }
                                                ]
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                                        md: 8,
                                        sm: 12,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_line_charts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Figures Trend",
                                            data: {
                                                labels: amortisation_schedule.map((res)=>res.payment_number),
                                                datasets: [
                                                    {
                                                        label: "Balance",
                                                        data: amortisation_schedule.map((res)=>res.balance),
                                                        borderColor: "rgb(53, 162, 235)",
                                                        backgroundColor: "rgba(53, 162, 235, 0.5)"
                                                    },
                                                    {
                                                        label: "Principal Payment",
                                                        data: amortisation_schedule.map((res)=>res.principal_paid),
                                                        borderColor: "rgb(255, 99, 132)",
                                                        backgroundColor: "rgba(255, 99, 132, 0.5)"
                                                    },
                                                    {
                                                        label: "Interest Payment",
                                                        data: amortisation_schedule.map((res)=>res.interest_paid),
                                                        borderColor: "rgb(154, 0, 132)",
                                                        backgroundColor: "rgba(154, 0, 132, 0.5)"
                                                    }
                                                ]
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                amortisation_schedule && amortisation_schedule.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                        children: Object.keys(amortisation_schedule[0]).map((k)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_7__/* .to_title */ .bk)(k.replace(/_/g, " "))
                                            }, k))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: amortisation_schedule.slice(0, amortization_table_index).map((entry)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: entry.month
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.payment)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.principal_paid)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.interest_paid)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_6__/* .commalise_figures */ .E)(entry.balance)
                                                    ]
                                                })
                                            ]
                                        }, entry.month);
                                    })
                                })
                            ]
                        }),
                        amortization_table_index < amortisation_schedule.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: "Load More",
                            action: this.load_more
                        }) : null
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: principal,
                                                                onChange: ({ target })=>this.setState({
                                                                        principal: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Principal"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Loan Term (Years)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Duration",
                                                                value: years,
                                                                onChange: ({ target })=>this.setState({
                                                                        years: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest",
                                                                value: interest,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Personal_loan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9071:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);
/* harmony import */ var _assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(487);






class Pregnancy_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.milestones = [
            {
                week: 4,
                milestone: "Embryo is implanted in the uterus",
                flag: ""
            },
            {
                week: 8,
                milestone: "Fetus has a regular heartbeat",
                flag: ""
            },
            {
                week: 12,
                milestone: "Fetus has all body parts and can swallow and urinate",
                flag: ""
            },
            {
                week: 16,
                milestone: "Sex of fetus can be determined",
                flag: ""
            },
            {
                week: 20,
                milestone: "Fetus can hear and has hair on head",
                flag: ""
            },
            {
                week: 24,
                milestone: "Fetus can survive outside the womb with medical assistance",
                flag: ""
            },
            {
                week: 28,
                milestone: "Fetus has a good chance of survival if born prematurely",
                flag: ""
            },
            {
                week: 32,
                milestone: "Fetus is fully developed and can open and close eyes",
                flag: ""
            },
            {
                week: 36,
                milestone: "Fetus is gaining weight and losing lanugo hair",
                flag: ""
            },
            {
                week: 40,
                milestone: "Due date - Fetus is fully mature and ready to be born",
                flag: ""
            }
        ];
        this.milestone_calculations = (weeks)=>{
            let milestones = new Array(...this.milestones);
            // Set flag for current milestone
            let current_milestone = "";
            for(let i = 0; i < milestones.length; i++){
                if (weeks < milestones[i].week) {
                    milestones[i].flag = "*";
                    break;
                } else if (i === milestones.length - 1) {
                    milestones[i].flag = "*";
                    current_milestone = milestones[i].milestone;
                }
            }
            // Create chart of pregnancy milestones
            let chart = milestones.reduce((acc, { week, milestone, flag })=>{
                acc += `Week ${week}: ${milestone}${flag}\n`;
                return acc;
            }, "");
            return {
                current_milestone,
                chart
            };
        };
        this.calculate_from_due_date = ()=>{
            let { due_date } = this.state;
            due_date = new Date(due_date);
            // Calculate last period date
            let last_period = new Date(due_date.getTime() - this.gestation_period);
            // Calculate pregnancy period
            let now = new Date();
            let weeks = Math.floor((now - last_period) / this.a_week);
            let days = Math.floor((now - last_period) / (24 * 60 * 60 * 1000)) - weeks * 7;
            // Calculate pregnancy milestones
            let current_milestone;
            let chart = this.milestones.reduce((acc, { week, milestone })=>{
                let milestone_week = Math.floor((due_date - last_period) / this.a_week);
                if (milestone_week >= week) {
                    if (!current_milestone) current_milestone = milestone_week;
                    acc += `Week ${week}: ${milestone}\n`;
                }
                return acc;
            }, "");
            this.setState({
                period: {
                    weeks,
                    days
                },
                milestones: chart,
                current_milestone,
                last_period_date: last_period,
                done: true
            });
        };
        this.gestation_period = 280 * 24 * 60 * 60 * 1000;
        this.calculate_from_conception_date = ()=>{
            let { conception_date } = this.state;
            conception_date = new Date(conception_date);
            let last_period = new Date(conception_date.getTime() - 266 * 24 * 60 * 60 * 1000);
            let due_date = new Date(conception_date.getTime() + this.gestation_period);
            // Calculate pregnancy period
            let now = new Date();
            let weeks = Math.floor((now - conception_date) / this.a_week);
            let days = Math.floor((now - conception_date) / (24 * 60 * 60 * 1000)) - weeks * 7;
            let chart = this.milestones.reduce((acc, { week, milestone })=>{
                let milestone_weeks = Math.floor((now - conception_date) / this.a_week);
                if (milestone_weeks >= week) {
                    acc += `Week ${week}: ${milestone}\n`;
                }
                return acc;
            }, "");
            this.setState({
                period: {
                    weeks,
                    days
                },
                // current_milestone,
                milestones: chart,
                due_date,
                done: true
            });
        };
        this.a_week = 7 * 24 * 60 * 60 * 1000;
        this.calculate_from_last_period = ()=>{
            let { last_period } = this.state;
            last_period = new Date(last_period);
            // Calculate due date
            let due_date = new Date(last_period.getTime() + this.gestation_period);
            // Calculate pregnancy period
            let now = new Date();
            let weeks = Math.floor((now - last_period) / this.a_week);
            let days = Math.floor((now - last_period) / (24 * 60 * 60 * 1000)) - weeks * 7;
            // Calculate pregnancy milestones
            let { chart, current_milestone } = this.milestone_calculations(weeks);
            // Return pregnancy period, current milestone, and chart of milestones
            this.setState({
                period: {
                    weeks,
                    days
                },
                current_milestone,
                milestones: chart,
                due_date,
                done: true
            });
        };
        this.calculations = new Array("due_date", "conception_date", "last_period");
        this.state = {
            calculator: this.calculations[0]
        };
    }
    render() {
        let { calculator, period, done, last_period_date, due_date } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Pregnancy Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Calculate By"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "simple-input",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                            id: "bank",
                                                            onChange: ({ target })=>this.setState({
                                                                    calculator: target.value
                                                                }),
                                                            className: "form-control",
                                                            children: this.calculations.map((calculator)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                    value: calculator,
                                                                    children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(calculator.replace(/_/g, " "))
                                                                }, calculator))
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "form-group",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(calculator.replace(/_/g, " "))
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "date",
                                                            value: this.state[calculator],
                                                            onChange: ({ target })=>this.setState({
                                                                    [calculator]: target.value,
                                                                    last_period_date: null,
                                                                    done: false
                                                                }),
                                                            className: "form-control",
                                                            style: {
                                                                fontSize: 16,
                                                                color: "#000"
                                                            },
                                                            placeholder: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .to_title */ .bk)(calculator.replace(/_/g, " "))
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this[`calculate_from_${calculator}`]
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        last_period_date ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-center text-dark",
                                    children: "Last Period"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-center mb-2",
                                    children: `${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .dow_index */ .j2[new Date(last_period_date).getDay() + 1]}, ${new Date(last_period_date).getDate()} ${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .month_index */ .Mf[new Date(last_period_date).getMonth()]} ${new Date(last_period_date).getFullYear()}`
                                })
                            ]
                        }) : null,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center mt-2 text-dark",
                            children: "Pregnancy Period"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: `${Math.abs(period.weeks)} weeks and ${Math.abs(period.days)} days`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center mt-2 text-dark",
                            children: "Due Date"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: `${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .dow_index */ .j2[new Date(due_date).getDay() + 1]}, ${new Date(due_date).getDate()} ${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .month_index */ .Mf[new Date(due_date).getMonth()]} ${new Date(due_date).getFullYear()}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                children: this.milestones.map(({ week, milestone })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("th", {
                                                children: [
                                                    "Week ",
                                                    week
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: milestone
                                            })
                                        ]
                                    }, week))
                            })
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pregnancy_calculator);


/***/ }),

/***/ 872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);




class Pregnancy_weight_gain extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.weeks = "*".repeat(40).split("").map((s, i)=>i + 1);
        this.calculate = ()=>{
            let { current_weight, pre_pregnancy_weight, weeks_pregnant } = this.state;
            current_weight = Number(current_weight);
            pre_pregnancy_weight = Number(pre_pregnancy_weight);
            weeks_pregnant = Number(weeks_pregnant);
            let recommended_min, recommended_max;
            if (weeks_pregnant < 14) {
                recommended_min = 1.1;
                recommended_max = 4.4;
            } else if (weeks_pregnant < 27) {
                recommended_min = 0.5;
                recommended_max = 2.2;
            } else if (weeks_pregnant < 40) {
                recommended_min = 0.4;
                recommended_max = 1.8;
            } else {
                recommended_min = 0.0;
                recommended_max = 0.5;
            }
            // Calculate expected weight gain based on pre-pregnancy weight
            let expected_gain = (recommended_min + recommended_max) / 2 * (weeks_pregnant / 4.3);
            let expected_weight = pre_pregnancy_weight + expected_gain;
            // Calculate actual weight gain and percentage
            let actual_gain = current_weight - pre_pregnancy_weight;
            let percent_complete = actual_gain / expected_gain * 100;
            // Create result object
            let result = {
                expected: {
                    gain: expected_gain.toFixed(1),
                    weight: expected_weight.toFixed(1)
                },
                actual: {
                    gain: actual_gain.toFixed(1),
                    weight: percent_complete.toFixed(1)
                }
            };
            this.setState({
                result,
                done: true
            });
        };
        this.state = {
            current_weight: 150,
            pre_pregnancy_weight: 125,
            weeks_pregnant: 28
        };
    }
    render() {
        let { current_weight, pre_pregnancy_weight, weeks_pregnant, result, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Pregnancy Weight Gain"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            children: "Pregnancy Week"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "simple-input",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                id: "bank",
                                                                defaultValue: `${weeks_pregnant}`,
                                                                onChange: ({ target })=>this.setState({
                                                                        weeks_pregnant: target.value
                                                                    }),
                                                                className: "form-control",
                                                                children: this.weeks.map((week)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                        value: week,
                                                                        children: [
                                                                            "Week ",
                                                                            week
                                                                        ]
                                                                    }, week))
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Current Weight"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Current Weight",
                                                                value: current_weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        current_weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Pre-Pregnancy Weight"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Pre Pregnancy Weight",
                                                                value: pre_pregnancy_weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        pre_pregnancy_weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Expected Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Gain"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: result.expected.gain
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Weight"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: result.expected.weight
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center mt-3 text-dark",
                            children: "Actual Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Gain"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: result.actual.gain
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Weight"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: result.actual.weight
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pregnancy_weight_gain);


/***/ }),

/***/ 4648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8158);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _text_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1294);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);






const sorts = new Array("ascending", "descending", "no");
const types = new Array("int", "decimal");
class Random_number_generator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate = ()=>{
            let { upper_bound, lower_bound, number_of_values, type, allow_duplicate, decimal_place, sort } = this.state;
            upper_bound = Number(upper_bound);
            lower_bound = Number(lower_bound);
            number_of_values = Number(number_of_values) || 1;
            if (number_of_values < 1) number_of_values = 1;
            let value = new Array();
            let fn = type === types[0] ? _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .gen_random_int */ .Yl : _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .gen_randon_value */ .xu;
            for(let i = 0; i < number_of_values; i++){
                let val = fn(upper_bound, lower_bound, decimal_place);
                if (!allow_duplicate) {
                    if (Math.abs(upper_bound - lower_bound) > number_of_values && type !== types[1]) while(value.includes(val))val = fn(upper_bound, lower_bound, decimal_place);
                }
                value.push(val);
            }
            if (value.length > 1) {
                if (sort === sorts[0]) value = value.sort((a, b)=>a - b);
                else if (sort === sorts[1]) value = value.sort((a, b)=>b - a);
            }
            this.setState({
                value,
                done: true
            });
        };
        this.toggle_advance = ()=>this.setState({
                advance: !this.state.advance
            });
        this.state = {
            upper_bound: 100,
            lower_bound: 1,
            number_of_values: 1,
            decimal_place: 4,
            type: types[0],
            allow_duplicate: false,
            sort: sorts[0]
        };
    }
    render() {
        let { upper_bound, lower_bound, advance, number_of_values, allow_duplicate, decimal_place, sort, type, value, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Random Number"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Upper Bound"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Upper Bound",
                                                                value: upper_bound,
                                                                onChange: ({ target })=>this.setState({
                                                                        upper_bound: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Lower Bound"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                min: "0",
                                                                placeholder: "Lower Bound",
                                                                value: lower_bound,
                                                                onChange: ({ target })=>this.setState({
                                                                        lower_bound: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        display: "flex",
                                                        alignItems: "center",
                                                        marginBottom: 20,
                                                        justifyContent: "center"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_text_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        action: this.toggle_advance,
                                                        style: {
                                                            textAlign: "center",
                                                            fontWeight: "bold"
                                                        },
                                                        text: "More Options"
                                                    })
                                                }),
                                                advance ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "form-group",
                                                                children: types.map((type_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        type: "radio",
                                                                        title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(type_.replace(/_/g, " ")),
                                                                        _id: type_,
                                                                        checked: type_ === type,
                                                                        action: (type)=>this.setState({
                                                                                type
                                                                            }),
                                                                        name: "type"
                                                                    }, type_))
                                                            })
                                                        }),
                                                        type === types[1] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-lg-6 col-md-6 col-sm-12",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "form-group",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        children: "Decimal Place"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                        className: "form-control",
                                                                        type: "number",
                                                                        min: "0",
                                                                        placeholder: "Decimal Place",
                                                                        value: decimal_place,
                                                                        onChange: ({ target })=>this.setState({
                                                                                decimal_place: target.value
                                                                            })
                                                                    })
                                                                ]
                                                            })
                                                        }) : null,
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-lg-6 col-md-6 col-sm-12",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "form-group",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        children: "Number of Values"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                        className: "form-control",
                                                                        type: "number",
                                                                        min: "1",
                                                                        placeholder: "Number of Values",
                                                                        value: number_of_values,
                                                                        onChange: ({ target })=>this.setState({
                                                                                number_of_values: target.value
                                                                            })
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        Number(number_of_values) > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "form-group",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    onClick: ()=>this.setState({
                                                                            allow_duplicate: !allow_duplicate
                                                                        }),
                                                                    className: "form-group smalls",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            id: "dups",
                                                                            className: "checkbox-custom",
                                                                            name: "dups",
                                                                            disabled: true,
                                                                            type: "checkbox",
                                                                            checked: allow_duplicate
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            for: "dups",
                                                                            className: "checkbox-custom-label",
                                                                            children: "Allow Duplicates"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }) : null,
                                                        number_of_values > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "form-group",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        children: "Sort by"
                                                                    }),
                                                                    sorts.map((sort_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                            type: "radio",
                                                                            title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(sort_.replace(/_/g, " ")),
                                                                            _id: sort_,
                                                                            checked: sort_ === sort,
                                                                            action: (sort)=>this.setState({
                                                                                    sort
                                                                                }),
                                                                            name: "sort"
                                                                        }, sort_))
                                                                ]
                                                            })
                                                        }) : null
                                                    ]
                                                }) : null
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Value"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2",
                            children: value.length > 1 ? value.map((v, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        v,
                                        i + 1 === value.length ? "" : ", "
                                    ]
                                })) : value[0]
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Random_number_generator);


/***/ }),

/***/ 1350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);






class Rectangle_cake_pan extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.units = new Array("inches", "centimeters", "millimeters", "feet", "meters");
        this.is_set = ()=>{
            let { from_unit, to_unit, height, length, width } = this.state;
            return from_unit && to_unit && height && width && length;
        };
        this.calculate = ()=>{
            let { from_unit, to_unit, width, height, length } = this.state;
            width = Number(width);
            length = Number(length);
            height = Number(height);
            // Convert dimensions to a base unit (inches)
            let base_length, base_width, base_height;
            switch(from_unit.toLowerCase()){
                case "inches":
                    base_length = length;
                    base_width = width;
                    base_height = height;
                    break;
                case "centimeters":
                    base_length = length / 2.54;
                    base_width = width / 2.54;
                    base_height = height / 2.54;
                    break;
                case "millimeters":
                    base_length = length / 25.4;
                    base_width = width / 25.4;
                    base_height = height / 25.4;
                    break;
                case "feet":
                    base_length = length * 12;
                    base_width = width * 12;
                    base_height = height * 12;
                    break;
                case "meters":
                    base_length = length * 39.37;
                    base_width = width * 39.37;
                    base_height = height * 39.37;
                    break;
                default:
                    throw new Error("Invalid 'from_unit' value. Supported units are: inches, centimeters, millimeters, feet, meters.");
            }
            // Convert dimensions to the target unit
            let converted_length, converted_width, converted_height;
            switch(to_unit.toLowerCase()){
                case "inches":
                    converted_length = base_length;
                    converted_width = base_width;
                    converted_height = base_height;
                    break;
                case "centimeters":
                    converted_length = base_length * 2.54;
                    converted_width = base_width * 2.54;
                    converted_height = base_height * 2.54;
                    break;
                case "millimeters":
                    converted_length = base_length * 25.4;
                    converted_width = base_width * 25.4;
                    converted_height = base_height * 25.4;
                    break;
                case "feet":
                    converted_length = base_length / 12;
                    converted_width = base_width / 12;
                    converted_height = base_height / 12;
                    break;
                case "meters":
                    converted_length = base_length / 39.37;
                    converted_width = base_width / 39.37;
                    converted_height = base_height / 39.37;
                    break;
                default:
                    throw new Error("Invalid 'to_unit' value. Supported units are: inches, centimeters, millimeters, feet, meters.");
            }
            // Round the dimensions to two decimal places
            converted_length = parseFloat(converted_length.toFixed(2));
            converted_width = parseFloat(converted_width.toFixed(2));
            converted_height = parseFloat(converted_height.toFixed(2));
            // Calculate the volume of the rectangular cake pan in cubic inches
            let volumeInCubicInches = converted_length * converted_width * converted_height;
            // Calculate the area of the rectangular cake pan in square inches
            let areaInSquareInches = converted_length * converted_width;
            // Calculate the circumference of the rectangular cake pan in inches
            let circumference_in_inches = 2 * (converted_length + converted_width);
            // Generate an object with the converted dimensions and other measurements
            this.setState({
                done: true,
                length_r: converted_length,
                width_r: converted_width,
                height_r: converted_height,
                volume: volumeInCubicInches,
                area: areaInSquareInches,
                circumference: circumference_in_inches
            });
        };
        this.state = {
            from_unit: this.units[0],
            to_unit: this.units[1],
            length: 9,
            width: 13,
            height: 2
        };
    }
    render() {
        let { volume, height_r, width_r, length_r, circumference, area, done, from_unit, to_unit, width, height, length } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: "text-center text-dark",
                                children: [
                                    "Converting from ",
                                    from_unit,
                                    " to ",
                                    to_unit
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Volume"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        " ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(volume)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Circumference (inches)"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        " ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(circumference)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Area"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(area)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Length"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(length_r)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Width"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(width_r)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Height"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(height_r)
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Length"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: length,
                                                                onChange: ({ target })=>this.setState({
                                                                        length: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Length"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Width"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: width,
                                                                onChange: ({ target })=>this.setState({
                                                                        width: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Width"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Height"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "From Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "bank",
                                                                    defaultValue: from_unit,
                                                                    onChange: ({ target })=>this.setState({
                                                                            from_unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((from_unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: from_unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(from_unit)
                                                                        }, from_unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "To Unit"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "bank",
                                                                    defaultValue: to_unit,
                                                                    onChange: ({ target })=>this.setState({
                                                                            to_unit: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.units.map((to_unit)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: to_unit,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(to_unit)
                                                                        }, to_unit))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rectangle_cake_pan);


/***/ }),

/***/ 159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);





class Retirement extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>true;
        this.calculate = ()=>{
            let { current_age, retirement_age, life_expectancy, monthly_contribution, interest_rate, inflation_rate, social_security_income, expected_lifestyle, annual_earning } = this.state;
            interest_rate = interest_rate;
            current_age = Number(current_age);
            retirement_age = Number(retirement_age);
            life_expectancy = Number(life_expectancy);
            interest_rate = Number(interest_rate);
            social_security_income = Number(social_security_income);
            monthly_contribution = Number(monthly_contribution);
            expected_lifestyle = Number(expected_lifestyle);
            let monthly_interest_rate = interest_rate / 1200;
            let num_months = (retirement_age - current_age) * 12;
            let social_security_years = Math.min(life_expectancy - retirement_age, 35 * 12);
            let total_contributions = monthly_contribution * num_months;
            let future_value = 0;
            for(let i = 0; i < num_months; i++){
                future_value = (future_value + monthly_contribution) * (1 + monthly_interest_rate);
            }
            let social_security_future_value = 0;
            let social_security_monthly_income = social_security_income / 12;
            for(let i = 0; i < social_security_years * 12; i++){
                social_security_future_value = (social_security_future_value + social_security_monthly_income) * (1 + monthly_interest_rate);
            }
            let total_future_value = future_value + social_security_future_value;
            let inflation_adjusted_value = total_future_value / Math.pow(1 + inflation_rate / 100, social_security_years);
            let expected_lifestyle_decimal = expected_lifestyle / 100;
            let retirement_savings_needed = inflation_adjusted_value / (1 - expected_lifestyle_decimal);
            let expected_annual_earning = (retirement_savings_needed - social_security_income) / (life_expectancy - retirement_age);
            let expected_lifestyle_at_retirement = expected_annual_earning / annual_earning * 100;
            this.setState({
                total_contributions,
                future_value,
                social_security_future_value,
                total_future_value,
                inflation_adjusted_value,
                expected_lifestyle_at_retirement,
                retirement_savings_needed,
                done: true
            });
        };
        this.state = {
            annual_earning: 80000,
            retirement_age: 65,
            life_expectancy: 90,
            social_security_income: 2000,
            inflation_rate: 3,
            expected_lifestyle: 70,
            interest_rate: 7,
            current_age: 30,
            monthly_contribution: 1000
        };
    }
    render() {
        let { total_contributions, future_value, social_security_future_value, total_future_value, inflation_adjusted_value, expected_lifestyle_at_retirement, principal, interest_rate, monthly_contribution, current_age, social_security_income, expected_lifestyle, inflation_rate, life_expectancy, retirement_age, annual_earning, retirement_savings_needed, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center",
                            children: "Retirement Savings Needed"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            className: "text-center mb-2",
                            children: [
                                "$ ",
                                (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(retirement_savings_needed)
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Total Future Value"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(total_future_value)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Inflation Adjusted Value"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(inflation_adjusted_value)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Future Value"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(future_value)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Social Security Future Value"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(social_security_future_value)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Total Contributions"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(total_contributions)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Expected Lifestyle at Retirement in %"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    expected_lifestyle_at_retirement
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Annual Earning"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Annual Earning",
                                                                value: annual_earning,
                                                                onChange: ({ target })=>this.setState({
                                                                        annual_earning: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Monthly Contributions"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Monthly Contributions",
                                                                value: monthly_contribution,
                                                                onChange: ({ target })=>this.setState({
                                                                        monthly_contribution: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Social Security Income"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Social Security Income",
                                                                value: social_security_income,
                                                                onChange: ({ target })=>this.setState({
                                                                        social_security_income: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Current Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Number of Years",
                                                                value: current_age,
                                                                onChange: ({ target })=>this.setState({
                                                                        current_age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Retirement Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Number of Years",
                                                                value: retirement_age,
                                                                onChange: ({ target })=>this.setState({
                                                                        retirement_age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Interest Rate (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Interest Rate",
                                                                value: interest_rate,
                                                                onChange: ({ target })=>this.setState({
                                                                        interest_rate: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Inflation Rate (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Inflation Rate",
                                                                value: inflation_rate,
                                                                onChange: ({ target })=>this.setState({
                                                                        inflation_rate: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Expected Lifestyle"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Expected Lifestyle",
                                                                value: expected_lifestyle,
                                                                onChange: ({ target })=>this.setState({
                                                                        expectedkkk_lifestyle: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Life Expectancy"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Life Expectancy",
                                                                value: life_expectancy,
                                                                onChange: ({ target })=>this.setState({
                                                                        life_expectancy: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Retirement);


/***/ }),

/***/ 5169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ commalise_figures),
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7108);





const commalise_figures = (value, no_float)=>{
    let integer = Math.floor(value);
    let decimal = (value - integer).toFixed(2).toString();
    let commalised = (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .Ew)(integer);
    return no_float ? commalised : `${commalised}${decimal.slice(decimal.indexOf("."))}`;
};
class Salary_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.payment_intervals = new Array("monthly", "quarterly", "yearly");
        this.is_set = ()=>{
            let { salary_amount, hours, days } = this.state;
            return salary_amount, hours, days;
        };
        this.adjusted = (type)=>{
            let { vacations, holidays, total_annual_days, daily, days } = this.state;
            let total_vacs = Number(vacations || 0) + Number(holidays || 0);
            let val = daily * (total_annual_days - total_vacs);
            if (type !== "annually") {
                val /= total_annual_days;
                if (type === "weekly") val *= days;
                else if (type === "bi_weekly") val *= days * 2;
                else if (type === "monthly") val *= days * 4;
                else if (type === "quarterly") val *= days * 4 * 3;
            }
            return val && commalise_figures(val);
        };
        this.calculate = ()=>{
            let { salary_amount, days } = this.state;
            let daily = salary_amount * 8;
            this.setState({
                daily,
                total_annual_days: days * 4 * 12,
                done: true
            });
        };
        this.state = {};
    }
    render() {
        let { salary_amount, done, hours, days, holidays, vacations, daily } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                        style: {
                            width: "100%",
                            textAlign: "center"
                        },
                        className: "result_table",
                        bordered: true,
                        hover: true,
                        responsive: true,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            children: "Unadjusted"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            children: "Holidays & Vacation Days Adjusted"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Daily"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("daily")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Weekly"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily * days)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("weekly")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Bi-Weekly"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily * days * 2)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("bi_weekly")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Monthly"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily * days * 4)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("monthly")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Quarterly"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily * days * 4 * 3)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("quarterly")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: "Annually"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    commalise_figures(daily * days * 4 * 12)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                children: [
                                                    "$ ",
                                                    this.adjusted("annually")
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Salary Amount per Hour"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        value: salary_amount,
                                                        onChange: ({ target })=>this.setState({
                                                                salary_amount: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "Hourly Rate"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Hours per Day"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Hours",
                                                                value: hours,
                                                                onChange: ({ target })=>this.setState({
                                                                        hours: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Day per Week"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Days",
                                                                value: days,
                                                                onChange: ({ target })=>this.setState({
                                                                        days: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Holidays per Year"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Holidays",
                                                                value: holidays,
                                                                onChange: ({ target })=>this.setState({
                                                                        holidays: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Vacation Days per Year"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Vacations",
                                                                value: vacations,
                                                                onChange: ({ target })=>this.setState({
                                                                        vacations: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Salary_calculator);



/***/ }),

/***/ 5850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);





class Sales_price extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { original_price, discount_percentage } = this.state;
            return original_price && discount_percentage;
        };
        this.calculate = ()=>{
            let { original_price, discount_percentage } = this.state;
            original_price = Number(original_price);
            discount_percentage = Number(discount_percentage);
            // Convert the discount percentage from a percentage to a decimal
            let decimalDiscount = discount_percentage / 100;
            // Calculate the amount of the discount
            let discount_amount = original_price * decimalDiscount;
            // Calculate the sales price
            let sales_price = original_price - discount_amount;
            // Generate an object with the results
            this.setState({
                original_price,
                discount_percentage,
                discount_amount,
                sales_price,
                done: true
            });
        };
        this.state = {
            original_price: 100,
            discount_percentage: 10
        };
    }
    render() {
        let { original_price, discount_percentage, sales_price, discount_amount, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Original Price"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(original_price)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Discount Percentage"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(discount_percentage),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Discount Amount"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(discount_amount)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Sales Price"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(sales_price)
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Original Price"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: original_price,
                                                                onChange: ({ target })=>this.setState({
                                                                        original_price: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Original Price"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Discount Percentage (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: discount_percentage,
                                                                onChange: ({ target })=>this.setState({
                                                                        discount_percentage: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Discount Percentage"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sales_price);


/***/ }),

/***/ 7166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);





class Sales_tax extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { price, tax_rate } = this.state;
            return price && tax_rate;
        };
        this.calculate = ()=>{
            let { price, tax_rate } = this.state;
            price = Number(price);
            tax_rate = Number(tax_rate);
            // Convert the tax rate from percentage to decimal
            let decimal_rate = tax_rate / 100;
            // Calculate the sales tax
            let sales_tax = price * decimal_rate;
            // Calculate the total cost
            let total_cost = price + sales_tax;
            // Round the results to two decimal places
            let sales_tax_rounded = Math.round(sales_tax * 100) / 100;
            let total_cost_rounded = Math.round(total_cost * 100) / 100;
            // Generate an object with the results
            this.setState({
                done: true,
                price: price,
                tax_rate: tax_rate,
                sales_tax: sales_tax_rounded,
                total_cost: total_cost_rounded
            });
        };
        this.state = {
            price: 100,
            tax_rate: 0.1
        };
    }
    render() {
        let { price, tax_rate, sales_tax, total_cost, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Total Cost"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(total_cost)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Sales Tax"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(sales_tax)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Tax Rate"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: tax_rate
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Price"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(price)
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Bill Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: price,
                                                                onChange: ({ target })=>this.setState({
                                                                        price: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Bill Amount"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Tip Percentage (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: tax_rate,
                                                                onChange: ({ target })=>this.setState({
                                                                        tax_rate: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Tip Percentage"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sales_tax);


/***/ }),

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Selling_price extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { profit_margin, cost } = this.state;
            return profit_margin && cost;
        };
        this.calculate = ()=>{
            let { profit_margin, cost } = this.state;
            profit_margin = Number(profit_margin);
            cost = Number(cost);
            // Convert profit margin from percentage to decimal
            let decimal_margin = profit_margin / 100;
            // Calculate the selling price
            let selling_price = cost / (1 - decimal_margin);
            this.setState({
                selling_price,
                done: true
            });
        };
        this.state = {
            profit_margin: 150,
            cost: 1000
        };
    }
    render() {
        let { profit_margin, cost, selling_price, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Profit Margin"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "text-center mb-2",
                                children: [
                                    "$ ",
                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(selling_price.toFixed(2))
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Profit Margin"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: profit_margin,
                                                                onChange: ({ target })=>this.setState({
                                                                        profit_margin: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Profit Margin"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Cost"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: cost,
                                                                onChange: ({ target })=>this.setState({
                                                                        cost: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Cost"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Selling_price);


/***/ }),

/***/ 9722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _alert_box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5589);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3782);





class Standard_deviation extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.handle_numbers = ({ target })=>{
            let numbers = target.value;
            numbers = numbers.replace(/ /g, ",").split(",");
            numbers = numbers.filter((n, i)=>{
                if (!n && i + 1 !== numbers.length) return;
                n = Number(n);
                if (!n && n !== 0) return false;
                return true;
            });
            this.setState({
                numbers: numbers.join(",")
            });
        };
        this.calculate_mode = (numbers)=>{
            // Create an object to store the frequency of each number
            let frequency = {};
            // Loop through the array of numbers and count the frequency of each number
            for(let i = 0; i < numbers.length; i++){
                if (frequency[numbers[i]]) {
                    frequency[numbers[i]]++;
                } else {
                    frequency[numbers[i]] = 1;
                }
            }
            // Find the number(s) with the highest frequency
            let max_frequency = 0;
            let modes = [];
            for(let number in frequency){
                if (frequency[number] > max_frequency) {
                    max_frequency = frequency[number];
                    modes = [
                        Number(number)
                    ];
                } else if (frequency[number] === max_frequency) {
                    modes.push(Number(number));
                }
            }
            return modes;
        };
        this.calculate = ()=>{
            let { numbers } = this.state;
            numbers = numbers.split(",").map((n)=>Number(n));
            let n = numbers.length;
            let mean = numbers.reduce((sum, num)=>sum + num, 0) / n;
            let variance = numbers.reduce((sum, num)=>sum + (num - mean) ** 2, 0) / n;
            let std = Math.sqrt(variance);
            let median;
            numbers = numbers.sort((i, j)=>i - j);
            if (n % 0) median = numbers[Math.ceil(n / 2)];
            else {
                let m = n / 2;
                median = (numbers[m] + numbers[m + 1]) / 2;
            }
            this.setState({
                std,
                variance,
                mean,
                median,
                mode: this.calculate_mode(numbers),
                done: true
            });
        };
        this.state = {
            numbers: "1,2,3,4,5,6,7,8,9,1"
        };
    }
    render() {
        let { numbers, mean, std, mode, median, variance, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "modal-title text-dark",
                                children: "Basic Statistics"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "login-form",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_box__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        message: "Separate numbers by comma (,)",
                                        type: "info"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            children: "Numbers"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                            className: "form-control",
                                                            type: "number",
                                                            placeholder: "Numbers",
                                                            value: numbers,
                                                            onChange: this.handle_numbers
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                disabled: !numbers,
                                                title: "Calculate",
                                                action: this.calculate
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }),
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-center mb-2"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%",
                                textAlign: "center"
                            },
                            className: "result_table",
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Standard Deviation"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: std
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Mean"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: mean
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Mode"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: mode
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Variance"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: variance
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Median"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: median
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Standard_deviation);


/***/ }),

/***/ 3705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);
/* harmony import */ var _assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7354);






class Subnet_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let your_ip = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .get_request */ .AN)("https://bckend.techmastertools.net/what_is_my_ip");
            this.setState({
                your_ip
            });
        };
        this.set_ip = (ip)=>this.setState(ip.includes(":") ? {
                ipv6: ip
            } : {
                ip
            });
        this.calculate_v6 = (e)=>{
            e && e.preventDefault();
            let { ipv6, v6_mask } = this.state;
            if (!ipv6) ipv6 = "fa60::8e71:0021:cb6e:e31c";
            let ip = ipv6;
            let mask = v6_mask || "64";
            mask = parseInt(mask);
            let result = new Object({
                ip
            });
            ip = ip.split(":");
            if (ip.length < 8) {
                if (ip.includes("")) {
                    let zeros = new Array(8 - ip.length);
                    zeros = zeros.map((z)=>"0000");
                    ip.splice(ip.indexOf(""), 0, ...zeros);
                    ip = ip.map((p)=>p || "");
                }
            }
            ip = ip.map((p)=>p.padStart(4, "0"));
            result.full_address = ip.join(":");
            let binary = ip.map((p)=>{
                return parseInt(p, 16).toString(2).padStart(16, "0");
            });
            result.binary = binary.join(":");
            binary = binary.join("");
            let net = new Array();
            let network_address = binary.slice(0, mask);
            while(true){
                if (network_address.length >= 16) {
                    net.push(network_address.slice(0, 16));
                    network_address = network_address.slice(16);
                } else {
                    network_address.length && net.push(network_address);
                    break;
                }
            }
            net = ip.slice(0, net.length);
            let net_upper_bound = new Array(...net);
            let x = net_upper_bound.slice(-1)[0];
            if (x && x.endsWith("0")) {
                let i = 0;
                while(i < x.length){
                    if (x[i] === "0") {
                        x = x.slice(0, i);
                        break;
                    }
                    i++;
                }
                x = x.padEnd(4, "f");
                net_upper_bound.pop();
                net_upper_bound.push(x);
            }
            while(net.length < 8){
                net.push("0000");
                net_upper_bound.push("ffff");
            }
            result.network_address = net.join(":");
            result.address_range = `${result.network_address} - ${net_upper_bound.join(":")}`;
            let assignable_hosts = binary.slice(mask);
            assignable_hosts = assignable_hosts.split("").map((a)=>"1");
            result.assignable_hosts = (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(parseInt(assignable_hosts.join(""), 2), true);
            result.prefix_length = mask;
            this.setState({
                result6: result,
                result_header6: Object.keys(result),
                done6: true
            });
        };
        this.calculate = async (e)=>{
            e && e.preventDefault();
            let { ip, your_ip, calculating, mask } = this.state;
            if (calculating) return;
            if (!ip) ip = your_ip && your_ip.ip;
            if (!ip) return;
            this.setState({
                calculating: true
            });
            mask = mask || "32";
            if (mask.startsWith("/")) mask = mask.slice(1);
            let result = await (0,_assets_js_utils_services__WEBPACK_IMPORTED_MODULE_5__/* .get_request */ .AN)(`https://networkcalc.com/api/ip/${ip.trim()}/${mask}?binary=true`, undefined, true);
            if (result && result.address) result.address.assignable_hosts = (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(Number(result.address.assignable_hosts), true);
            result = result && result.address;
            let result_header = result && Object.keys(result);
            this.setState({
                result,
                result_header,
                calculating: false,
                done: true
            });
        };
        this.state = {
            masks: new Array("255.255.255.255", "255.255.255.254", "255.255.255.252", "255.255.255.248", "255.255.255.240", "255.255.255.224", "255.255.255.192", "255.255.255.128", "255.255.255.0", "255.255.254.0", "255.255.252.0", "255.255.248.0", "255.255.240.0", "255.255.224.0", "255.255.192.0", "255.255.128.0", "255.255.0.0", "255.254.0.0", "255.252.0.0", "255.248.0.0", "255.240.0.0", "255.224.0.0", "255.192.0.0", "255.128.0.0", "255.0.0.0", "254.0.0.0", "252.0.0.0", "248.0.0.0", "240.0.0.0", "224.0.0.0", "192.0.0.0", "128.0.0.0", "0.0.0.0"),
            mask: "32",
            v6mask: Array.from(Array(129).keys())
        };
    }
    render() {
        let { done, ip, masks, calculating, result, result_header, your_ip, ipv6, v6mask, done6, result6, result_header6, v6_mask } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "IPv4 Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%"
                            },
                            striped: true,
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                style: {
                                    width: "100%"
                                },
                                children: result_header.map((header, index)=>{
                                    return header === "binary" ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                style: {
                                                    width: "45vw"
                                                },
                                                children: (header === "ip" ? header.toUpperCase() : header).replace(/_/g, " ")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                style: {
                                                    width: "55vw"
                                                },
                                                children: result[header]
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "IPv4"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "IP Address"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        value: ip,
                                                        onChange: ({ target })=>this.setState({
                                                                ip: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "IPv4"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            for: "",
                                            children: [
                                                "Your IP Address* ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: your_ip?.ip || "..."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Subnet Mask"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "simple-input",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                        id: "ipv4_mask",
                                                        onChange: ({ target })=>this.setState({
                                                                mask: target.value
                                                            }),
                                                        className: "form-control",
                                                        children: masks.map((msk, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                value: 32 - index,
                                                                children: [
                                                                    msk,
                                                                    " /",
                                                                    32 - index
                                                                ]
                                                            }, msk))
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            loading: calculating,
                                            disabled: !ip
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                done6 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid p-2 py-5 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "text-center text-dark",
                            children: "IPv4 Result"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                            style: {
                                width: "100%"
                            },
                            striped: true,
                            bordered: true,
                            hover: true,
                            responsive: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                style: {
                                    width: "100%"
                                },
                                children: result_header6.map((header, index)=>{
                                    return header === "binary" ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                style: {
                                                    width: "45vw"
                                                },
                                                children: (header === "ip" ? header.toUpperCase() : header).replace(/_/g, " ")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                style: {
                                                    width: "55vw"
                                                },
                                                children: result6[header]
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    ]
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "IPv6"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "IPv6 Address"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        value: ipv6,
                                                        onChange: ({ target })=>this.setState({
                                                                ipv6: target.value
                                                            }),
                                                        className: "form-control",
                                                        style: {
                                                            fontSize: 16,
                                                            color: "#000"
                                                        },
                                                        placeholder: "fa60::8e71:0021:cb6e:e31c"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Prefix length"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "simple-input",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                        id: "ipv4_mask",
                                                        onChange: ({ target })=>this.setState({
                                                                v6_mask: target.value
                                                            }),
                                                        className: "form-control",
                                                        children: v6mask.map((msk)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                value: msk.toString(),
                                                                children: [
                                                                    "/",
                                                                    msk
                                                                ]
                                                            }, msk))
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate_v6,
                                            disabled: !ipv6
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subnet_calculator);


/***/ }),

/***/ 8249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5169);





class Tip_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { bill_amount, tip_percentage, num_people } = this.state;
            return bill_amount && tip_percentage && num_people;
        };
        this.calculate = ()=>{
            let { bill_amount, tip_percentage, num_people } = this.state;
            bill_amount = Number(bill_amount);
            tip_percentage = Number(tip_percentage);
            num_people = Number(num_people);
            tip_percentage /= 100;
            // Calculate tip amount
            let tip_amount = bill_amount * (tip_percentage / 100);
            let per_person_amount = tip_amount / num_people;
            // Calculate bill_amount amount including tip
            let total_amount = bill_amount + tip_amount;
            // Generate an object with the results
            this.setState({
                tip_amount,
                total_amount,
                per_person_amount,
                done: true
            });
        };
        this.state = {
            bill_amount: 75,
            tip_percentage: 18,
            num_people: 4
        };
    }
    render() {
        let { bill_amount, tip_percentage, num_people, done, tip_amount, total_amount, per_person_amount } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Tip Amount"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(tip_amount)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Tip per Person"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(per_person_amount)
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "Total Amount"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    children: [
                                                        "$ ",
                                                        (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_4__/* .commalise_figures */ .E)(total_amount)
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Bill Amount"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: bill_amount,
                                                                onChange: ({ target })=>this.setState({
                                                                        bill_amount: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Bill Amount"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Tip Percentage (%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: tip_percentage,
                                                                onChange: ({ target })=>this.setState({
                                                                        tip_percentage: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Tip Percentage"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Number of People"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                min: "0",
                                                                value: num_people,
                                                                onChange: ({ target })=>this.setState({
                                                                        num_people: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Number of People"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tip_calculator);


/***/ }),

/***/ 4583:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _alert_box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5589);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3782);





class Triangle extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.calculate = ()=>{
            let { a, b, c, A, B, C } = this.state;
            a = Number(a);
            b = Number(b);
            c = Number(c);
            A = Number(A);
            B = Number(B);
            C = Number(C);
            if (!a) a = null;
            if (!b) b = null;
            if (!c) c = null;
            if (!A) A = null;
            if (!B) B = null;
            if (!C) C = null;
            // Convert angles to radians
            let radA = A ? A * Math.PI / 180 : null;
            let radB = B ? B * Math.PI / 180 : null;
            let radC = C ? C * Math.PI / 180 : null;
            // Calculate missing side using Law of Cosines
            let cosA = (b ** 2 + c ** 2 - a ** 2) / (2 * b * c);
            let cosB = (a ** 2 + c ** 2 - b ** 2) / (2 * a * c);
            let cosC = (a ** 2 + b ** 2 - c ** 2) / (2 * a * b);
            let side_a = A && b && c ? Math.sqrt(b ** 2 + c ** 2 - 2 * b * c * Math.cos(radA)) : a && B && c ? Math.sqrt(a ** 2 + c ** 2 - 2 * a * c * Math.cos(radB)) : a && b && C ? Math.sqrt(a ** 2 + b ** 2 - 2 * a * b * Math.cos(radC)) : null;
            let side_b = A && b && c ? Math.sqrt(a ** 2 + c ** 2 - 2 * a * c * Math.cos(radB)) : a && B && c ? Math.sqrt(b ** 2 + c ** 2 - 2 * b * c * Math.cos(radA)) : a && b && C ? Math.sqrt(a ** 2 + c ** 2 - 2 * a * c * Math.cos(radC)) : null;
            let side_c = A && b && c ? Math.sqrt(a ** 2 + b ** 2 - 2 * a * b * Math.cos(radC)) : a && B && c ? Math.sqrt(a ** 2 + c ** 2 - 2 * a * c * Math.cos(radB)) : a && b && C ? Math.sqrt(b ** 2 + c ** 2 - 2 * b * c * Math.cos(radA)) : null;
            // Calculate missing angles using Law of Sines
            let angle_a = A ? A : side_b && side_c ? Math.asin(side_b / side_c) * 180 / Math.PI : null;
            let angle_b = B ? B : side_a && side_c ? Math.asin(side_a / side_c) * 180 / Math.PI : null;
            let angle_c = C ? C : side_a && side_b ? Math.asin(side_a / side_b) * 180 / Math.PI : null;
            // Return missing sides and angles
            this.setState({
                side_a,
                side_b,
                side_c,
                angle_a,
                angle_b,
                angle_c,
                done: true
            });
        };
        this.render = ()=>{
            let { a, b, c, A, B, C, side_a, side_b, side_c, angle_a, angle_b, angle_c, done } = this.state;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "modal-title text-dark",
                                    children: "Triangle"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "login-form",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_box__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                message: "Leave missing sides / angles as 0",
                                                type: "info"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Side a"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Side a",
                                                                    value: a,
                                                                    onChange: ({ target })=>this.setState({
                                                                            a: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Angle a"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Angle a",
                                                                    value: A,
                                                                    onChange: ({ target })=>this.setState({
                                                                            A: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Side b"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Side b",
                                                                    value: b,
                                                                    onChange: ({ target })=>this.setState({
                                                                            b: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Angle b"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Angle b",
                                                                    value: B,
                                                                    onChange: ({ target })=>this.setState({
                                                                            B: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Side c"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Side c",
                                                                    value: c,
                                                                    onChange: ({ target })=>this.setState({
                                                                            c: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-lg-6 col-md-6 col-sm-12",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "form-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    children: "Angle c"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    className: "form-control",
                                                                    type: "number",
                                                                    placeholder: "Angle c",
                                                                    value: C,
                                                                    onChange: ({ target })=>this.setState({
                                                                            C: target.value
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                title: "Calculate",
                                                style: {
                                                    backgroundColor: "yellow"
                                                },
                                                action: this.calculate
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid p-2 py-5 text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-center mb-2"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Table, {
                                style: {
                                    width: "100%",
                                    textAlign: "center"
                                },
                                className: "result_table",
                                bordered: true,
                                hover: true,
                                responsive: true,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    style: {
                                                        textAlign: "center"
                                                    },
                                                    colSpan: 2,
                                                    children: "Sides"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    style: {
                                                        textAlign: "center"
                                                    },
                                                    colSpan: 2,
                                                    children: "Angles"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "a"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: side_a ? side_a.toFixed(2) : "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "A"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: angle_a ? angle_a.toFixed(2) : "-"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "b"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: side_b ? side_b.toFixed(2) : "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "B"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: angle_b ? angle_b.toFixed(2) : "-"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "c"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: side_c ? side_c.toFixed(2) : "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        children: "C"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: angle_c ? angle_c.toFixed(2) : "-"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }) : null
                ]
            });
        };
        this.state = {
            a: 3,
            b: 0,
            c: 5,
            A: 0,
            B: 45,
            C: 0
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Triangle);


/***/ }),

/***/ 2977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8158);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3782);
/* harmony import */ var _daily_calorie_need__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3085);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);






class Weight_loss_calculator extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.activities = new Array("sedentary", "lightly_active", "moderately_active", "very_active", "extra_active");
        this.sexes = new Array("male", "female");
        this.calculate = ()=>{
            let { weight, height, age, sex, activity, goal } = this.state;
            goal = Number(goal);
            let daily_calorie_need = new _daily_calorie_need__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z().calculate({
                weight,
                height,
                age,
                sex,
                activity
            });
            let daily_calorie_deficit = 500 * goal; // 500 calorie deficit per day for 1 lb weight loss per week
            let daily_calorie_intake = daily_calorie_need - daily_calorie_deficit;
            this.setState({
                daily_calorie_intake,
                done: true
            });
            return daily_calorie_intake;
        };
        this.state = {
            weight: 75,
            goal: 2,
            height: 180,
            age: 30,
            sex: this.sexes[0],
            activity: this.activities[0]
        };
    }
    render() {
        let { weight, height, daily_calorie_intake, goal, age, sex, done } = this.state;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "crs_grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-header",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: "modal-title text-dark",
                            children: "Weight Loss Calculator"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "login-form",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (kg)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Weight",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Goal (lbs)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Goal",
                                                                value: goal,
                                                                onChange: ({ target })=>this.setState({
                                                                        goal: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Height (centimeters)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Height",
                                                                value: height,
                                                                onChange: ({ target })=>this.setState({
                                                                        height: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Age"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                className: "form-control",
                                                                type: "number",
                                                                placeholder: "Age",
                                                                value: age,
                                                                onChange: ({ target })=>this.setState({
                                                                        age: target.value
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-12 col-md-12 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Sex"
                                                            }),
                                                            this.sexes.map((sex_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    type: "radio",
                                                                    title: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(sex_.replace(/_/g, " ")),
                                                                    _id: sex_,
                                                                    checked: sex_ === sex,
                                                                    action: (sex)=>this.setState({
                                                                            sex
                                                                        }),
                                                                    name: "sex"
                                                                }, sex_))
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Activity Level"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "simple-input",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                                    id: "activity",
                                                                    onChange: ({ target })=>this.setState({
                                                                            activity: target.value
                                                                        }),
                                                                    className: "form-control",
                                                                    children: this.activities.map((activity)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                            value: activity,
                                                                            children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(activity.replace(/_/g, " "))
                                                                        }, activity))
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !weight || !height || !age || !goal || !sex
                                        })
                                    ]
                                }),
                                done ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "crs_grid p-2 py-5 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "text-center text-dark",
                                            children: "Daily Calorie Intake"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                            className: "text-center mb-2",
                                            children: [
                                                (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .commalise_figures */ .Ew)(parseInt(daily_calorie_intake)),
                                                " calories"
                                            ]
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    })
                ]
            })
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Weight_loss_calculator);


/***/ }),

/***/ 1072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stretch_btn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3782);
/* harmony import */ var _salary_calculator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5169);




class Weight_to_volume extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.is_set = ()=>{
            let { density, weight } = this.state;
            return density && weight;
        };
        this.calculate = ()=>{
            let { density, weight } = this.state;
            density = Number(density);
            weight = Number(weight);
            // Convert weight to grams
            let weight_in_grams = weight * 1000;
            // Calculate volume in milliliters
            let volume_in_milliliters = weight_in_grams / density;
            // Return the result
            this.setState({
                volume: volume_in_milliliters,
                done: true
            });
        };
        this.state = {
            density: 1,
            weight: 1
        };
    }
    render() {
        let { density, weight, volume, done } = this.state;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                done ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "crs_grid py-4 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center text-dark",
                                children: "Volume"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "text-center mb-2",
                                children: [
                                    (0,_salary_calculator__WEBPACK_IMPORTED_MODULE_3__/* .commalise_figures */ .E)(volume.toFixed(2)),
                                    " ml"
                                ]
                            })
                        ]
                    })
                }) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "crs_grid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-header",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "modal-title text-dark",
                                children: "Calculator"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "modal-body",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "login-form",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Weight (kg)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: weight,
                                                                onChange: ({ target })=>this.setState({
                                                                        weight: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Weight"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-lg-6 col-md-6 col-sm-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: "Density"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                value: density,
                                                                onChange: ({ target })=>this.setState({
                                                                        density: target.value
                                                                    }),
                                                                className: "form-control",
                                                                style: {
                                                                    fontSize: 16,
                                                                    color: "#000"
                                                                },
                                                                placeholder: "Density"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stretch_btn__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            title: "Calculate",
                                            style: {
                                                backgroundColor: "yellow"
                                            },
                                            action: this.calculate,
                                            disabled: !this.is_set()
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Weight_to_volume);


/***/ }),

/***/ 8158:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Checkbox = ({ title, no_capitalise, type, style, name, _id, action, disabled, checked })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-group smalls",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: _id,
                className: "checkbox-custom",
                name: name,
                type: type || "checkbox",
                checked: checked,
                onChange: ()=>{
                    console.log(title, "HLE");
                    !disabled && action(_id);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                style: {
                    ...style
                },
                for: _id,
                className: "checkbox-custom-label",
                children: no_capitalise ? title : (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_2__/* .to_title */ .bk)(title)
            })
        ]
    }, _id);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Checkbox);


/***/ }),

/***/ 6558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export options */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3767);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__]);
([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ options,default auto */ 



chart_js__WEBPACK_IMPORTED_MODULE_2__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_2__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.LineElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.Title, chart_js__WEBPACK_IMPORTED_MODULE_2__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_2__.Legend);
const options = {
    responsive: true,
    plugins: {
        legend: {
            position: "top"
        }
    }
};
class Line_chart extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
    }
    render() {
        let { data, title } = this.props;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            style: {
                marginBottom: 40
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Line, {
                    options: options,
                    data: data
                }),
                title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        marginTop: 20,
                        textAlign: "center",
                        fontWeight: "bold",
                        fontSize: 18,
                        marginBottom: 20
                    },
                    children: title
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Line_chart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5799:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3767);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__]);
([chart_js__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



chart_js__WEBPACK_IMPORTED_MODULE_2__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_2__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_2__.Legend);
class Pie_chart extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
    }
    render() {
        let { data, title } = this.props;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            style: {
                textAlign: "center",
                marginBottom: 40
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Pie, {
                    data: data
                }),
                title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        marginTop: 20,
                        textAlign: "center",
                        fontWeight: "bold",
                        fontSize: 18
                    },
                    children: title
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pie_chart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ reviews)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./assets/js/utils/functions.js
var functions = __webpack_require__(7108);
// EXTERNAL MODULE: ./assets/js/utils/services.js
var services = __webpack_require__(7354);
;// CONCATENATED MODULE: ./assets/img/user_image_placeholder.png
/* harmony default export */ const user_image_placeholder = ({"src":"/_next/static/media/user_image_placeholder.a01896a2.png","height":121,"width":121,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAS1BMVEX////4+vzs8fji6/Tg6fTe6PPR3+/K2+3E1uvD1uu50OiuyeWlw+Kkw+Kcv+CXvN+Vu9+Uut6Tut6Ot92Mtt2LtdyKtdyJtdyHtNxcB2MpAAAAQElEQVR42hXGxwHAIAwEsKO3BIOp+08K6CWUyt5zLaARgDAItCxg1838hfgmoSWplEwN2+AyG12/6A7O0bmY+QBm7QKgwu5gxAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/comment.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




class Comment extends (external_react_default()).Component {
    constructor(props){
        super(props);
        this.like_comment = async (e)=>{
            e.preventDefault();
            let { comment } = this.props;
            let { likes } = this.state;
            likes++;
            this.setState({
                likes
            });
            await (0,services/* post_request */.Yu)("comment_like", {
                comment: comment._id,
                item: comment.comment || comment.item
            });
        };
        this.dislike_comment = async (e)=>{
            e.preventDefault();
            let { comment } = this.props;
            let { dislikes } = this.state;
            dislikes++;
            this.setState({
                dislikes
            });
            await (0,services/* post_request */.Yu)("comment_dislike", {
                comment: comment._id,
                item: comment.comment || comment.item
            });
        };
        this.heart_comment = async (e)=>{
            e.preventDefault();
            let { comment } = this.props;
            let { hearts } = this.state;
            hearts++;
            this.setState({
                hearts
            });
            await (0,services/* post_request */.Yu)("comment_heart", {
                comment: comment._id,
                item: comment.comment || comment.item
            });
        };
        let { likes, dislikes, hearts } = this.props.comment;
        this.state = {
            likes: likes || 0,
            dislikes: dislikes || 0,
            hearts: hearts || 0
        };
    }
    render() {
        let { likes, dislikes, hearts } = this.state;
        let { comment } = this.props;
        let { text, name, created } = comment;
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            class: "reviews-comments-item",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    class: "review-comments-avatar",
                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                        src: user_image_placeholder.src,
                        class: "img-fluid",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    class: "reviews-comments-item-text",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("h4", {
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                    href: "#",
                                    children: name
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                    class: "reviews-comments-item-date",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            class: "ti-calendar theme-cl"
                                        }),
                                        (0,functions/* date_string */.Rd)(created)
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            class: "listing-rating",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    class: "fas fa-star active"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    class: "fas fa-star active"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    class: "fas fa-star active"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    class: "fas fa-star active"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    class: "fas fa-star active"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            class: "clearfix"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                            children: [
                                '" ',
                                text,
                                ' "'
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            class: "pull-left reviews-reaction",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                    href: "#",
                                    onClick: this.like_comment,
                                    class: "comment-like active",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            class: "ti-thumb-up"
                                        }),
                                        " ",
                                        likes || ""
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                    href: "#",
                                    onClick: this.dislike_comment,
                                    class: "comment-dislike active",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            class: "ti-thumb-down"
                                        }),
                                        " ",
                                        dislikes || ""
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                    href: "#",
                                    onClick: this.heart_comment,
                                    class: "comment-love active",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            class: "ti-heart"
                                        }),
                                        " ",
                                        hearts || ""
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const components_comment = (Comment);

// EXTERNAL MODULE: ./components/listempty.js
var listempty = __webpack_require__(1030);
// EXTERNAL MODULE: ./components/loadindicator.js + 1 modules
var loadindicator = __webpack_require__(1875);
;// CONCATENATED MODULE: ./components/submit_review.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



class Submit_review extends (external_react_default()).Component {
    constructor(props){
        super(props);
        this.submit = async (e)=>{
            e.preventDefault();
            let { calculator, on_comment, comment: comm } = this.props;
            let { name, text, email, loading } = this.state;
            if (loading) return;
            this.setState({
                loading: true
            });
            let comment = {
                name,
                email,
                text
            };
            if (calculator) comment.item = calculator._id;
            else comment.comment = comm._id;
            let result = await (0,services/* post_request */.Yu)(comm ? "new_reply" : "new_comment", comment);
            comment._id = result._id;
            comment.created = result.created;
            on_comment && on_comment(comment);
            this.clear_state();
        };
        this.clear_state = ()=>this.setState({
                name: "",
                loading: false,
                email: "",
                text: ""
            });
        this.state = {};
    }
    render() {
        let { text, name, email, loading } = this.state;
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            class: "edu_wraper",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                    class: "edu_title",
                    children: "Submit Reviews"
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    class: "review-form-box form-submit",
                    children: /*#__PURE__*/ jsx_runtime.jsx("form", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            class: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    class: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                children: [
                                                    "Name ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-danger",
                                                        children: "*"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                class: "form-control",
                                                type: "text",
                                                placeholder: "Your Name",
                                                value: name,
                                                onChange: ({ target })=>this.setState({
                                                        name: target.value
                                                    })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    class: "col-lg-6 col-md-6 col-sm-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                children: [
                                                    "Email ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-danger",
                                                        children: "*"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                class: "form-control",
                                                type: "email",
                                                placeholder: "Your Email",
                                                value: email,
                                                onChange: ({ target })=>this.setState({
                                                        email: target.value
                                                    })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    class: "col-lg-12 col-md-12 col-sm-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        class: "form-group",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                                children: [
                                                    "Review ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-danger",
                                                        children: "*"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("textarea", {
                                                class: "form-control ht-140",
                                                placeholder: "Review",
                                                value: text,
                                                onChange: ({ target })=>this.setState({
                                                        text: target.value
                                                    })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    class: "col-lg-12 col-md-12 col-sm-12",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        class: "form-group",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                            onClick: this.submit,
                                            type: "submit",
                                            disabled: !name || loading || !text || !functions/* email_regex */.E_.test(email),
                                            class: "btn theme-bg btn-md",
                                            children: "Submit Review"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const submit_review = (Submit_review);

;// CONCATENATED MODULE: ./components/reviews.js
/* __next_internal_client_entry_do_not_use__ default auto */ 






class Reviews extends (external_react_default()).Component {
    constructor(props){
        super(props);
        this.componentDidMount = async ()=>{
            let { calculator, article } = this.props;
            let { limit, page } = this.state;
            if (!calculator) calculator = article;
            let comments = await (0,services/* post_request */.Yu)("comments", {
                item: calculator._id,
                limit,
                skip: limit * (page - 1)
            });
            this.setState({
                comments
            });
        };
        this.append_comment = (comment)=>{
            let { comments } = this.state;
            if (!Array.isArray(comments)) comments = new Array();
            comments = new Array(...comments, comment);
            this.setState({
                comments
            });
        };
        this.state = {
            limit: 10,
            page: 1
        };
    }
    render() {
        let { calculator, article } = this.props;
        if (!calculator) calculator = article;
        let { comments } = this.state;
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    class: "list-single-main-item fl-wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            class: "list-single-main-item-title fl-wrap",
                            children: comments && comments.length ? /*#__PURE__*/ (0,jsx_runtime.jsxs)("h3", {
                                children: [
                                    "Item Reviews - ",
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        children: [
                                            " ",
                                            comments.length,
                                            " "
                                        ]
                                    })
                                ]
                            }) : null
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            class: "reviews-comments-wrap",
                            children: comments ? comments.length ? comments.map((comment)=>/*#__PURE__*/ jsx_runtime.jsx(components_comment, {
                                    comment: comment
                                }, comment._id)) : /*#__PURE__*/ jsx_runtime.jsx(listempty/* default */.Z, {
                                text: "Be the first to post a review"
                            }) : /*#__PURE__*/ jsx_runtime.jsx(loadindicator/* default */.Z, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx(submit_review, {
                    calculator: calculator,
                    on_comment: this.append_comment
                })
            ]
        });
    }
}
/* harmony default export */ const reviews = (Reviews);


/***/ })

};
;