"use strict";
exports.id = 431;
exports.ids = [431];
exports.modules = {

/***/ 487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Mf: () => (/* binding */ month_index),
/* harmony export */   j2: () => (/* binding */ dow_index),
/* harmony export */   nw: () => (/* binding */ domain)
/* harmony export */ });
/* unused harmony exports hostname, client_domain, organisation_name, DEV, dow_index_inverse */
const DEV = false;
const hostname = DEV ? `http://${"localhost"}` : "https://mortgage-amortization-calculator.net";
const client_domain = (/* unused pure expression or super */ null && (DEV ? `${hostname}:1410` : `https://mortgage-amortization-calculator.net`));
const domain = DEV ? `${hostname}:3301` : `https://backend.mortgage-amortization-calculator.net`;
const month_index = new Object({
    0: "jan",
    1: "feb",
    2: "mar",
    3: "apr",
    4: "may",
    5: "jun",
    6: "jul",
    7: "aug",
    8: "sep",
    9: "oct",
    10: "nov",
    11: "dec"
});
const dow_index = new Object({
    1: "monday",
    2: "tuesday",
    3: "wednesday",
    4: "thursday",
    5: "friday",
    6: "saturday",
    7: "sunday"
});
const dow_index_inverse = new Object({
    monday: 1,
    tuesday: 2,
    wednesday: 3,
    thursday: 4,
    friday: 5,
    saturday: 6,
    sunday: 7
});
const organisation_name = "Calculator Master";



/***/ }),

/***/ 7108:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E_: () => (/* binding */ email_regex),
/* harmony export */   Ew: () => (/* binding */ commalise_figures),
/* harmony export */   GB: () => (/* binding */ trim_id),
/* harmony export */   Rd: () => (/* binding */ date_string),
/* harmony export */   Yl: () => (/* binding */ gen_random_int),
/* harmony export */   bk: () => (/* binding */ to_title),
/* harmony export */   ee: () => (/* binding */ copy_object),
/* harmony export */   iu: () => (/* binding */ search_object),
/* harmony export */   xu: () => (/* binding */ gen_randon_value)
/* harmony export */ });
/* unused harmony exports _id, generate_random_string, phone_regex, time_string, next_quarter, shuffle_array, countdown */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(487);

const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const combinations = {
    alnum: charset,
    num: "01234556789",
    alpha: "abcdefghijklmnopqrstuvwxyz"
};
const shuffle_array = (array)=>{
    const new_array = [
        ...array
    ];
    const length = new_array.length;
    for(let start = 0; start < length; start++){
        const random_position = Math.floor((new_array.length - start) * Math.random());
        const random_item = new_array.splice(random_position, 1);
        new_array.push(...random_item);
    }
    return new_array;
};
const to_title = (string)=>{
    if (!string) return string;
    let str = "";
    string.split(" ").map((s)=>{
        if (s) str += " " + s[0].toUpperCase() + s.slice(1);
    });
    return str.trim();
};
const date_string = (timestamp)=>{
    let date = new Date(timestamp);
    return `${date.getDate().toString().padStart(2, "0")} ${to_title(_constants__WEBPACK_IMPORTED_MODULE_0__/* .month_index */ .Mf[date.getMonth()])} ${date.getFullYear()}`;
};
const time_string = (timestamp)=>{
    let date = new Date(timestamp);
    return `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}`;
};
const generate_random_string = (len, combination)=>{
    let string = "";
    combination = combinations[combination] || combinations["num"];
    for(let i = 0; i < (len || 6); i++)string += combination[gen_random_int(combination.length)];
    return string;
};
const gen_random_int = (max_int, min_int = 0)=>Math.floor(Math.random() * (max_int - min_int + 1)) + min_int;
const gen_randon_value = (max, min = 0, decimal_place = 4)=>(Math.random() * (max - min) + min).toFixed(decimal_place);
let phone_regex = /^(\+{0,})(\d{0,})([(]{1}\d{1,3}[)]{0,}){0,}(\s?\d+|\+\d{2,3}\s{1}\d+|\d+){1}[\s|-]?\d+([\s|-]?\d+){1,2}(\s){0,}$/gm;
let email_regex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const next_quarter = ()=>{
    let date = new Date();
    let quarter = date.getMonth() % 3 + 1, quarter_was_4;
    let curr_entry = quarter;
    if (quarter === 4) {
        quarter_was_4 = true;
        quarter = 1;
    }
    let propect_month = quarter * 3, propect_year = date.getFullYear();
    let str = `${month_index[propect_month]}, ${quarter_was_4 ? propect_year + 1 : propect_year}`;
    let next_prospect_month = propect_month + 2;
    let next_entry = `${month_index[next_prospect_month > 11 ? 0 : next_prospect_month]}, ${next_prospect_month > 11 ? propect_year + 1 : propect_year}`;
    let curr_year = propect_year;
    curr_entry = curr_entry - 1;
    if (curr_entry === 0) {
        curr_entry = 0;
    }
    let curr_month = curr_entry * 3 + 1;
    return {
        str,
        next_entry,
        curr_entry: {
            month: curr_month,
            quarter: curr_entry === 0 ? 1 : curr_entry,
            year: curr_year,
            str: `${month_index[curr_month - 1]}, ${curr_year}`
        }
    };
};
const countdown = (date)=>{};
const _id = (prefix)=>{
    let random_value = "";
    for(let i = 0; i < gen_random_int(32, 12); i++)random_value += charset[gen_random_int(charset.length)];
    return `${prefix}~${random_value}~${Date.now()}`;
};
const commalise_figures = (figure)=>{
    if (typeof figure !== "number") {
        return figure;
    }
    if (figure >= 1e21) return figure.toLocaleString("fullwide");
    figure = figure.toString();
    if (figure.length <= 3) return figure;
    let ff = "", i;
    for(i = 0; i < figure.length; i += 3)ff = `${figure.slice(figure.length - i - 3, figure.length - i)},${ff}`;
    if (i < figure.length) ff = `${figure.slice(0, i)}${ff}`;
    else if (i > figure.length) {
        ff = `${figure.slice(0, figure.length % 3)}${ff}`;
    }
    if (ff.startsWith(",")) ff = ff.slice(1);
    return ff.slice(0, -1);
};
const search_object = (object, param)=>{
    if (Array.isArray(object)) return object.filter((o)=>search_object(o, param));
    param = param && param.trim().split();
    for(const prop in object){
        let value = object[prop];
        if (typeof value === "string") {
            value = value.toLowerCase().split(" ");
            for(let p = 0; p < param.length; p++)for(let v = 0; v < value.length; v++)if (value[v].includes(param[p].trim().toLowerCase())) return object;
        } else if (Array.isArray(value)) {
            if (value.find((v)=>search_object(v, param.join(" ")))) return object;
        } else if (typeof value === "object") {
            if (search_object(value, param.join(" "))) return object;
        }
    }
};
const copy_object = (object)=>{
    if (typeof object !== "object") return object;
    if (Array.isArray(object)) return object.map((o)=>copy_object(o));
    let new_object = {
        ...object
    };
    for(let prop in new_object){
        let val = new_object[prop];
        if (Array.isArray(val) && typeof val[0] === "object" && val[0] && valid_id(val[0]._id)) new_object[prop] = val.map((v)=>copy_object(v));
        else if (typeof val === "object" && val && !Array.isArray(val)) new_object[prop] = copy_object(val);
    }
    return new_object;
};
const trim_id = (_id)=>{
    return _id && _id.split("~").slice(1).join("~");
};



/***/ }),

/***/ 7354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AN: () => (/* binding */ get_request),
/* harmony export */   Yu: () => (/* binding */ post_request),
/* harmony export */   nw: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.nw)
/* harmony export */ });
/* unused harmony export upload_file */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(487);

const get_request = async (path, header, all)=>{
    if (path && path.startsWith("/")) path = path.slice(1);
    try {
        let ftch = await fetch(path.startsWith("http") ? path : `${_constants__WEBPACK_IMPORTED_MODULE_0__/* .domain */ .nw}/${path}`, header);
        let res;
        try {
            res = await ftch.json();
        } catch (e) {
            return {
                _$not_sent: true
            };
        }
        return all ? res : res && res.data;
    } catch (e) {
        console.log(e, _constants__WEBPACK_IMPORTED_MODULE_0__/* .domain */ .nw);
    }
};
const upload_file = async (file)=>{
    let form_data = new FormData();
    if (!Array.isArray(file)) file = new Array(file);
    file.map((f, index)=>form_data.append(`file${index}`, f));
    try {
        let ftch = await fetch("/upload_file", {
            method: "POST",
            // mode: "no-cors",
            headers: {
                "Content-Type": "multipart/form-data",
                Accept: "application/json"
            },
            body: form_data
        });
        let res;
        try {
            res = await ftch.json();
        } catch (e) {
            return {
                _$not_sent: true
            };
        }
        return res.data;
    } catch (e) {
        console.log(e, domain);
        return null;
    }
};
const post_request = async (path, data, header)=>{
    if (path && path.startsWith("/")) path = path.slice(1);
    try {
        let ftch = await fetch(path.startsWith("http") ? path : `${_constants__WEBPACK_IMPORTED_MODULE_0__/* .domain */ .nw}/${path}`, {
            method: "POST",
            // mode: "no-cors",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                ...header
            },
            body: data && JSON.stringify(data)
        });
        let res;
        try {
            res = await ftch.json();
        } catch (e) {
            return {
                _$not_sent: true
            };
        }
        return res && res.data;
    } catch (e) {
        console.log(e, _constants__WEBPACK_IMPORTED_MODULE_0__/* .domain */ .nw);
        return path, data;
    }
};



/***/ }),

/***/ 91:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Lx: () => (/* binding */ get_session),
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   kH: () => (/* binding */ scroll_to_top),
/* harmony export */   qC: () => (/* binding */ save_to_session)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default,scroll_to_top,save_to_session,get_session auto */ 



const scroll_to_top = ()=>window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
const save_to_session = (key, value)=>window.sessionStorage.setItem(key, JSON.stringify(value));
const get_session = (key)=>{
    let value = window.sessionStorage.getItem(key);
    try {
        value = JSON.parse(value);
    } catch (e) {}
    return value;
};
class Footer extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { navs } = this.props;
        navs?.sort((c1, c2)=>{
            let a_title = c1?.title?.toLowerCase(), b_title = c2?.title?.toLowerCase();
            if (a_title === "other" && b_title !== "other") return 1;
            else if (a_title !== "other" && b_title === "other") return -1;
            else return 0;
        });
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
            className: "dark-footer skin-dark-footer style-2",
            style: {
                backgroundColor: "#000"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "footer-middle",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-5 col-md-5",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "footer_widget",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "text-light",
                                                    children: "Calculator Master"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: "extream text-light mb-3",
                                                children: "UK"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-light",
                                                children: "Crunch those numbers with confidence - our top calculators have got you covered!"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-lg-6 col-md-7 ml-auto",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "footer_widget",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            className: "widget_title",
                                                            children: "Categories"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                            className: "footer-menu",
                                                            children: navs && navs.length ? navs.map((nav)=>nav === "developer" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: `text-light`,
                                                                    onClick: scroll_to_top,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                        href: `/calculators/${nav.title.replace(/ /g, "")}?_id=${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_3__/* .trim_id */ .GB)(nav._id)}`,
                                                                        onClick: ()=>save_to_session("category", nav),
                                                                        children: nav && nav.title || "home"
                                                                    })
                                                                }, nav._id)) : null
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "footer_widget",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            className: "widget_title",
                                                            children: "Company"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                            className: "footer-menu",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                    href: `/blog`,
                                                                    children: "Blog"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "footer-bottom",
                    style: {
                        backgroundColor: "#000"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row align-items-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-12 col-md-12 text-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "mb-0",
                                    children: [
                                        "\xa9 ",
                                        new Date().getFullYear(),
                                        " Calculator Master. All rights reserved."
                                    ]
                                })
                            })
                        })
                    })
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);



/***/ }),

/***/ 1030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Listempty = ({ text })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "my-5",
        style: {
            textAlign: "center",
            width: "100%"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            style: {
                textAlign: "center"
            },
            className: "h4",
            children: text || "Nothing here yet."
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Listempty);


/***/ }),

/***/ 1875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ loadindicator)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./assets/css/img/ajax-loader.gif
/* harmony default export */ const ajax_loader = ({"src":"/_next/static/media/ajax-loader.ff361d5c.gif","height":198,"width":198,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./components/loadindicator.js
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Loadindicator = ({ height, width, small })=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: !small ? "d-flex align-items-center justify-content-center my-5" : "",
        children: /*#__PURE__*/ jsx_runtime.jsx("img", {
            src: ajax_loader.src,
            style: {
                height: height || 64,
                width: width || 64
            }
        })
    });
};
/* harmony default export */ const loadindicator = (Loadindicator);


/***/ }),

/***/ 3909:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6981);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_padder__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5969);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7108);
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Custom_nav = ({ navs })=>{
    navs?.sort((c1, c2)=>{
        let a_title = c1?.title?.toLowerCase(), b_title = c2?.title?.toLowerCase();
        if (a_title === "other" && b_title !== "other") return 1;
        else if (a_title !== "other" && b_title === "other") return -1;
        else return 0;
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "header",
                style: {
                    backgroundColor: "#fff",
                    color: "#000",
                    position: "fixed",
                    width: "100vw"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: "navigation",
                        className: "navigation navigation-landscape",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Navbar, {
                            expand: "lg",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavbarBrand, {
                                    href: "/",
                                    className: "nav-brand",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-dark",
                                        children: "Calculator Master"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavbarToggler, {
                                    ref: (nav_toggle)=>undefined.nav_toggle = nav_toggle,
                                    style: {
                                        color: "#000",
                                        backgroundColor: "pink"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Collapse, {
                                    isOpen: false,
                                    navbar: true,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_2__.Nav, {
                                        className: "ml-auto",
                                        navbar: true,
                                        style: {
                                            alignItems: "center"
                                        },
                                        children: [
                                            navs && navs.length ? navs.map((nav, index)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                                        style: {
                                                            backgroundColor: "transparent"
                                                        },
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            style: {
                                                                textDecorationColor: "none"
                                                            },
                                                            href: `/calculators/${nav.title.replace(/ /g, "_")}?_id=${(0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .trim_id */ .GB)(nav._id)}`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                style: {
                                                                    color: "#000"
                                                                },
                                                                children: (0,_assets_js_utils_functions__WEBPACK_IMPORTED_MODULE_5__/* .to_title */ .bk)(nav.title.replace(/_/g, " "))
                                                            })
                                                        })
                                                    })
                                                }, index);
                                            }) : null,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavItem, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                                    style: {
                                                        backgroundColor: "transparent"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        style: {
                                                            textDecorationColor: "none",
                                                            borderLeftColor: "#ccc",
                                                            borderLeftWidth: 1,
                                                            borderLeftStyle: "solid",
                                                            paddingLeft: 10
                                                        },
                                                        href: "/blog",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            style: {
                                                                color: "#000"
                                                            },
                                                            children: "Blog"
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_padder__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Custom_nav);


/***/ }),

/***/ 5969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Padder = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            height: 80
        }
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Padder);


/***/ }),

/***/ 1294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Text_btn = ({ text, color, style, action, icon })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        onClick: action,
        style: {
            color: color || "#03b97c",
            cursor: "pointer",
            ...style
        },
        children: [
            text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: `${text}  `
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: `fas ${icon}`
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Text_btn);


/***/ })

};
;