"use strict";
exports.id = 712;
exports.ids = [712];
exports.modules = {

/***/ 5589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Alert_box = ({ message, type })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        class: `alert alert-${type || "danger"}`,
        role: "alert",
        children: message
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Alert_box);


/***/ }),

/***/ 3782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1875);
/* __next_internal_client_entry_do_not_use__ default auto */ 


class Stretch_button extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { title, action, loading, disabled, style } = this.props;
        if (loading) disabled = loading;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            type: "button",
            className: disabled ? "btn full-width btn-md gray text-dark" : "btn full-width btn-md text-dark",
            disabled: disabled,
            onClick: ()=>!disabled && action && action(),
            style: {
                ...style,
                textTransform: "capitalize",
                backgroundColor: "#ffdf00",
                color: "#000"
            },
            children: [
                title,
                loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    small: true
                }) : null
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stretch_button);


/***/ })

};
;