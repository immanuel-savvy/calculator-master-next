"use strict";
exports.id = 55;
exports.ids = [55];
exports.modules = {

/***/ 2160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

class Contact_us_today extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact_us_today);


/***/ }),

/***/ 586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_blurhash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7497);
/* harmony import */ var react_blurhash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_blurhash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _loadindicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1875);
/* harmony import */ var _assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(487);
/* __next_internal_client_entry_do_not_use__ default auto */ 





class Preview_image extends (react__WEBPACK_IMPORTED_MODULE_1___default().Component) {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        let { image_loaded } = this.state;
        let { onclick, style, no_preview, image, class_name, image_hash, height, width, parent_class, childs } = this.props;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            className: parent_class,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__.LazyLoadImage, {
                    src: image && (image.startsWith("/") || image.startsWith("http") || image.startsWith("data")) || typeof image !== "string" ? image : `${_assets_js_utils_constants__WEBPACK_IMPORTED_MODULE_5__/* .domain */ .nw}/images/${image}`,
                    onLoad: ()=>this.setState({
                            image_loaded: true
                        }),
                    beforeLoad: ()=>this.setState({
                            image_load_started: true
                        }),
                    className: class_name || "img-fluid rounded image-responsive",
                    onClick: onclick,
                    style: {
                        height: image_loaded ? height || null : 0,
                        width: width || null,
                        ...style
                    }
                }),
                !image_loaded && image_hash ? no_preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loadindicator__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    small: true
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_blurhash__WEBPACK_IMPORTED_MODULE_2__.Blurhash, {
                    hash: image_hash,
                    height: height || 210,
                    width: width || 600,
                    className: class_name || "img-fluid rounded",
                    punch: 1,
                    onClick: onclick
                }) : null,
                childs
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Preview_image);


/***/ })

};
;