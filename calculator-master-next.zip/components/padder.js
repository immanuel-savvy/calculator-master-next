"use client";

import React from "react";

const Padder = () => <div style={{ height: 80 }} />;

export default Padder;
