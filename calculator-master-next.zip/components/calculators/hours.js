import React from "react";

class Hours_calculator extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return <></>;
  }
}

export default Hours_calculator;
