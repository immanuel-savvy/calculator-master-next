import React from "react";
import Morgage_loan_repayment from "./morgage_loan_repayment";

class Loan_calculator extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return <Morgage_loan_repayment />;
  }
}

export default Loan_calculator;
