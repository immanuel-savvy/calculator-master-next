"use client";

import React from "react";

class Contact_us_today extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return <></>;
  }
}

export default Contact_us_today;
